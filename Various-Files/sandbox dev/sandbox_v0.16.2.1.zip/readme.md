![Foundry version badge](https://img.shields.io/endpoint?url=https%3A%2F%2Ffoundryshields.com%2Fversion%3Fstyle%3Dfor-the-badge%26url%3Dhttps%3A%2F%2Fraw.githubusercontent.com%2FAnderware%2FSandbox-System-Builder%2Frefs%2Fheads%2Fmain%2Fsystem.json)![GitHub Release](https://img.shields.io/github/v/release/Anderware/Sandbox-System-Builder?style=for-the-badge&label=Latest%20release&color=%23ff6400)
# Sandbox

Build any system, without coding a single line in Javascript.

Sandbox lets you build any TTRPG system, including sheets and game data, without coding. To install it, go to your Foundry core main page, and in the systems tab search for Sandbox. Install it, and you are now ready to start building your system.

## Contributors

| Name      | Role                                      | Like this system? Want to donate?                            |
| --------- | ----------------------------------------- | ------------------------------------------------------------ |
| Ramses800 | Current main developer                    | [Ko-fi](https://ko-fi.com/ramses800)                         |
| Alondaar  | Support and development                   | [Ko-fi](https://ko-fi.com/alondaar)                          |
| Seregras  | Original developer and creator of Sandbox | [PATREON](https://www.patreon.com/seregras?fan_landing=true) |

More contributor information can be found in  [Contributors](contributors.md)

## Documentation, Tutorials & More help

### Documentation

[Documentation](docs/help/start.md)

#### Documentation update in progress

These pages are under construction, if needed, please refer to the previous [README](readme_previous.md)

### Videos

These videos were made with earlier versions of Sandbox and thus some things looks slightly different and not all newer features are included, but the core principles and functionality is still valid.

Playlist with video tutorials in English
[Video tutorials -English](https://www.youtube.com/playlist?list=PLMAQsyqo9jDFpHYy4WZv0eF_SgqotcUKs)

Playlist with video tutorials in Spanish
[Video tutorials -Spanish](https://www.youtube.com/playlist?list=PLMAQsyqo9jDFEfeqRHBhwHT7kY_1eK2zY)

### How-tos

Find various articles on how-to do things in the [Wiki](https://gitlab.com/rolnl/sandbox-system-builder/-/wikis/How-to)

### More help

Do you have questions? Join the Discord server and head to SANDBOX ENGLISH
[Discord](https://discord.gg/QE7CHNP)

## Frequent issues

- Do not insert data in the Template actor. Template Actors are not for sheet building, just create regular actors for that!
- After rebuilding a sheet, any previous character will require pressing the reload template button, left of the template selector, in order to display the new changes
  ![](docs/help/resources/actor_sheet_header.jpg)
- Never forget to include a key to a Sandbox element, or it won't let you drag it anywhere. Also, make sure keys are unique and do not contain spaces!
- Whenever you change a template, your existing actors won't register the changes correctly. 
This is intentional, until sandbox is more stable so any mistakes in the template don't destroy your world. You just need to reload the template as mentioned above