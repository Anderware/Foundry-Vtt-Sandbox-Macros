const _system_id='sandbox';  // system true name(id)


// Usage: 
//    let api=game.system.api;
//    api.BuildActorTemplates();   
export class SandboxAPI {
  // ---------------------------------------------------------------- 
  // Initialize                                                       
  // ----------------------------------------------------------------     
  initialize() {   
      console.log("Sandbox | Initializing API");
      game.system.api={
        BuildActorTemplates,
        Actor_GetFromName,
        Actor_GetFromSheet,
        ActorSheet_GetFromActor,
        ActorSheet_Render,
        SheetInfo_GetFromSheetId,
        fontAwesomeIconPicker
      };           
    
  }
}

// **************************************************************** 
// Macro:        BuildActorTemplates                                                    
// Description:  Build all actor templates.
//               Useful if the template does not show normally
// Parameters :  actortemplatename - optional, if set only this template will rebuild                               
// Example :     for building only the template named _PlayerCharacter
//               BuildActorTemplates('_PlayerCharacter');
//                      
// ================================================================ 
// Date       Version  Author               Description             
// ---------- -------- -------------------- ----------------------- 
// 2021-12-16 1.0.0    Ramses800            Macro created.         
// **************************************************************** 
function BuildActorTemplates(actortemplatename=''){
  let actortemplates;
  if(actortemplatename==''){
    // get all actor templates
    actortemplates=game.actors.filter(y => y.type=="character" && y.system.istemplate==true);
  }
  else{
    // get specific actor
    actortemplates=game.actors.filter(y => y.type=="character" && y.system.istemplate==true && y.name==actortemplatename);
  }    
  if(actortemplates.length>0){ 
    // loop all actors
    actortemplates.forEach(function(actortemplate)  { 
      if(actortemplate!=null){
        
        ui.notifications.info('Building actor template '+ actortemplate.name )
        console.log('Building actor template '+ actortemplate.name )
        try{
          actortemplate.sheet.buildSheet();
          ui.notifications.info('Build complete for actor template '+ actortemplate.name )
        }
        catch(err){
          ui.notifications.error('Error building actor template ' + actortemplate.name);
          console.err('Error building actor template' + actortemplate.name);
          console.err(err);
        }
      }
    });    
  }
  else{
    ui.notifications.warn('No actor template found');
  }
    
}

//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                               
//                          Functions for getting Actor                          
//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                               

// ***************************************************************************** 
// Function:       Actor_GetFromName                                       
// Description:    Get actor with name 
// Version  
// Parameters:     name as string                
// Returns:        actor, returns null if not found                              
// ============================================================================= 
// Date       Version  Author               Description                          
// ---------- -------- -------------------- ------------------------------------ 
// 2022-04-30 1.0.0    Ramses800            Function created                      
// ***************************************************************************** 
function Actor_GetFromName(actorname){
  let actor;
  actor=game.actors.getName(actorname); 
  if(actor==null){
    ui.notifications.warn('Actor_GetFromName | No Actor found with name [' + actorname + ']');
  }
  return actor;
}

// ***************************************************************************** 
// Function:       Actor_GetFromSheet                 
// Parameters:     event            
// Return:         Returns the actor that called this macro from its Sandbox sheet
//                 If no actor found, it returns null. 
//                 This means generally that the macro have 
//                 been run from the hot bar
// ============================================================================= 
// Date       Version  Author               Description             
// ---------- -------- -------------------- ------------------------------------
// 2021-11-30 1.0.0    Ramses800            Function created                          
// *****************************************************************************  
function Actor_GetFromSheet(event) {
  let returnactor;  
  let cp = event.composedPath();
  for (let key in cp) {
    if (cp.hasOwnProperty(key)) {
      if ((typeof (cp[key]) !== "undefined" && cp[key] !== null)) {
        if ((typeof (cp[key].classList) !== "undefined" && cp[key].classList !== null)) {
          if (cp[key].classList.contains('sandbox') && cp[key].classList.contains('sheet') && cp[key].classList.contains('actor')) {
            //console.log(cp[key].id);  //actor-MMwTr94GekOCihrC   or actor-MMwTr94GekOCihrC-6bX8wMQkdZ9OyOQa
            let sheetinfo=SheetInfo_GetFromSheetId(cp[key].id);
            if(sheetinfo.documentclass!=null && sheetinfo.documentid!=null){
              switch (sheetinfo.documentclass){
                case "Actor":
                  returnactor = game.actors.get(sheetinfo.documentid);
                  break;
                case "Token":
                  let token = canvas.tokens.placeables.find(y=>y.id==sheetinfo.documentid);
                  if (token != null) {
                    returnactor = token.actor;
                  }
                  break;
              }
            }
            // exit for loop, no need to look anymore
            break;
          }
        }
      }
    }
  }
  return returnactor;
}

//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                               
//                          Functions for Actor Sheets                          
//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//  
function ActorSheet_GetFromActor(actor){
  let actorsheet;
  if(actor==null){
    ui.notifications.warn('ActorSheet_Render | No Actor data supplied');
  } else {
    actorsheet=actor.sheet;       
  } 
  return actorsheet;
}

function ActorSheet_Render(actorsheet){
  if(actorsheet==null){
    ui.notifications.warn('ActorSheet_Render | No Actor Sheet found');
  } else {
    actorsheet.render(true,{focus:true});
  }        
}


//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                               
//                                Support Functions                          
//                                                                               
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<o>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
// 
function SheetInfo_GetFromSheetId(sheetid){         
  let sheetinfo={
    documentclass:null,
    sheetclass:null,
    documentid:null,
    sceneid:null,
    compendium_type:null,
    compendium_name:null
  };
  let substrings=sheetid.split("-");
  
  if(substrings.length>0){
    sheetinfo.sheetclass=substrings[0];
    switch (substrings[0]){
      case "gActorSheet":        
        if(substrings.length>1){
          switch (substrings[1]){
            case "Actor":
              // actor            :gActorSheet-Actor-8I8j7C8KRYY6zQSK
              if(substrings.length>2){
                sheetinfo.documentclass=substrings[1];
                sheetinfo.documentid=substrings[2];
              }
              break;
            case "Scene":
              // token actor      :gActorSheet-Scene-8VQZqtjzEgqqaPDK-Token-MPWjc8w15806WYt1
              if(substrings.length>4){
                sheetinfo.documentclass=substrings[3];
                sheetinfo.documentid=substrings[4];
                sheetinfo.sceneid=substrings[2];
              }
              break;
            case "Compendium":
              // compendium actor :gActorSheet-Compendium-world-monsters-PbY9XcLCKKGrlvtU              
              if(substrings.length>4){
                sheetinfo.documentclass=substrings[1];
                sheetinfo.documentid=substrings[4];
                sheetinfo.compendium_name=substrings[3];
                sheetinfo.compendium_type=substrings[2];
              }
              break;
          }
        }                  
        break;
      case "sItemSheet":                
        if(substrings.length>1){
          switch (substrings[1]){            
            case "Item":
              //sItemSheet-Item-Wif4h38I0OiNapG1
              if(substrings.length>2){
                sheetinfo.documentclass=substrings[1];
                sheetinfo.documentid=substrings[2];
              }
              break;
            case "Compendium":
              //sItemSheet-Compendium-world-equipment-OuRNFgwaueUsYhFh
              if(substrings.length>4){
                sheetinfo.documentclass=substrings[1];
                sheetinfo.documentid=substrings[4];
                sheetinfo.compendium_name=substrings[3];
                sheetinfo.compendium_type=substrings[2];
              }
              break;
          }
        }
        break;
    }             
  }          
  return sheetinfo;  
}


async function fontAwesomeIconPicker(selectedclass='',defaultclass='', addToTitle='') {
  let sTitle=`Icon Picker` + addToTitle;
  let html=`
    <style>
    
    </style>
    <script>
    
    async function iconPickerReadJSONFile(sfileurl){
      let result = null;      
      const response = await fetch(sfileurl);
      if (!response.ok) {
        const message = 'Icon Picker : Can not read icon file, response[' + response.status +']';
        ui.notifications.error(message);
      } else {
        result = await response.json();
      }  
      return result;
    }
  
    async function iconPickerLoadIcons(){
      
      let iconshtml='';
      let iconcount= 0;  
      let iconarray=[];
      let iconsjson=null; 
      // load from json, start with brands
      iconsjson = await iconPickerReadJSONFile("systems/sandbox/module/fontawesome-icons-brands.json"); 
      if (iconsjson!=null){
        iconsjson.forEach(function(item){          
          // check if ends with ::before
          if(item.selector!=null){
            if(item.selector.trim().endsWith(':before')){ 
              // split selectors
              const selectors=item.selector.split(',');
              // use the first selector and get rid starting . and ending  of ::before
              const selector='fa-brands ' + selectors[0].trim().substr(1, selectors[0].trim().length - 8 );                               
              iconcount = iconcount + 1;              
              iconarray.push(selector);
            }
          }
  
        });
      }
      // load from json, the rest
      iconsjson = await iconPickerReadJSONFile("systems/sandbox/module/fontawesome-icons.json"); 
      if (iconsjson!=null){
        iconsjson.forEach(function(item){          
          // check if ends with ::before
          if(item.selector!=null){
            if(item.selector.trim().endsWith(':before')){ 
              // split selectors
              const selectors=item.selector.split(',');
              // use the first selector and get rid starting . and ending  of ::before
              const selector=selectors[0].trim().substr(1, selectors[0].trim().length - 8 );                               
              iconcount = iconcount + 1;              
              iconarray.push(selector);
            }
          }
  
        });
      }
      console.log('Sandbox | IconPicker | icons loaded:' + iconcount);

      if (iconarray.length>0) {                               
        // sort array
        iconarray.sort((a, b) => a.localeCompare(b));
        // get any filter active
        let textfilter=document.getElementById("sb-icon-picker-filter").value;
        
        if(textfilter.length>0){
          // check for multiple search
          let filterused=textfilter.trim().split(' ')
          for (let i = 0; i < filterused.length; i++) {
            if(filterused[i].trim().length>0){
              iconarray=iconarray.filter(name => name.includes(filterused[i].trim()));
            }
          } 
          
        } 
        // output array
        for (var i = 0; i < iconarray.length; i++) {      
          iconshtml+= '<div class="sb-icon-picker-displayframe" title="' + iconarray[i] +'" dataitem="' + iconarray[i] +'"  onclick="iconPickerSelectIcon();"><i dataitem="' + iconarray[i] +'" class="sb-icon-picker-displayicon fas ' + iconarray[i] +'"  ></i></div>';
        }
        // update div
        document.getElementById("sb-icon-picker-body").innerHTML=iconshtml;
      }
    }
     
    function iconPickerLoadPreviousIcons(){
      let previousicons='';
      let current_previous_used_icons=game.user.getFlag('world','sb-icon-picker-previous-used-icons');
      if(current_previous_used_icons!=null){
        if(current_previous_used_icons.length>0){                                                                
          // add other prevoius
          for (let i = 0; i < current_previous_used_icons.length; i++) {
            previousicons+= '<div class="sb-icon-picker-displayframe" title="' + current_previous_used_icons[i] +'" dataitem="' + current_previous_used_icons[i] +'"  onclick="iconPickerSelectIcon();"><i dataitem="' + current_previous_used_icons[i] +'" class="sb-icon-picker-displayicon fas ' + current_previous_used_icons[i] +'"  ></i></div>';
          } 
        // update div
        document.getElementById("sb-icon-picker-previous-selected-body").innerHTML=previousicons;
        }
      }
    }
  
  
    function iconPickerLoadStandardIcons(){
      const standardicons=['fa-book','fa-vial','fa-star','fa-dice-d20','fa-dice-d12','fa-dice-d10','fa-dice-d8','fa-dice-d6','fa-dice-d4','fa-circle','fa-square','fa-file-alt'];
      let iconshtml='';
      for (let i = 0; i < standardicons.length; i++) {
          iconshtml+= '<div class="sb-icon-picker-displayframe" title="' + standardicons[i] +'" dataitem="' + standardicons[i] +'"  onclick="iconPickerSelectIcon();"><i dataitem="' + standardicons[i] +'" class="sb-icon-picker-displayicon fas ' + standardicons[i] +'"  ></i></div>';
      } 
      // update div
      document.getElementById("sb-icon-picker-standard-icons-body").innerHTML=iconshtml;
        
      
    }
  
  
  
    function iconPickerSelectIcon() {        
      let target=event.target;  
      let selector=target.getAttribute('dataitem');
      document.getElementById("sb-icon-picker-selected-icon-class").value=selector;
      document.getElementById("sb-icon-picker-selected-icon-preview").className = 'sb-icon-picker-displayicon fas ' + selector;
    }
    function iconPickerSelectedIconTextChanged() {
      let selector=document.getElementById("sb-icon-picker-selected-icon-class").value;
      document.getElementById("sb-icon-picker-selected-icon-preview").className = 'sb-icon-picker-displayicon fas ' + selector;
    }
    function iconPickerFilter() {
      iconPickerLoadIcons(); 
    }
    function iconPickerFilterClear() {
      document.getElementById("sb-icon-picker-filter").value='';
      iconPickerLoadIcons(); 
    }
    function iconPickerBringToFront(){
      let dialog_element=document.getElementById('sb-icon-picker-dialog'); 
      if(dialog_element!=null){
        // get app id 
        const appID=dialog_element.getAttribute('data-appid');
        if(appID!=null){
          let app=ui.windows[appID];
          if (app!=null){    
            // attempt to bring to the front
            app.bringToTop(); 
          }
        }
      }
    }
  
    </script>
    <fieldset>
      <legend class="sb-icon-picker-title">Icon library</legend>
      <div>
        <span class="sb-icon-picker-span-no-break" >
          <label class="sb-icon-picker-label-no-break" for="sb-icon-picker-filter">Search filter</label><input type="text" id="sb-icon-picker-filter"/>
          <button class="sb-icon-picker-button-filter" type="button" onclick="iconPickerFilter()" title="Search"><i  class="fa-solid fa-magnifying-glass"></i></button> 
          <button class="sb-icon-picker-button-filter" type="button" onclick="iconPickerFilterClear()" title="Clear filter"><i  class="fa-solid fa-times-circle"></i></button> 
        </span>
      </div>
      <div id="sb-icon-picker-body" class ="sb-icon-picker-body">
      </div>
    </fieldset> 
  
    <fieldset class="sb-icon-picker-default-icon">
      <legend class="sb-icon-picker-title">Default icon</legend>
      <div id="sb-icon-picker-default-icon-body" class ="sb-icon-picker-default-icon-body">        
        <div class="sb-icon-picker-displayframe" title="${defaultclass}" dataitem="${defaultclass}"  onclick="iconPickerSelectIcon();"><i dataitem="${defaultclass}" class="sb-icon-picker-displayicon fas ${defaultclass}"  ></i></div>
      </div>
    </fieldset>  
  
    <fieldset class="sb-icon-picker-standard-icon">
      <legend class="sb-icon-picker-title">Standard icons</legend>
      <div id="sb-icon-picker-standard-icons-body" class ="sb-icon-picker-standard-icons-body">                
      </div>
    </fieldset>  
  
    <fieldset class="sb-icon-picker-previous-icons">
      <legend class="sb-icon-picker-title">Previously used icons</legend>
      <div id="sb-icon-picker-previous-selected-body" class ="sb-icon-picker-previous-selected-body">
      </div>
    </fieldset>  
    <fieldset>
      <legend class="sb-icon-picker-title">Selected icon</legend>
      <div>      
        <span class="sb-icon-picker-span-no-break" >
          <label class="sb-icon-picker-label-no-break">Selected icon</label>
          <div class="sb-icon-picker-displayframe"><i id="sb-icon-picker-selected-icon-preview" class="sb-icon-picker-displayicon fas ${selectedclass}" ></i></div>
          <input style="margin-left: 12px;" type="text" disabled id="sb-icon-picker-selected-icon-class" class="sb-icon-picker-selected-icon-class" onchange="iconPickerSelectedIconTextChanged()" value="${selectedclass}"/>                
        </span>
      </div>
    </fieldset>
    <script>
    iconPickerLoadIcons();
    iconPickerLoadStandardIcons();
    iconPickerLoadPreviousIcons();
    // make sure the dialog is in front
    iconPickerBringToFront();
    </script>
    
    `;
  
  
  let dialog = new Promise((resolve, reject) => {
    new Dialog({
      title: sTitle,
      content: html,      
      buttons: {
        ok: {
          icon: '<i class ="fas fa-check"></i>',
          label: `OK`,
          callback: async() => {
            const selectedicon=document.getElementById("sb-icon-picker-selected-icon-class").value;
            // get previous
            let current_previous_used_icons=game.user.getFlag('world','sb-icon-picker-previous-used-icons');
            
            let updated_previous_used_icons=[];
            
            // add it                
            updated_previous_used_icons.push(selectedicon);
            if(current_previous_used_icons!=null){
              if(current_previous_used_icons.length>0){                                                                
                // add other prevoius
                let icons_added=1;
                for (let i = 0; i < current_previous_used_icons.length; i++) {
                  // only use the lastest x
                  if(icons_added==18){
                    break;
                  }
                  // only add others
                  if(current_previous_used_icons[i]!=selectedicon){
                    updated_previous_used_icons.push(current_previous_used_icons[i]);
                    icons_added = icons_added + 1;
                  }
                } 
              }
            }
            
            game.user.setFlag('world','sb-icon-picker-previous-used-icons',updated_previous_used_icons)
            resolve(selectedicon);
          }
        },
        cancel: {
          icon: '<i class ="fas fa-times"></i>',
          label: `Cancel`,
          callback: () => {  
            // game.user.unsetFlag('world','sb-icon-picker-previous-used-icons');
            resolve('');
          }
        }
      },
      default: "ok",
      close: () => {
        resolve('')
      }      
    }).render(true,{
            width: "632",
            height: "750",
            resizable: false,
            id:"sb-icon-picker-dialog"            
    });
  });
  let answer = await dialog;
  return answer;
}