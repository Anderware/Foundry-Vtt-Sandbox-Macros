# Sandbox Extensions Change Log
## Version 0.14.0(2023-01-05)
- Foundry 10 changes
  - Data Model
    - Important Note: When migrating a v9 Sandbox world, all actors/actor templates will be in an faulty state. 
      Use "Build Actor Templates" from the Sandbox System Builder Section in the Settings Sidebar to update actor templates to v10 data model
      and Reload all actors
  - Drag n drop
  - CSS adaptations
- Refactored System Settings
- Improved chat messages
- Refactored JSON Export
- Added API to Sandbox
  - Added BuildActorsTemplate to API
- Added Sandbox System Builder Section to Settings Sidebar
  - Moved JSON Export and Import to Sandbox System Builder Section
  - Added BuildActorTemplates to Sandbox System Builder Section
  - Added Bug Report Form to Sandbox System Builder Section
- Added Confirm Delete for subitem lists(tables etc)
- Added Item Helpers for items
  - Autogeneration
  - Expression Editor
  - Validation
  - Copy/Cut/Paste
- Added feature Show Icons? for tables
- Added icons for property datatypes
- Reworked item icons to SVGs
- Added Show icons on all subitems list on sheet,tab,panel,multipanel,group
- Various fixes and tweaks
