import  { 
          SETTINGATTRIBUTE,
          sb_item_sheet_get_game_setting
        } from "./sb-setting-constants.js";
import  { 
          ITEM_SHEET_HEIGHT,
          ITEM_SHEET_PROPERTY_HEIGHT,
          ITEM_SHEET_DEFAULT_WIDTH,
          ITEM_SHEET_TABS
        } from "./sb-itemsheet-constants.js";
import { SOCKETCONSTANTS } from "./sb-socket-constants.js";


export function sb_sheet_appwindow_id(id){
  // item             :sItemSheet-Item-8Wdrh3wOYzx5S5rE
  // actor            :gActorSheet-Actor-8I8j7C8KRYY6zQSK
  // token actor      :gActorSheet-Scene-8VQZqtjzEgqqaPDK-Token-MPWjc8w15806WYt1
  // compendium actor :gActorSheet-Compendium-world-monsters-PbY9XcLCKKGrlvtU 
  // compendium item  :sItemSheet-Compendium-world-equipment-GdgvW214tin4odiA
  // infoform item    :SandboxInfoForm-Item-a4cTIwVWm7QtnztR
  let appwindowinfo={
    type:null,
    id:null,
    compendium:{type:null,name:null}
  };
  let substrings=id.split("-"); 
  switch(substrings.length){
    case 3:
      appwindowinfo.type=substrings[1];
      appwindowinfo.id=substrings[2];
      break;
    case 5:
      // check for compendium
      if(substrings[1]=='Compendium'){
        if(substrings[0]=='sItemSheet'){
          appwindowinfo.type='Item';                    
        } else if(substrings[0]=='gActorSheet'){
          appwindowinfo.type='Actor'; 
        }
        appwindowinfo.compendium.type=substrings[2];
        appwindowinfo.compendium.name=substrings[3];
         appwindowinfo.id=substrings[4];
      } else if(substrings[1]=='Scene'){
        appwindowinfo.type='Token';
        appwindowinfo.id=substrings[4];
      }            
      break;
  };
  return appwindowinfo;  
}

export function sb_sheet_display_id_in_window_caption(html, sheettype, appwindowinfo) {
  const OPTION_DISPLAY_ID_IN_SHEET_CAPTION = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.OPTION_DISPLAY_ID_IN_SHEET_CAPTION.ID); 
  if (OPTION_DISPLAY_ID_IN_SHEET_CAPTION) {
    if (game.user.isGM) {
      let foldername = '';
      let newelementid = 'sb-show-in-console-' + appwindowinfo.id; 
      if (appwindowinfo.compendium.type==null){
        // get folder based on type
        switch (sheettype) {
          case 'Actor':
            let actor = game.actors.get(appwindowinfo.id);
            if (actor != null) {
              if (actor.folder != null) {
                foldername = actor.folder.name;
              }
            }
            break;
          case 'Item':
            let item = game.items.get(appwindowinfo.id);
            if (item != null) {
              if (item.folder != null) {
                foldername = item.folder.name;
              }
            }
            break;
        }
        if (foldername.length > 0) {
          foldername = ' in Folder [' + foldername + ']';
        }        
      } else {
        // compendium
        foldername = ' in Compendium [' + appwindowinfo.compendium.type + '.' + appwindowinfo.compendium.name + ']';
      }
      // get window title
      let insertafterthis = html.find('.window-title');
      if (insertafterthis) {
        insertafterthis.after('<a id="' + newelementid + '" title="' + sheettype + ' [' + appwindowinfo.id + ']' + foldername + '&#13;Click to show data in Console"><i class="fas fa-tag"></i> Info</a>');
        switch (sheettype) {
          case 'Actor':            
            // if token
            // need to get the actor from the canvas so use the secondary id            
            if (appwindowinfo.type=="Token") {                                                       
              html.find('#' + newelementid).click(ev => {
                let token = canvas.tokens.placeables.find(y=>y.id==appwindowinfo.id); 
                // output this to console on purpose
                console.log(token.actor);
              });                              
            } else {
              // check for compendium
              if (appwindowinfo.compendium.type==null){
                // normal actor
                html.find('#' + newelementid).click(ev => {
                  // output this to console on purpose
                  console.log(game.actors.get(appwindowinfo.id));
                });
              } else {
                // compendium actor
                html.find('#' + newelementid).click(async (ev) => {
                 const pack=game.packs.get(appwindowinfo.compendium.type + "." + appwindowinfo.compendium.name);
                 const compendiumactor = await pack.getDocument(appwindowinfo.id);
                 // output this to console on purpose
                 console.log(compendiumactor);
                 });
              }
            }                        
            break;
          case 'Item':
            if (appwindowinfo.compendium.type==null){
              // normal item
              html.find('#' + newelementid).click(ev => {
                // output this to console on purpose
                console.log(game.items.get(appwindowinfo.id));
              });  
            } else {
              // compendium item
              html.find('#' + newelementid).click(async (ev) => {
                 const pack=game.packs.get(appwindowinfo.compendium.type + "." + appwindowinfo.compendium.name);
                 const compendiumitem = await pack.getDocument(appwindowinfo.id);
                 // output this to console on purpose
                 console.log(compendiumitem);
              });
            }
            break;
        }
      }
    }
  }
}

export function sb_sheet_display_show_to_others_in_sheet_caption(html, sheettype, appwindowinfo,reshowable=false,defaultshowclass='') {
  const OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION.ID); 
  if (OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION) {            
    if (html[0].classList.contains('sb-info-form-reshowable')||reshowable){
      let showid;
      let showtype;
      let showclass;    
      if(defaultshowclass!=''){
        showclass=defaultshowclass;
      } else{
        if (html[0].classList.contains('sb-info-form-show-image-only')){
          showclass='sb-info-form-show-image-only';
        }
        if (html[0].classList.contains('sb-info-form-show-name-and-image')){
          showclass='sb-info-form-show-name-and-image';
        }
        if (html[0].classList.contains('sb-info-form-show-all')){
          showclass='sb-info-form-show-all';
        }
      }
      let newelementid = 'sb-show-others-' + appwindowinfo.id;
      let insertafterthis = html.find('.window-title');
      if (insertafterthis) {
        insertafterthis.after('<a id="' + newelementid + '" title="Show info to others"><i class="fas fa-eye"></i> Show</a>');
        switch (sheettype) {
          case 'Actor':
            // if the actorid is double(ie MwTr94GekOCihrC-6bX8wMQkdZ9OyOQa), then it is a unlinked token, 
            // need to get the actor from the canvas so use the secondary id            
            if (appwindowinfo.type=="Token") {              
              showid=appwindowinfo.id;
              showtype='Token';            
            } else {
              // check for compendium
              if (appwindowinfo.compendium.type==null){
                // normal actor
                showid=appwindowinfo.id;
                showtype='Actor';
              } else {
                // compendium actor                                
                // TODO
                console.warn('Sandbox | sb_sheet_display_show_to_others_in_sheet_caption | support for compendium actor not there yet')
                showid=appwindowinfo.id;
                showtype='Actor';
              }
            }                    
            break;
          case 'Item':     
            if (appwindowinfo.compendium.type==null){
              // normal item
              showid=appwindowinfo.id;
              showtype='Item';
            } else {
              // compendium item
              // TODO
              console.warn('Sandbox | sb_sheet_display_show_to_others_in_sheet_caption | support for compendium item not there yet')
              showid=appwindowinfo.id;
              showtype='Item';
            }
            break;
        }
        html.find('#' + newelementid).click(ev => { 
          //console.log('Sandbox | sb_sheet_display_show_to_others_in_sheet_caption');
          sb_sheet_showplayers_info_form(showid,showtype,showclass);
        });
      }
    }
  }
}

function sb_sheet_showplayers_info_form(showid,showtype,showclass) {
  //console.warn('sbe_sheet_showplayers_info_form,' + showid + ','+showtype+','+showclass);
  //
  let objectname='';
  let datasource='';
  let token_actor_id='';
  switch (showtype) {
    case('Item'):
      let item = game.items.get(showid);
      if (item != null) {
        objectname=item.name;
        datasource=`<input type="hidden" id="show-info-content-datasource-item" name="show-info-content-datasource-item" value="Item">`;
      }
      break;
    case('Actor'):
      let actor = game.actors.get(showid)
      if (actor != null) {
        objectname=actor.name;
        datasource=`<input type="hidden" id="show-info-content-datasource-actor" name="show-info-content-datasource-actor" value="Actor">`;
      }
      break;
    case('Token'):
      let token = canvas.tokens.placeables.find(y => y.id == showid);
      if (token != null) {
        objectname= token.name;
        // get the parent actor for the token for later use
        token_actor_id=token.document.actorId;        
        datasource=`
                     <br><label>From : </label>
                    <input class="sb-info-form-option" type="radio" id="show-info-content-datasource-actor" name="show-info-content-datasource" value="Actor" >
                    <label class="sb-info-form-option" for="show-info-content-datasource-actor">Actor</label>
                    <input class="sb-info-form-option" type="radio" id="show-info-content-datasource-token" name="show-info-content-datasource" value="Token" checked>
                    <label class="sb-info-form-option" for="show-info-content-datasource-token">Token</label>
                    `;
      }
      break;
  }
  // generate dialog to ask userwhat data to show
  let htmlUsers='';
  // generate user list
  let users = game.users.filter(user => user.active);
  let actor;
  let actorimg="icons/svg/mystery-man.svg";
  let username='';
  let charactername='';
  let userid;
  // Build checkbox list for all active players
  users.forEach(user => {           
    username=user.name;
    if(user.isGM){
      username +='[GM]'
    }
    userid=user.id;
    if (user.character!=null){             
      actor=game.actors.get(user.character.id);
      if(actor!=null){
        actorimg=actor.img;
      }
      charactername=user.character.name;
      
    } else {
      charactername=user.name;      
      // use the user avatar if any
      if (user.avatar!=null){
        actorimg=user.avatar;
      }      
    }
    htmlUsers+='<div class="sb-info-form-playerinfo"><input type="checkbox" class="sb-info-form-playerselected" name="' + username +'" value="' + userid +'"  checked><img class="sb-info-form-portrait-img"  src="' + actorimg +'"</img><p>' + charactername+'<br>[' + username  +']' + '</p></div>';
  });
  
  // 
  //
  let showAll='';
  let showImageOnly='';
  let showNameAndImage='';
  switch (showclass){
    case 'sb-info-form-show-all':
      showAll='checked';      
      break;
    case 'sb-info-form-show-name-and-image':
      showAll='disabled';
      showNameAndImage='checked';
      break;
    case 'sb-info-form-show-image-only':
      showAll='disabled';
      showImageOnly='checked';
      showNameAndImage='disabled';
      break;
  }
  let d=new Dialog({
    title: `Show [` + showtype + '] ' + objectname + ' to others',
    content: `
          <style>
            
          </style>
          <script>
            function sbeshowInfoToggleUserSelection(){
              // get current value of "Selected users"
              const toselectedusers=document.getElementById("show-info-to-selected").checked;
              let fsSelectedUsers=document.getElementById("show-info-selected-users");
              if(toselectedusers){
                fsSelectedUsers.disabled = false;
              } else {
                fsSelectedUsers.disabled = true;
              }
            }
          </script>
            <form>
          <div class="sb-info-form-column-float"> 
            <fieldset class="sb-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show as</legend> 

                  <input class="sb-info-form-option" type="radio" id="show-info-as-form" name="show-info-show-type" value="FORM" checked>
                  <label class="sb-info-form-option" for="show-info-as-form">Pop-up</label><br>
               
                  
                  <input class="sb-info-form-option" type="radio" id="show-info-as-chat" name="show-info-show-type" value="CHAT" >
                  <label class="sb-info-form-option" for="show-info-as-chat">Chat</label><br>
                
                  <input class="sb-info-form-option" type="radio" id="show-info-as-chat-compact" name="show-info-show-type" value="CHAT_COMPACT" >
                  <label class="sb-info-form-option" for="show-info-as-chat-compact">Chat(compact)</label><br>
                
            </fieldset> 
          </div>
          <div class="sb-info-form-column-float"> 
            <fieldset class="sb-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show what</legend>
                                  
                  <input class="sb-info-form-option" id="show-info-content-description" name="show-info-content" type="radio" value="all" ` + showAll + ` />
                  <label class="sb-info-form-option" for="show-info-content-description">Image, name and info</label><br>
                                                     
                  <input class="sb-info-form-option" id="show-info-content-name" name="show-info-content" type="radio" value="name-and-image" ` + showNameAndImage + ` />
                  <label class="sb-info-form-option" for="show-info-content-name">Image and name</label><br>
                   
                  <input class="sb-info-form-option" id="show-info-content-image" name="show-info-content" type="radio" value="image-only" ` + showImageOnly + `/>  
                  <label class="sb-info-form-option" for="show-info-content-image">Image only</label>
                  `+datasource+`
              </fieldset>
          </div>
          
          <div class="sb-info-form-column-float">
          <fieldset class="sb-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show to</legend> 
                
                  <input class="sb-info-form-option" type="radio" id="show-info-to-all" name="show-info-show-to" value="ALL" onclick="sbeshowInfoToggleUserSelection();" checked>
                  <label class="sb-info-form-option" for="show-info-to-all">All players & GM</label><br>

                  <input class="sb-info-form-option"  type="radio" id="show-info-to-gm" name="show-info-show-to" value="GM" onclick="sbeshowInfoToggleUserSelection();">
                  <label class="sb-info-form-option" for="show-info-to-gm">GM only</label><br>
    
                  <input class="sb-info-form-option" type="radio" id="show-info-to-selected" name="show-info-show-to" value="SELECTED" onclick="sbeshowInfoToggleUserSelection();">
                  <label class="sb-info-form-option" for="show-info-to-selected">Selected players</label><br>
           </fieldset>
          </div>
          

          <fieldset id="show-info-selected-users" style="text-align:left;" disabled>
            <legend style="text-align:left;">Selected players</legend>
            `+htmlUsers+`
          </fieldset>   
                

      </form>
            `,
    buttons: {
      yes: {
        icon: "<i class='fas fa-check'></i>",
        label: `Show`,
        callback: async (html) => {
          // assemble data
          // what to show                    
          let who_show=(html.find('input[name="show-info-show-to"]:checked').val() || 'none'); 
          if(who_show=='SELECTED'){
            // get users
            const selectedplayers = document.getElementsByClassName("sb-info-form-playerselected"); 
            if(selectedplayers.length>0){
              who_show='';
              // get them
              for (let i = 0; i < selectedplayers.length; i++){
                if(selectedplayers[i].checked){                          
                  who_show+=selectedplayers[i].value +';' ;                  
                }
              }
              if(who_show==''){
                who_show='none';
              }
            } else {
              who_show='none';
            }
          }
          const what_show=(html.find('input[name="show-info-content"]:checked').val() || 'none'); 
          const how_show=(html.find('input[name="show-info-show-type"]:checked').val() || 'none'); 
          // for tokens, check if user wanted to use data from the parent actor
          if(showtype=='Token'){
            const datasource=(html.find('input[name="show-info-content-datasource"]:checked').val() || 'Token');
            if(datasource=='Actor'){
              showtype='Actor';
              showid=token_actor_id;
            }
          }
          if(what_show !='none' && who_show !='none' && how_show!='none'){                        
            if(how_show=='CHAT' ){
              sb_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,false);
            } else if(how_show=='CHAT_COMPACT'){
              sb_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,true);
            } else {
              // send through socket to client to show popup
              let show_name=false;
              let show_image=false;
              let show_description=false;            
              console.log('Show to players ' + showtype + ' : ' + showid );
              switch(what_show){
                case 'all':
                  show_name=true;
                  show_image=true;
                  show_description=true;
                  break;
                case 'image-only':
                  show_image=true;
                  break;
                case 'name-and-image':
                  show_name=true;
                  show_image=true;
                  break;
              }
              game.socket.emit(SOCKETCONSTANTS.CONNECTION.NAME, {
                op:SOCKETCONSTANTS.MSG.OPERATIONS.SHOW_PLAYERS,
                from:game.user.id,
                data:{
                  id: showid,
                  type:showtype,
                  class:showclass,
                  show:{
                    name:show_name,
                    image:show_image,
                    description:show_description,
                    who:who_show
                  }
                }
              });
            }
          } else{
            // notify user no msg will be sent
            ui.notifications.warn('Show to others | No content or recipients selected to show');
          }
        }
      },
      no: {
        icon: "<i class='fas fa-times'></i>",
        label: `Cancel`
      }
    },
    default: "yes",
    close: (html) => {
    }
  });
  d.options.width = 575;
  d.position.width = 575;
  d.options.height=0;
  d.position.height=0;
  d.options.resizable=true;
  d.render(true);
}

function sb_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,compact_mode=false) {  
  let chatname='';
  let chatimage='';
  let whisperrecipients='';
  let objectname;
  let objectimage;
  let objectinfo;
  switch (showtype) {
    case('Item'):
      let item = game.items.get(showid);
      if (item != null) {
        objectname=item.name;
        objectimage=item.img;
        objectinfo=item.system.description;
      }
      break;
    case('Actor'):
      let actor = game.actors.get(showid)
      if (actor != null) {
        objectname=actor.name;
        objectimage=actor.img;
        objectinfo=actor.system.biography;
      }
      break;
    case('Token'):
      let token = canvas.tokens.placeables.find(y => y.id == showid);
      if (token != null) {
        objectname= token.name;
        objectimage=token.document.texture.src; //  token.img;
        objectinfo=token.actor.system.biography;
      }
      break;
  }    
  switch(what_show){
    case 'all':            
      break;
    case 'image-only':      
      objectname=null;
      objectinfo=null;
      break;
    case 'name-and-image':      
      objectinfo=null;
      break;
  }
  
  if (game.user.character!=null){ 
    let actor=game.actors.get(game.user.character.id);
    if(actor!=null){
      chatimage=actor.img;      
      chatname=actor.name;
    }        
  } else {
    chatimage = game.user.avatar;
    chatname = game.user.name;
  }  
  // determine recipiencts
  let targets=[];
  let iswhisper=false;
  switch(who_show){
    case 'ALL':            
      break;
    case 'GM':
      iswhisper=true;
      whisperrecipients='GM' ;
      // whisper to GMs
      targets= ChatMessage.getWhisperRecipients('GM');
      // add self
      targets.push(game.user.id);
      break;
    default:
      iswhisper=true;
      whisperrecipients= '';
      // parse name list
      const arrRecipients = who_show.split(";");
      let recipient;
      for (let i = 0; i < arrRecipients.length; i++){
        targets.push(arrRecipients[i]);
        recipient=game.users.get(arrRecipients[i]);
        if (recipient!=null){
          if(whisperrecipients.length==0){
            whisperrecipients=recipient.name;
          } else {
            whisperrecipients+=', ' + recipient.name;
          }
        }
      }
      // add self
      targets.push(game.user.id);
  }      
  let msgData = {
      token:{
          img:chatimage,
          name:chatname
      },
      objectinfo: objectinfo,
      objectname:objectname,
      objectimage:objectimage,
      compact_mode:compact_mode,
      actor:chatname,
      user: game.user.name,
      isWhisper:iswhisper,
      whisperTo:whisperrecipients
    };
  renderTemplate("systems/sandbox/templates/sb-info-chat-msg-all.hbs", msgData).then(html => {
      ChatMessage.create({
          content: html,
          whisper: targets
      });
  });                            
}


export function adaptItemSheetGeoMetrics (gItemSheet, html)  {
  const typeClass = gItemSheet.item.type;
  const OPTION_ADAPT_ITEM_SHEET_POSITION = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.OPTION_ADAPT_ITEM_SHEET_POSITION.ID);
  if(OPTION_ADAPT_ITEM_SHEET_POSITION){
    // make room for details menu by  increasing the item sheet window height                    
    if (game.user.isGM) {      
      // for updates the return html is a form
      if (html[0].nodeName !== 'FORM') {    
        let sheetheight=ITEM_SHEET_HEIGHT[typeClass.toUpperCase()]; 
        if (typeClass.toUpperCase() == 'PROPERTY') {
          const datatype = gItemSheet.item.system.datatype;
          sheetheight = ITEM_SHEET_PROPERTY_HEIGHT[datatype.toUpperCase()];
        }
        // center window
        let newtop = (window.innerHeight - (sheetheight)) / 2;
        if (newtop < 0) {
          newtop = 0;
        }
        gItemSheet.setPosition({top: newtop});
        gItemSheet.setPosition({height: sheetheight, width: ITEM_SHEET_DEFAULT_WIDTH});
      }
    }
  }
  const OPTION_SET_DEFAULT_ITEM_TAB = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.OPTION_SET_DEFAULT_ITEM_TAB.ID); 
    if (OPTION_SET_DEFAULT_ITEM_TAB ) {
      // set default tab shown for items
      if (game.user.isGM) {
        // for updates the return html is a form
        if (html[0].nodeName !== 'FORM') {
          const detailstabname = ITEM_SHEET_TABS[typeClass.toUpperCase()].DETAILS;
          // activate tab
          gItemSheet._tabs[0].activate(detailstabname);
        }
      }
    }
};