export async function sb_custom_dialog_confirm(sTitle,sQuestion,answerOneCaption='Ok',answerTwoCaption='Cancel'){
  let dialog=new Promise((resolve,reject)=>{
    new Dialog({
      title: sTitle,
      content: sQuestion ,
      buttons: {
        ok: {
          icon:'<i class ="fas fa-check"></i>',
          label: answerOneCaption,            
          callback: () => {resolve(true)}
        },
        cancel: { 
          icon:'<i class ="fas fa-times"></i>',
          label: answerTwoCaption,            
          callback: () => {resolve(false)}
        }
      },
      default: "ok",
      close:  () => {resolve(false) }   
    }).render(true);             
  }); 
  let answer=await dialog;
  return answer;    
 }

export async function sb_custom_dialog_information(sTitle,sInformation,answerOneCaption='Ok'){
  let dialog=new Promise((resolve,reject)=>{
    new Dialog({
      title: sTitle,
      content:  sInformation ,
      buttons: {
        ok: {
          icon:'<i class ="fas fa-check"></i>',
          label: answerOneCaption,            
          callback: () => {resolve(true)}
        }
      },
      default: "ok",
      close:  () => {resolve(false) }   
    }).render(true);             
  }); 
  let answer=await dialog;
  return answer;    
 }   
 
 export async function confirmRemoveSubItem(parentName,parentType,itemName,itemType=''){
   let prompttitle =game.i18n.format("SANDBOX.confirmRemoveSubItemPromptTitle",{itemname:itemName,itemtype:itemType});
   let promptbody='<h4>' + game.i18n.localize("AreYouSure") +'</h4>';        
   promptbody   +='<p>' + game.i18n.format("SANDBOX.confirmRemoveSubItemPromptBody",{parentname:parentName,parenttype:parentType,itemname:itemName,itemtype:itemType}) +'</p>';        
   let answer=sb_custom_dialog_confirm(prompttitle,promptbody,game.i18n.localize("Yes"),game.i18n.localize("No"));
   return answer;
 }
 
