import { SandboxInfoForm } from "./sb-info-form.js";
import { SOCKETCONSTANTS } from "./sb-socket-constants.js";

export function sb_socket_manager(msg) {
  console.log('recieved data');
  console.log(msg);

  switch (msg.op) {
    case(SOCKETCONSTANTS.MSG.OPERATIONS.CLIENT_REFRESH):
      if(msg.user != game.user.id){
        //
        console.warn('Sandbox | Refresh request');
      }
      break;
    case(SOCKETCONSTANTS.MSG.OPERATIONS.SHOW_PLAYERS):
      let showme = false;
      // check if to show this player
      switch (msg.data.show.who) {
        case 'ALL':
          showme=true;
          break;
        case 'GM':
          if(game.user.isGM){
            showme=true;
          }
          break;
        default:
          // check for length
          if (msg.data.show.who.length>0){
            // split to array by semicolon
            const arrRecipients = msg.data.show.who.split(";");
            if(arrRecipients.includes(game.user.id)){
              showme=true;              
            }
          }
      }
      if (showme) {
        let options;
        switch (msg.data.type) {
          case('Item'):
            let item = game.items.get(msg.data.id);
            if (item != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: item.name,
                image: item.img,
                description: item.system.description
              };
            }
            break;
          case('Actor'):
            let actor = game.actors.get(msg.data.id)
            if (actor != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: actor.name,
                image: actor.img,
                description: actor.system.biography
              };
            }
            break;
          case('Token'):
            let token = canvas.tokens.placeables.find(y => y.id == msg.data.id);
            if (token != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: token.name,
                image: token.img,
                description: token.actor.system.biography
              };
            }
            break;
        }
        if (options != null) {
          let f = new SandboxInfoForm(options).render(true, {focus: true});
        }
        break;
      }
  }
}
