import  { 
          SETTINGATTRIBUTE,
          sb_item_sheet_get_game_setting
        } from "./sb-setting-constants.js";
import { sb_custom_dialog_information,
         sb_custom_dialog_confirm} from "./sb-custom-dialogs.js";        

export async function versionManagement(){
  // check if world flag for system version has been set
  const WORLD_LAST_CORE_VERSION_USED = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.WORLD_LAST_CORE_VERSION_USED.ID);
  const WORLD_LAST_SYSTEM_VERSION_USED = sb_item_sheet_get_game_setting("sandbox", SETTINGATTRIBUTE.WORLD_LAST_SYSTEM_VERSION_USED.ID);
  
  let worldHasData=true;
  let versionDataFound=false;
  // pre v0.14.0, the sandbox did not save the version used with the world
  if(WORLD_LAST_SYSTEM_VERSION_USED==''){
    // not set yet
    console.log('Sandbox | versionManagement | World last system used not set');
    // check if the world has any data
    if(game.items.size==0 && game.actors.size == 0 ){
      // new world
      worldHasData=false;
      console.log('Sandbox | versionManagement | World has no items/actors');
    }
    if(worldHasData){    
      console.log('Sandbox | versionManagement | World has items/actors');      
      // check all actors for version data  _stats(added in foundry v10)
      for (let [key, actor] of  game.actors.entries()) {	
        if(actor._stats.systemVersion!=null){
          // actor found with version data
          console.log(key + " = " + actor.name)
          versionDataFound=true;
          break;
        }
      }                  
      // check all items for version data
      if(!versionDataFound){
        for (let [key, item] of  game.items.entries()) {	
          if(item._stats.systemVersion!=null){
            // actor found with version data
            console.log(key + " = " + item.name)
            versionDataFound=true;
            break;
          }
        } 
      }            
      // if world has data and no version info is found for any actors/items then assume this is a migrated world from pre 0.14.0
      if(!versionDataFound){        
        // remind user        
        await sb_custom_dialog_information(game.i18n.localize("Information"),game.i18n.localize("SANDBOX.VersionManagementAfterMigrationTo10NoticeTitle"),game.i18n.localize("Ok"))
        
      }
    } else {
      // no actors or items found, assume new world
    }
    
    
  } else {
    // version info found in world settings
    console.log('Sandbox | versionManagement | World last Foundy core used:' + WORLD_LAST_CORE_VERSION_USED);
    console.log('Sandbox | versionManagement | World last Sanbox system used:' + WORLD_LAST_SYSTEM_VERSION_USED);
  }
  
  // check if world has Sandbox extensions installed and actve
  let isSandboxExtensionsActive=false;
  if (game.modules.get("sandbox-extensions")!=null ){
    isSandboxExtensionsActive=game.modules.get("sandbox-extensions").active;
    console.log('Sandbox | versionManagement | Sandbox Extension is active:' + isSandboxExtensionsActive);
    if(isSandboxExtensionsActive){      
      await sb_custom_dialog_information(game.i18n.localize("Information"),game.i18n.localize("SANDBOX.VersionManagementExtensionsWarning"))
      // disable the module
      let moduleSettings = game.settings.get('core','moduleConfiguration')
      moduleSettings['sandbox-extensions'] = false;
      await game.settings.set('core','moduleConfiguration',moduleSettings)
      let answer = await sb_custom_dialog_confirm(game.i18n.localize("SETTINGS.ReloadPromptTitle"),game.i18n.localize("SETTINGS.ReloadPromptBody"),game.i18n.localize("Yes"),game.i18n.localize("No"))
      if(answer){
        // reload for settings to take effect
        location.reload();
      }
    }   
  }
  
  // update world setting for versions 
  await game.settings.set(game.system.id, SETTINGATTRIBUTE.WORLD_LAST_SYSTEM_VERSION_USED.ID, game.system.version);  
  await game.settings.set(game.system.id, SETTINGATTRIBUTE.WORLD_LAST_CORE_VERSION_USED.ID, game.version);  
}
