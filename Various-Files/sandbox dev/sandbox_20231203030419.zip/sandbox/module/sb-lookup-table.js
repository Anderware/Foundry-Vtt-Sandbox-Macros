
// returns empty string if error or not found
export function lookupv(lookupValue,lookupKey,returnColumn,exactMatch=false,optionalDefault=''){
  let returnvalue=optionalDefault;
  let lookup=game.items.find(y=>y.type=='lookup' && y.system.lookupKey==lookupKey);
  if(lookup==null) {
    ui.notifications.warn('Unable to find Lookup item with key:['+ lookupKey +']');
    return returnvalue;
  }
  
  if(!sb_is_valid_lookupTable(lookup.system.lookupTable)) {
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have invalid lookup table');
    return returnvalue;
  }

  if(lookup.system.lookupTable.columns.length==0){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have no columns');
    return returnvalue;
  }

  if(lookup.system.lookupTable.rows.length==0){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have no rows');
    return returnvalue;
  }

  if(returnColumn>=lookup.system.lookupTable.columns.length){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have less than '+ (returnColumn + 1) +' columns');
    return returnvalue;
  }
  
  for (let row = 0; row < lookup.system.lookupTable.rows.length-1; row++) {    
    if((lookupValue)>=(lookup.system.lookupTable.rows[row][0]) && (lookupValue)<=(lookup.system.lookupTable.rows[row][1])){
      returnvalue=lookup.system.lookupTable.rows[row][returnColumn];
      return returnvalue;
    }
  }  
  if(!exactMatch){
    if(lookupValue<(lookup.system.lookupTable.rows[0][0])){
      returnvalue=lookup.system.lookupTable.rows[0][returnColumn];
      return returnvalue;
    }
  }
  if(!exactMatch){
    if(lookupValue>(lookup.system.lookupTable.rows[lookup.system.lookupTable.rows.length-1][1])){
      returnvalue=lookup.system.lookupTable.rows[lookup.system.lookupTable.rows.length-1][returnColumn];
      return returnvalue;
    }
  }
  return returnvalue;
}


export function lookupx(lookupValue,lookupKey,lookupColumn,returnColumn,optionalDefault=''){
  let returnvalue=optionalDefault;
  let lookup=game.items.find(y=>y.type=='lookup' && y.system.lookupKey==lookupKey);
  if(lookup==null) {
    ui.notifications.warn('Unable to find Lookup item with key:['+ lookupKey +']');
    return returnvalue;
  }
  
  if(!sb_is_valid_lookupTable(lookup.system.lookupTable)) {
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have invalid lookup table');
    return returnvalue;
  }

  if(lookup.system.lookupTable.columns.length==0){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have no columns');
    return returnvalue;
  }

  if(lookup.system.lookupTable.rows.length==0){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have no rows');
    return returnvalue;
  }

  if(returnColumn>=lookup.system.lookupTable.columns.length){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have less than '+ (returnColumn + 1) +' columns');
    return returnvalue;
  }
  
  if(lookupColumn>=lookup.system.lookupTable.columns.length){
    ui.notifications.warn('Lookup item ['+ lookup.name  +'] with key:['+ lookupKey +'] have less than '+ (lookupColumn + 1) +' columns');
    return returnvalue;
  }
  
  for (let row = 0; row < lookup.system.lookupTable.rows.length-1; row++) {    
    if((lookupValue)==(lookup.system.lookupTable.rows[row][lookupColumn])){
      returnvalue=lookup.system.lookupTable.rows[row][returnColumn];
      return returnvalue;
    }
  }  
  return returnvalue;  
}


export function sb_lookupTable_to_string(lookupTable){
  try {
      return (JSON.stringify(lookupTable));
    } catch (e) {
      console.error('sb_string_to_lookupTable | ' + e.message);
      return '';
    }
}

export function sb_string_to_lookupTable(sLookupTable){  
  try {
      return (JSON.parse(sLookupTable));
    } catch (e) {
      console.error('sb_string_to_lookupTable | ' + e.message);
      return '';
    }  
}


// returns the lookup(as string) if valid, else empty string
export function sb_string_is_valid_lookup_table(slookuptable) {
  // check lookuptable if it is a valid json
  let lookupTable = sb_string_to_lookupTable(slookuptable);
  if(lookupTable=='') return '';    
  if(!sb_is_valid_lookupTable(lookupTable)) return '';
  return slookuptable;    
}

// returns true if valid lookup table(object) else false
export function sb_is_valid_lookupTable(lookupTable){
  if(lookupTable==null) return false;
  if(!lookupTable.hasOwnProperty('columns')) return false; 
  if(!lookupTable.hasOwnProperty('rows')) return false;
  if(lookupTable.columns.length<2) return false;
  return true;
}


