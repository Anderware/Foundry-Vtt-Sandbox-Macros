export const SOCKETCONSTANTS={
  CONNECTION:{
    NAME:'system.sandbox'
  },
  MSG:{
    OPERATIONS:{
      TARGET_EDIT:'target_edit',
      TRANSFER_EDIT:'transfer_edit',
      SHOW_PLAYERS:'show_players',
      CLIENT_REFRESH:'client_refresh'
    }
  }
};

