import * as stringCasing from './sbe-strings-case.js'
import { ModuleSettingsForm } from "./module-settings-form.js";
import { SandboxExtensionsToolsForm } from "./sbe-tools-form.js";

export function sbe_settings_menus(obj) {
  // menu for tools
    game.settings.registerMenu(obj.ID, obj.SETTINGS.AUTOGEN.TOOLS_FORM, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.TOOLS_FORM}.Name`,
      label: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.TOOLS_FORM}.Name`,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.TOOLS_FORM}.Hint`,
      icon: "fas fa-toolbox",
      type: SandboxExtensionsToolsForm,
      restricted: true
    });  
    // menu for the Module Setting Form 
    game.settings.registerMenu(obj.ID, obj.SETTINGS.AUTOGEN.SETTINGS_FORM, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
      label: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SETTINGS_FORM}.Hint`,
      icon: "fas fa-cog",
      type: ModuleSettingsForm,
      restricted: true
    }); 
}

export function sbe_settings_registration(obj) {
  game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION, {
    name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}.Name`,
    default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}`,
    type: Boolean,
    scope: 'user',
    config: true,
    hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}.Hint`,
    category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_ITEM_DELETE_PROTECTION
  });
  
  // ------------------
    // OPtions for cItems
    // ------------------
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS
    });    
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON_TABLE_SUFFIX, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON_TABLE_SUFFIX}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON_TABLE_SUFFIX}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON_TABLE_SUFFIX}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS
    });        
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SETTING_CITEM_ICON_SIZE, {
        name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SETTING_CITEM_ICON_SIZE}.Name`,
        hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SETTING_CITEM_ICON_SIZE}.Hint`,
        scope: "client",
        config: false,
        type: Number,
        range: {
          min: 0,
          max: 256,
          step: 1,
        },
        default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SETTING_CITEM_ICON_SIZE}`,
        category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS  
      });                   
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS 
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS 
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_CITEM_OPTIONS 
    });
    // -----------------------
    // General display options
    // -----------------------
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SUBITEMS_ICONS, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SUBITEMS_ICONS}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_DISPLAY_SUBITEMS_ICONS}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SUBITEMS_ICONS}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_GENERAL_DISPLAY_OPTIONS
    });
    // -------------
    // Sheet caption 
    // -------------
    
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_ID_IN_SHEET_CAPTION, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_ID_IN_SHEET_CAPTION}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_DISPLAY_ID_IN_SHEET_CAPTION}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_ID_IN_SHEET_CAPTION}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_SHEET_CAPTION_OPTIONS
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_SHEET_CAPTION_OPTIONS        
    });
    // ------------
    // Items sheets
    // ------------
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_ITEM_SHEET_OPTIONS
    });       
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_ITEM_SHEET_OPTIONS
    });      
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_ITEM_SHEET_OPTIONS
    });
    // key validation options
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_KEY_VALIDATION_OPTIONS
    });
    // ----------------------
    // Autogeneration options
    // ----------------------
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}`,
      type: String, 
      choices: {
        0: stringCasing.CASING.CASE.NONE,
        1: stringCasing.CASING.CASE.LOWERCASE,
        2: stringCasing.CASING.CASE.UPPERCASE,
        3: stringCasing.CASING.CASE.TITLECASE
      },        
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}`,
      type: String, 
      choices: {
        0: stringCasing.CASING.CASE.NONE,
        1: stringCasing.CASING.CASE.LOWERCASE,
        2: stringCasing.CASING.CASE.UPPERCASE,
        3: stringCasing.CASING.CASE.TITLECASE
      },        
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}`,
      type: Boolean,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_OPTIONS
    });
    // -----------------
    // Prefixes/suffixes
    // -----------------
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_PANEL, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PANEL}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PANEL}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_PANEL}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_GROUP, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_GROUP}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_GROUP}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_GROUP}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.PREFIX_TAB, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_TAB}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.PREFIX_TAB}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.PREFIX_TAB}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    }); 
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });         
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SUFFIX_ROLLID, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_ROLLID}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });      
    game.settings.register(obj.ID, obj.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME, {
      name: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}.Name`,
      default: `${obj.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}`,
      type: String,
      scope: 'world',
      config: false,
      hint: `sandbox-extensions.settings.autogen.${obj.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}.Hint`,
      category: obj.SETTINGS.AUTOGEN.SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES        
    });
  
  
  
  
  
}
