const _title = "Sandbox Extensions Tools";
const _formid = "Sandbox-Extensions-Tools";
import { ModuleSettingsForm } from "./module-settings-form.js";
import { SandboxKeyCheckerForm } from "./sandbox-key-checker-form.js";
import { SandboxItemCheckerForm } from "./sandbox-item-checker-form.js";

import { SandboxExtensionsProcessLogForm } from "./sbe-process-log-form.js";

export class SandboxExtensionsToolsForm extends FormApplication {

  static initialize() {

    console.log('Initialized ' + _title);
  }

  static get defaultOptions() {
    const defaults = super.defaultOptions;
    const overrides = {
      height: 'auto',
      width: '600',
      id: _formid,
      template: `modules/sandbox-extensions/templates/sbe-tools-form.hbs`,
      title: _title,
      userId: game.userId,
      closeOnSubmit: false, // do not close when submitted
      submitOnChange: false, // submit when any input changes 
      resizable: true
    };
    const mergedOptions = foundry.utils.mergeObject(defaults, overrides);
    return mergedOptions;
  }

  activateListeners(html) {
    super.activateListeners(html);

    html.find('#sbe-btn-show-settings').click(this._onDisplay_SandboxExtensions_Settings.bind(this));

    html.find('#sbe-btn-show-key-checker').click(this._onDisplay_SandboxExtensions_KeyChecker.bind(this));
    html.find('#sbe-btn-show-item-structure-checker').click(this._onDisplay_SandboxExtensions_ItemStructureChecker.bind(this));

    html.find('#sbe-btn-show-citem-checker').click(this._onDisplay_SandboxExtensions_cItemChecker.bind(this));
    html.find('#sbe-btn-show-templateactor-checker').click(this._onDisplay_SandboxExtensions_TemplateActorChecker.bind(this));
  }

  getData(options) {
    let data;
    data = {
      submenus: {
        KEY_CHECKER: {
          id: 'sbe-btn-show-key-checker',
          name: 'sandbox-extensions.settings.autogen.KEY_CHECKER_FORM.Name',
          hint: 'sandbox-extensions.settings.autogen.KEY_CHECKER_FORM.Hint',
          icon: 'fas fa-key',
          display: true,
          indevelopment: false
        },
        ITEM_STRUCTURE_CHECKER: {
          id: 'sbe-btn-show-item-structure-checker',
          name: 'sandbox-extensions.settings.autogen.ITEM_CHECKER_FORM.Name',
          hint: 'sandbox-extensions.settings.autogen.ITEM_CHECKER_FORM.Hint',
          icon: 'fas fa-sitemap',
          display: true,
          indevelopment: false
        },
        CITEM_CHECKER: {
          id: 'sbe-btn-show-citem-checker',
          name: 'sandbox-extensions.settings.autogen.CITEM_CHECKER_FORM.Name',
          hint: 'sandbox-extensions.settings.autogen.CITEM_CHECKER_FORM.Hint',
          icon: 'fas fa-sitemap',
          display: false,
          indevelopment: true
        }
        ,
        TEMPLATE_ACTOR_CHECKER: {
          id: 'sbe-btn-show-templateactor-checker',
          name: 'Template actor checker',
          hint: 'You should not be here',
          icon: 'fas fa-sitemap',
          display: false,
          indevelopment: true
        }
      }
    };
    return data;
  }

  _onDisplay_SandboxExtensions_cItemChecker(event) {
    event.preventDefault();
    let options = {
      processid: 'sbe-process-citem-checker',
      titletext: 'Sandbox cItem Checker',
      formtext: '<p>Checks data for cItems</p><p>Please note that for a world with many items, the check could take a little time.</p>',
      processfunction: SandboxExtensions_cItemsCheck,
      logtableconfiguration: {}
    };
    new SandboxExtensionsProcessLogForm(options).render(true, {focus: true});
  }

  _onDisplay_SandboxExtensions_TemplateActorChecker(event) {
    event.preventDefault();
    let options = {
      processid: 'sbe-process-templateactor-checker',
      titletext: 'Sandbox Template Actor Checker',
      formtext: '<p>Checks data for template actors</p><p>Please note that for a world with many items, the check could take a little time.</p>',
      processfunction: SandboxExtensions_TemplateActorsCheck,
      logtableconfiguration: {}
    };
    new SandboxExtensionsProcessLogForm(options).render(true, {focus: true});
  }

  _onDisplay_SandboxExtensions_Settings(event) {
    event.preventDefault();
    let f = new ModuleSettingsForm();
    f.render(true,{focus:true});
  }

  _onDisplay_SandboxExtensions_KeyChecker(event) {
    event.preventDefault();
    let f = new SandboxKeyCheckerForm();
    f.render(true,{focus:true});
  }

  _onDisplay_SandboxExtensions_ItemStructureChecker(event) {
    event.preventDefault();
    let f = new SandboxItemCheckerForm();
    f.render(true,{focus:true});
  }

}
;

function SandboxExtensions_cItemsCheck() {
  console.log('citem checker');

  for (let i = 0; i < game.items.contents.length; i++) {
    let s_object = game.items.contents[i];
    if (s_object.type == "cItem") {
      console.log(s_object.name + " id:" + s_object.id + " ciKey:" + s_object.data.data.ciKey);
      this.IncItemCount();
    }
  }



}

function SandboxExtensions_TemplateActorsCheck() {
  console.log('template actor checker');
}