// export const needed by ModuleSettingsForm
export const _module_id='sandbox-extensions';  // modules true name(id)
export const _module_ignore_settings=[];       // array of strings containing settings that should not be displayed, can be empty []
// constants
import { ITEMATTRIBUTE } from "./sbe-constants-item.js"
import { TYPECLASS } from "./sbe-constants-item.js"
import { ITEM_SHEET_DEFAULT_HEIGHT } from "./sbe-constants-item.js"
import { ITEM_SHEET_HEIGHT } from "./sbe-constants-item.js"
import { ITEM_SHEET_PROPERTY_HEIGHT } from "./sbe-constants-item.js"
import { ITEM_SHEET_DEFAULT_WIDTH } from "./sbe-constants-item.js"
import { ITEM_SHEET_TABS } from "./sbe-constants-item.js"

// forms  
import { ModuleSettingsForm } from "./module-settings-form.js";
import { SandboxExtensionsToolsForm } from "./sbe-tools-form.js";
import { SandboxExpressionEditorForm } from "./sandbox-expression-editor-form.js";
import { SandboxTableFilterEditorForm } from "./sandbox-table-filter-editor-form.js";
import { SandboxExtensionInfoForm } from "./sbe-info-form.js";

import { sbe_table_filter_passed } from "./sbe-table-filters.js";
import { sbe_property_has_valid_table_filter } from "./sbe-table-filters.js";
import { sbe_string_is_valid_table_filter } from "./sbe-table-filters.js";

import { sbe_settings_menus } from "./sbe-settings-registration.js";
import { sbe_settings_registration } from "./sbe-settings-registration.js";
// Data export functions
import * as itemDataExport from './sbe-item-data-export.js'
// Case handling
import * as stringCasing from './sbe-strings-case.js'
// validate functions
import { INVALID_KEY_CHARACTERS } from "./sandbox-key-validate.js";
import { SandboxKeyValidate } from "./sandbox-key-validate.js";
import { transliterate  } from "./transliteration_2.1.8_bundle.esm.min.js";       
// Sandbox methods to override
import {gActorSheet} from "../../../systems/sandbox/module/gactorsheet.js"
import {sItemSheet} from "../../../systems/sandbox/module/sitemsheet.js"

   
class SandboxExtensions {
  lastItemId='';
  static ID = _module_id ;  // moduleID         

  static SETTINGS =  { 
    AUTOGEN :{                           
      SETTINGS_FORM: 'SETTINGS_FORM',
      KEY_CHECKER_FORM: 'KEY_CHECKER_FORM',
      ITEM_CHECKER_FORM: 'ITEM_CHECKER_FORM',
      TOOLS_FORM:'TOOLS_FORM',
      CITEM_CHECKER_FORM:'CITEM_CHECKER_FORM',

      PREFIX_PROPERTY: 'PREFIX_PROPERTY',
      PREFIX_PROPERTY_SIMPLETEXT: 'PREFIX_PROPERTY_SIMPLETEXT',
      PREFIX_PROPERTY_SIMPLENUMERIC: 'PREFIX_PROPERTY_SIMPLENUMERIC',
      PREFIX_PROPERTY_CHECKBOX: 'PREFIX_PROPERTY_CHECKBOX',
      PREFIX_PROPERTY_RADIO: 'PREFIX_PROPERTY_RADIO',
      PREFIX_PROPERTY_TEXTAREA: 'PREFIX_PROPERTY_TEXTAREA',
      PREFIX_PROPERTY_LIST: 'PREFIX_PROPERTY_LIST',
      PREFIX_PROPERTY_LABEL: 'PREFIX_PROPERTY_LABEL',
      PREFIX_PROPERTY_BADGE: 'PREFIX_PROPERTY_BADGE',
      PREFIX_PROPERTY_TABLE: 'PREFIX_PROPERTY_TABLE',
      PREFIX_PROPERTY_BUTTON: 'PREFIX_PROPERTY_BUTTON',
      PREFIX_PANEL: 'PREFIX_PANEL', 
      PREFIX_MULTIPANEL: 'PREFIX_MULTIPANEL',
      PREFIX_GROUP: 'PREFIX_GROUP',
      PREFIX_TAB: 'PREFIX_TAB',
      SUFFIX_FONTGROUP:'SUFFIX_FONTGROUP',
      SUFFIX_INPUTGROUP:'SUFFIX_INPUTGROUP',
      SUFFIX_HEADERGROUP:'SUFFIX_HEADERGROUP',
      SUFFIX_ROLLID:'SUFFIX_ROLLID', 
      SUFFIX_ROLLNAME:'SUFFIX_ROLLNAME',
      
      OPTION_KEY_CONVERT_TO_CASE:'OPTION_KEY_CONVERT_TO_CASE',
      OPTION_CSS_CONVERT_TO_CASE:'OPTION_CSS_CONVERT_TO_CASE',
      OPTION_ENFORCED_VALIDATION:'OPTION_ENFORCED_VALIDATION',
      OPTION_CONFIRM_BATCH_OVERWRITE:'OPTION_CONFIRM_BATCH_OVERWRITE',
      OPTION_SHOW_ITEM_HELPERS:'OPTION_SHOW_ITEM_HELPERS',
      OPTION_ACTIVATE_ITEM_DELETE_PROTECTION:'OPTION_ACTIVATE_ITEM_DELETE_PROTECTION',
      OPTION_USE_DATATYPE_PREFIX:'OPTION_USE_DATATYPE_PREFIX',
      OPTION_USE_PREFIX_SUFFIX:'OPTION_USE_PREFIX_SUFFIX',
      OPTION_TRANSLITERATE_NON_LATIN:'OPTION_TRANSLITERATE_NON_LATIN',
      OPTION_SET_DEFAULT_ITEM_TAB:'OPTION_SET_DEFAULT_ITEM_TAB',
      OPTION_ADAPT_ITEM_SHEET_POSITION:'OPTION_ADAPT_ITEM_SHEET_POSITION',
      OPTION_DISPLAY_ID_IN_SHEET_CAPTION:'OPTION_DISPLAY_ID_IN_SHEET_CAPTION',
      OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION:'OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION',
      OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS:'OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS',
      OPTION_USE_CITEM_INFO_FORM_FOR_GMS:'OPTION_USE_CITEM_INFO_FORM_FOR_GMS',
      OPTION_USE_CITEM_ICON:'OPTION_USE_CITEM_ICON',
      OPTION_USE_CITEM_ICON_TABLE_SUFFIX:'OPTION_USE_CITEM_ICON_TABLE_SUFFIX',
      SETTING_CITEM_ICON_SIZE:'SETTING_CITEM_ICON_SIZE',
      OPTION_USE_TABLE_FILTERS:'OPTION_USE_TABLE_FILTERS',
      OPTION_DISPLAY_SUBITEMS_ICONS:'OPTION_DISPLAY_SUBITEMS_ICONS',
      SETTING_CATEGORY_CITEM_OPTIONS:'SETTING_CATEGORY_CITEM_OPTIONS',
      SETTING_CATEGORY_ITEM_DELETE_PROTECTION:'SETTING_CATEGORY_ITEM_DELETE_PROTECTION',
      SETTING_CATEGORY_GENERAL_DISPLAY_OPTIONS:'SETTING_CATEGORY_GENERAL_DISPLAY_OPTIONS',
      SETTING_CATEGORY_ITEM_SHEET_OPTIONS:'SETTING_CATEGORY_ITEM_SHEET_OPTIONS',
      SETTING_CATEGORY_AUTOGENERATION_OPTIONS:'SETTING_CATEGORY_AUTOGENERATION_OPTIONS',
      SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES:'SETTING_CATEGORY_AUTOGENERATION_PREFIXES_SUFFIXES',
      SETTING_CATEGORY_KEY_VALIDATION_OPTIONS:'SETTING_CATEGORY_KEY_VALIDATION_OPTIONS',
      SETTING_CATEGORY_SHEET_CAPTION_OPTIONS:'SETTING_CATEGORY_SHEET_CAPTION_OPTIONS',
      SETTING_CATEGORY_GENERAL_OPTIONS:'SETTING_CATEGORY_GENERAL_OPTIONS',
      OPTION_NUMBER:'OPTION_NUMBER',
      OPTION_BOOLEAN:'OPTION_BOOLEAN',
      OPTION_FILEPICKER:'OPTION_FILEPICKER'
    }
  }    

  static DEFAULT_SETTINGS={  
    AUTOGEN :{
      PREFIX_PROPERTY: 'PROPERTY',
      PREFIX_PROPERTY_SIMPLETEXT: 'TXT',
      PREFIX_PROPERTY_SIMPLENUMERIC: 'NUM',
      PREFIX_PROPERTY_CHECKBOX: 'CHK',
      PREFIX_PROPERTY_RADIO: 'RDO',
      PREFIX_PROPERTY_TEXTAREA: 'TXA',
      PREFIX_PROPERTY_LIST: 'LST',
      PREFIX_PROPERTY_LABEL: 'LBL',
      PREFIX_PROPERTY_BADGE: 'BDG',
      PREFIX_PROPERTY_TABLE: 'TBL',
      PREFIX_PROPERTY_BUTTON: 'BTN',
      PREFIX_PANEL: 'PANEL', 
      PREFIX_MULTIPANEL: 'MULTIPANEL',
      PREFIX_GROUP: 'GROUP',
      PREFIX_TAB: 'TAB',
      SUFFIX_FONTGROUP:'FONTGROUP',
      SUFFIX_INPUTGROUP:'INPUTGROUP',
      SUFFIX_HEADERGROUP:'HEADERGROUP',
      SUFFIX_ROLLID:'ROLL',
      SUFFIX_ROLLNAME:'Roll',
      OPTION_KEY_CONVERT_TO_CASE:2,
      OPTION_CSS_CONVERT_TO_CASE:1,
      OPTION_ENFORCED_VALIDATION:'', // empty means false, non-empty is true
      OPTION_CONFIRM_BATCH_OVERWRITE:true,
      OPTION_SHOW_ITEM_HELPERS:true,
      OPTION_ACTIVATE_ITEM_DELETE_PROTECTION:true,
      OPTION_USE_DATATYPE_PREFIX:true,
      OPTION_USE_PREFIX_SUFFIX:true,
      OPTION_TRANSLITERATE_NON_LATIN:true,
      OPTION_SET_DEFAULT_ITEM_TAB:true,
      OPTION_ADAPT_ITEM_SHEET_POSITION:true,
      OPTION_DISPLAY_ID_IN_SHEET_CAPTION:'',
      OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS:true,
      OPTION_USE_CITEM_INFO_FORM_FOR_GMS:true,
      OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION:true,
      OPTION_USE_CITEM_ICON:true,
      OPTION_USE_CITEM_ICON_TABLE_SUFFIX:'',
      SETTING_CITEM_ICON_SIZE:26,
      OPTION_USE_TABLE_FILTERS:'', // empty means false
      OPTION_DISPLAY_SUBITEMS_ICONS:true
    }
  }      
  //                                                                  
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  //                                                                  
  //                          Class Methods                           
  //                                                                  
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  //                                                                  

  // ---------------------------------------------------------------- 
  // Initialize                                                       
  // ----------------------------------------------------------------     
  static initialize() { 
    // ---------------------------------------------------------------- 
    // Settings registrations for menus in Settings form                                           
    // ----------------------------------------------------------------  
    sbe_settings_menus(this);
    // ---------------------------------------------------------------- 
    // Settings registrations for module                                           
    // ----------------------------------------------------------------  
    sbe_settings_registration(this);
     
                             
    
    console.log('SBE  | Register Handlebar Helper');
    Handlebars.registerHelper('eachProperty', function(context, options) {      
        var ret = "";
        for(var prop in context)
        {
          if(context.hasOwnProperty(prop)){
            ret = ret + options.fn({property:prop.toString(),value:context[prop]});
          }
        }
        return ret;
    });
    Handlebars.registerHelper('sbe_concat', function() {
      var outStr = '';
      for (var arg in arguments) {
        if (typeof arguments[arg] != 'object') {
          outStr += arguments[arg];
        }
      }
      return outStr;
    });
    
  }
} 
   

   
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       SBE Sandbox overrides                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
// 

function sbe_sandbox_overrides(){
  sbe_sheet_override_sandbox_hook_render_actor();
  sbe_sheet_override_sandbox_hook_render_item();
 }
  
  
function sbe_sheet_override_sandbox_hook_render_actor(){    
  if (sbe_running_required_game_system('sandbox','0.13.1')){    
    // for SB 0.13.1, Seregras added custom  overide functions to easily use
    console.log('SBE   | sbe_sheet_override_sandbox_hook_render_actor using gActorSheet.prototype.customCallOverride');
    gActorSheet.prototype.customCallOverride = async function(basehtml) {
      sbe_sheet_actor_options_after_ready(basehtml);
    };
  } else if (sbe_running_required_game_system('sandbox','0.10.5')){
    // as of SB 0.12.8, this uses the actorsheet method of addHeaderButtons
    // since this is an "empty" method(only contains comments)
    console.log('SBE   | sbe_sheet_override_sandbox_hook_render_actor using gActorSheet.prototype.addHeaderButtons');
    gActorSheet.prototype.addHeaderButtons = async function(basehtml) {
      sbe_sheet_actor_options_after_ready(basehtml);
    };
  } else {
    console.warn('SBE  | Running Sandbox version to old for overriding actor render');
  }
}

function sbe_sheet_override_sandbox_hook_render_item(){
  if (sbe_running_required_game_system('sandbox','0.13.1')){ 
    // for SB 0.13.1, Seregras added custom  overide functions to easily use
    console.log('SBE   | sbe_sheet_override_sandbox_hook_render_item using sItemSheet.prototype.customCallOverride');
    sItemSheet.prototype.customCallOverride = async function(basehtml) {
      sbe_sheet_item_options_after_ready(basehtml);
    };
  } else if (sbe_running_required_game_system('sandbox','0.10.5')){
    // make a complete override with original code and adition
    console.log('SBE   | sbe_sheet_override_sandbox_hook_render_item using sItemSheet.prototype.scrollBarTest');
    sItemSheet.prototype.scrollBarTest = async function(basehtml) {
      // start original code
      const wcontent = await this._element[0].getElementsByClassName("window-content");
      let newheight = parseInt(wcontent[0].offsetHeight) - 152;
      const html = await basehtml.find(".scrollable");
      for (let i = 0; i < html.length; i++) {
          let scrollNode = html[i];
          scrollNode.style.height = newheight + "px";
      }
      // end original code
      
      // add the custom override code
      sbe_sheet_item_options_after_ready(basehtml);
    };
  } else {
    console.warn('SBE  | Running Sandbox version to old for overriding actor render');
  }
}

function sbe_sheet_actor_options_after_ready(html){
  console.warn('SBE  | sbe_sheet_actor_options_after_ready');
  //console.warn(html);
  // IN development, commented on SBE 0.4.2
  sbe_sheet_actor_filter_tables(html);
  

  sbe_sheet_item_delete_protection(html);
  sbe_sheet_use_citem_info_form(html);
  sbe_sheet_use_citem_icon(html);
  
}

function sbe_sheet_item_options_after_ready(html){
  sbe_sheet_item_delete_protection(html);  
}

//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       SBE hook functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//

Hooks.once('init', () => {     
    SandboxExtensions.initialize();
    sbe_sandbox_overrides();
    
  });

Hooks.once("ready", () => {
  game.socket.on("module.sandbox-extensions", sbe_socket_manager);
});

Hooks.on("updateModuleSetting", async(moduleId) => {
  //console.warn('SBE  | updateModuleSetting:' + moduleId);
  if(moduleId==_module_id){
    // get specific settings that need special handling
    const SETTING_CITEM_ICON_SIZE = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SETTING_CITEM_ICON_SIZE);
    let root = document.querySelector(':root');  
    let rootStyles = getComputedStyle(root);  
    let iconsize = rootStyles.getPropertyValue('--sbe-table-citem-icon-size');    
    if (SETTING_CITEM_ICON_SIZE>=0) {   
      root.style.setProperty('--sbe-table-citem-icon-size', SETTING_CITEM_ICON_SIZE + 'px');
    }
    // check all open windows
    for (let app in ui.windows){
      // if actor or item sheet
      if(ui.windows[app].options.baseApplication=='ActorSheet' || ui.windows[app].options.baseApplication=='ItemSheet'){
        // render the sheet
        ui.windows[app].render(true);
      }
    }
  }
});

Hooks.on("updateItem", async(item, updateData, options, userId) => {
  // console.warn('SBE  | updateItem');
  // check if update was for table property
  try{
    // check if property
    if(item.data.type=='property'){
      // check if table
      if(item.data.data.datatype=='table'){
        // check if it was for tooltip
        //console.warn(updateData);
        if(updateData.data.hasOwnProperty('tooltip')){
          //console.warn('updateItem: table tooltip');
          // force rerender on all open actor sheets
          // check all open windows
          for (let app in ui.windows){
            // if actor or item sheet
            if(ui.windows[app].options.baseApplication=='ActorSheet'){
              // render the sheet
              ui.windows[app].render(true);
            }
          }
        }
      }
    }
  } catch (err) {
    console.error('SBE   | updateItem Err:' + err.message);
  }
});


// In development, commented on 4.2
Hooks.on("preUpdateActor", async(actor, updateData, options, userId) => {
  console.warn('SBE  | preUpdateActor');
});
// In development, commented on 4.2
Hooks.on("updateActor", async(actor, updateData, options, userId) => {
  console.warn('SBE  | updateActor');
  
  //sbe_sheet_actor_filter_tables_totals(actor);
});

Hooks.on("updategActor", async(actor, updateData, options, userId) => {
  console.warn('SBE  | updategActor');
  
  //sbe_sheet_actor_filter_tables_totals(actor);
});


Hooks.on('renderItemSheet', (gItemSheet, html) => {
  // Some things in the actor sheet are not fully populated at render, 
  // Overrides of sandbox methods are used to intercept them
  
  sbe_sheet_display_id_in_window_caption(html,'ITEM', gItemSheet.id.replace('item-',''));
  sbe_sheet_display_show_to_others_in_sheet_caption(html,'ITEM', gItemSheet.id.replace('item-',''),true,'sbe-info-form-show-all');
  const OPTION_USE_TABLE_FILTERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS);      
  const showitemhelpers = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS);
  if (showitemhelpers && game.user.isGM) {
    let itemName;    
    let hasKey = false;
    let hasTag = false;
    let hasTooltip = false;
    let hasFontGroup = false;
    let hasInputGroup = false;
    let hasHeaderGroup = false;
    let hasRollExp = false;
    let hasRollName = false;
    let hasRollID = false;
    let hasAuto = false;
    let hasAutoMax = false;
    let hasDefault = false;
    let hasCheckGroup = false;
    let hasList = false;
    let hasConditionVisibleIf = false;
    let hasConditionVisibleValue = false;
    let hasDataType=false;
    let detailstabname='details';
    
//    let lielement;
//    let subitemid;
//    let subitem;
//    let subitemslist;
//    let containeritem;

    let itemid = gItemSheet.object.data._id;
    if (itemid != '') {
      SandboxExtensions.lastItemId = itemid;
    } else {
      // cant get the itemid
      console.error("SandboxExtensions || Cant get itemid, reusing last from class object");
      itemid = SandboxExtensions.lastItemId;
    }
    
    // get the name of the item
    itemName = sbe_item_sheet_get_input(html, 'name', 'ITEM')[0].value;
    // find typeclass
    const typeClass = html.find(`${ITEMATTRIBUTE.ITEM.TYPECLASS.IDENTIFIER}`)[0].innerText;
    let sheetheight=ITEM_SHEET_HEIGHT[typeClass]; 
    let propertydatatype='';
    // depending on typeclass
    switch (typeClass) {
      case 'PROPERTY':        
        hasKey = true;
        hasTag = true;
        hasTooltip = true;
        hasFontGroup = true;
        hasInputGroup = true;
        hasRollExp = true;
        hasRollName = true;
        hasRollID = true;
        hasAuto = true;
        hasAutoMax = true;
        hasDefault = true;
        hasCheckGroup = true;
        hasList = true;
        hasDataType=true;
        propertydatatype = sbe_item_sheet_get_input(html, ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE, 'PROPERTY')[0].value;
        break;
      case "MULTIPANEL":
        hasKey = true;
        hasTag = true;
        hasHeaderGroup = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;        
        sbe_sheet_display_subitems_icons(html,'h4.property-name',gItemSheet.item,gItemSheet.item.data.data.panels);        
        break;
      case "PANEL":
        hasKey = true;
        hasTag = true;
        hasFontGroup = true;
        hasInputGroup = true;
        hasHeaderGroup = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;
        sbe_sheet_display_subitems_icons(html,'h4.property-name',gItemSheet.item,gItemSheet.item.data.data.properties);
        break;
      case "TAB":
        hasKey = true;
        hasTag = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;
        sbe_sheet_display_subitems_icons(html,'h4.property-name',gItemSheet.item,gItemSheet.item.data.data.panels);                
        break;
      case "GROUP":
        hasKey = true;        
        sbe_sheet_display_subitems_icons(html,'h4.group-name',gItemSheet.item,gItemSheet.item.data.data.properties);        
        break;
      case "cITEM":
        if (game.user.isGM) {
          hasRollExp = true;
          hasRollName = true;
          hasRollID = true;
        }
        detailstabname='attributes';        
        sbe_sheet_display_subitems_icons(html,'h4.property-name',gItemSheet.item,gItemSheet.item.data.data.groups);        
        break;
      default:
      // nothing
    }
   
    
    const adaptitemsheetgeometrics = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION);
    if (adaptitemsheetgeometrics) {
      if (game.user.isGM) {
        // make room for details menu by  increasing the item sheet window height                    
        // for updates the return html is a form
        if (html[0].nodeName !== 'FORM') {
          if (typeClass === 'PROPERTY') {
            const datatype = sbe_item_sheet_get_input(html, ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE, 'PROPERTY')[0].value;
            sheetheight = ITEM_SHEET_PROPERTY_HEIGHT[datatype.toUpperCase()];
          }
          // center window
          let newtop = (window.innerHeight - (sheetheight)) / 2;
          if (newtop < 0) {
            newtop = 0;
          }
          gItemSheet.setPosition({top: newtop});
          gItemSheet.setPosition({height: sheetheight, width: ITEM_SHEET_DEFAULT_WIDTH});
        }
      }
    }
  
    const setdefaultitemtab = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB);
    if (setdefaultitemtab ) {
      if (game.user.isGM) {
        if (html[0].nodeName !== 'FORM') {
          // activate tab
          gItemSheet._tabs[0].activate(detailstabname);
        }
      }
    }
    // ---------------------------------------------------------------- 
    // details menu     
    // ----------------------------------------------------------------
    let elementDetails = 'div[data-tab="details"]> div:nth-child(1)';
  
    let divDetails = html.find(`${elementDetails}`);
    if (divDetails != null && divDetails.length > 0) {

      let sMenu = `        
            <div class="sbe-sheet-item-menu"> 
              <label id="sbe-action-menu-autogenerate-all-visible-fields" class="sbe-action-menu-label" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-autogenerate-all-visible-fields-tooltip') + `"><i class="fas fa-magic"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-autogenerate-all-visible-fields-caption') + `</label>
              <label id="sbe-action-menu-validate-all-visible-fields" class="sbe-action-menu-label" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-validate-all-visible-fields-tooltip') + `"><i class="fas fa-spell-check"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-validate-all-visible-fields-caption') + `</label>
               `
              + sbe_item_sheet_dropdown_header(itemid, 'exports', 'Copy As', 'fas fa-copy')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-html', 'fab fa-html5')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-markdown', 'fab fa-markdown')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-plaintext', 'fas fa-table')
              + sbe_item_sheet_dropdown_footer()
              + `
              <label id="sbe-action-menu-clear-all-visible-fields" class="sbe-action-menu-label" style="" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-clear-all-visible-fields-tooltip') + `"><i class="fas fa-times-circle"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-clear-all-visible-fields-caption') + `</label>          
              <label id="sbe-item-sheet-display-sandbox-extensions-config" class="sbe-action-menu-label" style="" title="` + game.i18n.localize('sandbox-extensions.sbe-item-sheet-display-sandbox-extensions-config-tooltip') + `"><i class="fas fa-cog"></i> ` + game.i18n.localize('sandbox-extensions.sbe-item-sheet-display-sandbox-extensions-config-caption') + `</label>

            </div>
            <div class="sbe-sheet-item-menu-placeholder"></div> `;
      divDetails.before(sMenu);
      let sAttribute = 'exports';
      // register event listeners for labels 
      html.find('#sbe-item-sheet-display-sandbox-extensions-config').click(ev => {
        let f = new ModuleSettingsForm();
        f.render(true,{focus:true});
      });
      // auto generate all       
      html.find('#sbe-action-menu-autogenerate-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        sbe_item_sheet_autogenerate_all(gItemSheet,html, typeClass);
      });
      // validate all
      html.find('#sbe-action-menu-validate-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        switch (typeClass) {
          case 'PROPERTY':
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
            if(propertydatatype=='table' && OPTION_USE_TABLE_FILTERS){
              sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP, typeClass, itemid);
            }
            break;
          case "MULTIPANEL":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "PANEL":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "TAB":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "GROUP":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "cITEM":
            break;
          default:
            break;
        }
      });
      // clear all
      html.find('#sbe-action-menu-clear-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        sbe_item_sheet_clear_all(gItemSheet,html, typeClass);
      });
      // register event listeners for dropdown      
      let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
      let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
      // register event listeners for dropdown items
      html.find('.sbe-export-copy-visible-as-html').click(ev => {
        itemDataExport.sbe_item_sheet_export_data_html(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
      html.find('.sbe-export-copy-visible-as-markdown').click(ev => {
        itemDataExport.sbe_item_sheet_export_data_markdown(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
      html.find('.sbe-export-copy-visible-as-plaintext').click(ev => {
        itemDataExport.sbe_item_sheet_export_data_plaintext(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
    }
    // ---------------------------------------------------------------- 
    // Item Name                                                              
    // ---------------------------------------------------------------- 
    let inputName=sbe_item_sheet_get_input(html,'name','ITEM');
    if (inputName != null && inputName.length > 0) {
      sbe_item_sheet_set_title_from_value(inputName);
      // special adaption of input width style
      inputName[0].style.width='calc(100% - 30px )';
      let sDropDown = sbe_item_sheet_dropdown_header(itemid, ITEMATTRIBUTE.ITEM.NAME.ATTRIBUTE, '', '', inputName)
                + sbe_item_sheet_dropdown_item('sbe-uppercase-name', 'fas fa-angle-double-up','uppercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-lowercase-name', 'fas fa-angle-double-down','lowercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-titlecase-name', 'fas fa-angle-up','titlecase.svg')
                + sbe_item_sheet_dropdown_item('sbe-cut-name', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-name', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-name', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-name', 'fas fa-times-circle');
        
      inputName.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE.ITEM.NAME.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        html.find('.sbe-uppercase-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE.ITEM.NAME,stringCasing.CASING.CASE.UPPERCASE);          
        });
        html.find('.sbe-lowercase-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE.ITEM.NAME,stringCasing.CASING.CASE.LOWERCASE);          
        });
        html.find('.sbe-titlecase-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE.ITEM.NAME,stringCasing.CASING.CASE.TITLECASE);          
        });
        
        html.find('.sbe-cut-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE.ITEM.NAME);
        });
        html.find('.sbe-copy-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE.ITEM.NAME);
        });
        html.find('.sbe-paste-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE.ITEM.NAME);
        });
        html.find('.sbe-clear-name').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE.ITEM.NAME.IDENTIFIER);
        });
        
    }
    // ---------------------------------------------------------------- 
    // Key                                                              
    // ----------------------------------------------------------------                 
    if (hasKey) {
      // find the element which the key
     let inputKey = sbe_item_sheet_get_input(html, 'key', typeClass);
      
      if (inputKey != null && inputKey.length > 0) {
        sbe_item_sheet_set_title_from_value(inputKey);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.ATTRIBUTE, '', '', inputKey)
                + sbe_item_sheet_dropdown_item('sbe-generate-key', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-validate-key', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-uppercase-key', 'fas fa-angle-double-up','uppercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-lowercase-key', 'fas fa-angle-double-down','lowercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-titlecase-key', 'fas fa-angle-up','titlecase.svg') 
                + sbe_item_sheet_dropdown_item('sbe-cut-key', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-key', 'fas fa-copy');
        if (typeClass.toUpperCase() === 'PROPERTY') {
          sDropDown += sbe_item_sheet_dropdown_item('sbe-copy-key-as-actor-property', 'fas fa-at')
                  + sbe_item_sheet_dropdown_item('sbe-copy-key-as-citem-property', 'fas fa-hashtag')
                  + sbe_item_sheet_dropdown_item('sbe-copy-key-as-dialog-property', 'far fa-window-maximize', 'd.svg');
        }
        sDropDown += sbe_item_sheet_dropdown_item('sbe-paste-key', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-key', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputKey.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items   
        html.find('.sbe-generate-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass);
        });
        html.find('.sbe-validate-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
        });
        
        html.find('.sbe-uppercase-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,stringCasing.CASING.CASE.UPPERCASE);          
        });
        html.find('.sbe-lowercase-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,stringCasing.CASING.CASE.LOWERCASE);          
        });
        html.find('.sbe-titlecase-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,stringCasing.CASING.CASE.TITLECASE);          
        });
        
        
        html.find('.sbe-cut-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-actor-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_actor_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-citem-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_citem_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-dialog-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_dialog_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-paste-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-clear-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()][sAttribute.toUpperCase()].IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // dataType                                                          
    // ----------------------------------------------------------------  
    if(hasDataType){
      
      let inputDataType = sbe_item_sheet_get_input(html, 'datatype', typeClass);
      if (inputDataType != null && inputDataType.length > 0) {
        // insert a dropdown at the end of this element
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].DATATYPE.ATTRIBUTE;
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'datatype','','',inputDataType)
                + sbe_item_sheet_dropdown_item('sbe-generate-property-icon', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-reset-property-icon', 'fas fa-magic','anti-clockwise-rotation.svg')
                + sbe_item_sheet_dropdown_footer();
        inputDataType.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-property-icon').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_icon(html);
        });
        html.find('.sbe-reset-property-icon').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_icon(html,true);
        });
      }
    }

    // ---------------------------------------------------------------- 
    // Default Value                                                          
    // ----------------------------------------------------------------  
    if (hasDefault) {
      // find the element which has the value
      let inputDefault = sbe_item_sheet_get_input(html, 'default', typeClass);      
      if (inputDefault != null && inputDefault.length > 0) {
        sbe_item_sheet_set_title_from_value(inputDefault);
        // insert a dropdown at the end of this element
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.ATTRIBUTE;
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'default','','',inputDefault)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-default', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-default', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-default', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-default', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-default', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputDefault.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-open-expression-editor-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT, typeClass, itemid);
        });
        html.find('.sbe-cut-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
        html.find('.sbe-copy-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
        html.find('.sbe-clear-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.IDENTIFIER);
        });
        html.find('.sbe-paste-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Tag/Title                                                        
    // ---------------------------------------------------------------- 
    if (hasTag) {
      // find the element
      let inputTag = sbe_item_sheet_get_input(html, 'tag', typeClass);
      if (inputTag != null && inputTag.length > 0) {
        sbe_item_sheet_set_title_from_value(inputTag);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'tag','','',inputTag)
                + sbe_item_sheet_dropdown_item('sbe-generate-tag', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-uppercase-tag', 'fas fa-angle-double-up','uppercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-lowercase-tag', 'fas fa-angle-double-down','lowercase.svg')
                + sbe_item_sheet_dropdown_item('sbe-titlecase-tag', 'fas fa-angle-up','titlecase.svg') 
                + sbe_item_sheet_dropdown_item('sbe-cut-tag', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-tag', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-tag', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-tag', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputTag.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG, typeClass);
        });
        
        html.find('.sbe-uppercase-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,stringCasing.CASING.CASE.UPPERCASE);          
        });
        html.find('.sbe-lowercase-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,stringCasing.CASING.CASE.LOWERCASE);          
        });
        html.find('.sbe-titlecase-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,stringCasing.CASING.CASE.TITLECASE);          
        });
        
        html.find('.sbe-cut-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-copy-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-paste-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-clear-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Tooltip                                                          
    // ----------------------------------------------------------------    
    if (hasTooltip) {
      // find the element
      let inputTooltip = sbe_item_sheet_get_input(html, 'tooltip', typeClass);
      if (inputTooltip != null && inputTooltip.length > 0) {
        sbe_item_sheet_set_title_from_value(inputTooltip);
        let sDropDown;
        if(propertydatatype=='table' && typeClass.toUpperCase() === 'PROPERTY' && OPTION_USE_TABLE_FILTERS){
          // change the label
          let objLabel = inputTooltip[0].previousElementSibling;
          objLabel.innerHTML='Table Filter';
          // insert a dropdown at the end of this element
          sDropDown = sbe_item_sheet_dropdown_header(itemid, 'tooltip','','',inputTooltip)                  
                  + sbe_item_sheet_dropdown_item('sbe-open-table-filter-editor-table-filter', 'fas fa-edit')
                  + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-table-filter', 'fas fa-code')
                  + sbe_item_sheet_dropdown_item('sbe-validate-table-filter', 'fas fa-spell-check')
                  + sbe_item_sheet_dropdown_item('sbe-cut-table-filter', 'fas fa-cut')
                  + sbe_item_sheet_dropdown_item('sbe-copy-table-filter', 'fas fa-copy')
                  + sbe_item_sheet_dropdown_item('sbe-paste-table-filter', 'fas fa-paste')
                  + sbe_item_sheet_dropdown_item('sbe-clear-table-filter', 'fas fa-times-circle')
                  + sbe_item_sheet_dropdown_footer();
        } else {
          // insert a dropdown at the end of this element
          sDropDown = sbe_item_sheet_dropdown_header(itemid, 'tooltip','','',inputTooltip)
                  + sbe_item_sheet_dropdown_item('sbe-generate-tooltip', 'fas fa-magic')
                  + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-tooltip', 'fas fa-code')
                  + sbe_item_sheet_dropdown_item('sbe-uppercase-tooltip', 'fas fa-angle-double-up','uppercase.svg')
                  + sbe_item_sheet_dropdown_item('sbe-lowercase-tooltip', 'fas fa-angle-double-down','lowercase.svg')
                  + sbe_item_sheet_dropdown_item('sbe-titlecase-tooltip', 'fas fa-angle-up','titlecase.svg') 
                  + sbe_item_sheet_dropdown_item('sbe-cut-tooltip', 'fas fa-cut')
                  + sbe_item_sheet_dropdown_item('sbe-copy-tooltip', 'fas fa-copy')
                  + sbe_item_sheet_dropdown_item('sbe-paste-tooltip', 'fas fa-paste')
                  + sbe_item_sheet_dropdown_item('sbe-clear-tooltip', 'fas fa-times-circle')
                  + sbe_item_sheet_dropdown_footer();
        }
        inputTooltip.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        if(propertydatatype=='table' && typeClass.toUpperCase() === 'PROPERTY' && OPTION_USE_TABLE_FILTERS){
          html.find('.sbe-open-table-filter-editor-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER, typeClass, itemid,propertydatatype,OPTION_USE_TABLE_FILTERS);
          });
          html.find('.sbe-open-expression-editor-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER, typeClass, itemid,propertydatatype);
          });
          html.find('.sbe-validate-table-filter').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP, typeClass, itemid);
        });
          html.find('.sbe-cut-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER);
          });
          html.find('.sbe-copy-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER);
          });
          html.find('.sbe-paste-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER);
          });
          html.find('.sbe-clear-table-filter').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TABLEFILTER.IDENTIFIER);
          });
          
          
          
        } else {        
          // register event listeners for dropdown items 
          html.find('.sbe-generate-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP, typeClass);
          });
          html.find('.sbe-open-expression-editor-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP, typeClass, itemid,propertydatatype,OPTION_USE_TABLE_FILTERS);
          });
          html.find('.sbe-uppercase-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP,stringCasing.CASING.CASE.UPPERCASE);          
          });
          html.find('.sbe-lowercase-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP,stringCasing.CASING.CASE.LOWERCASE);          
          });
          html.find('.sbe-titlecase-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_changecase_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP,stringCasing.CASING.CASE.TITLECASE);          
          });
          html.find('.sbe-cut-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
          });
          html.find('.sbe-copy-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
          });
          html.find('.sbe-paste-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
          });
          html.find('.sbe-clear-tooltip').click(ev => {
            sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
            sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.IDENTIFIER);
          });
        }
      }
    }
    // ---------------------------------------------------------------- 
    // Roll Name                                                        
    // ----------------------------------------------------------------  
    if (hasRollName) {
      // find roll name
      let inputRollName = sbe_item_sheet_get_input(html, 'rollname', typeClass);
      if (inputRollName != null && inputRollName.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollName);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollname','','',inputRollName)
                + sbe_item_sheet_dropdown_item('sbe-generate-rollname', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollname', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollname', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollname', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollname', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollname', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollName.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items        
        html.find('.sbe-generate-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME, typeClass);
        });
        html.find('.sbe-open-expression-editor-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME, typeClass, itemid);
        });
        html.find('.sbe-cut-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-copy-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-paste-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-clear-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Roll ID                                                          
    // ----------------------------------------------------------------     
    if (hasRollID) {
      // find roll id
      let inputRollID = sbe_item_sheet_get_input(html, 'rollid', typeClass);
      if (inputRollID != null && inputRollID.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollID);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollid','','',inputRollID)
                + sbe_item_sheet_dropdown_item('sbe-generate-rollid', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollid', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollid', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollid', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollid', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollid', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollID.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items         
        let sBase;
        html.find('.sbe-generate-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID, typeClass);
        });
        html.find('.sbe-open-expression-editor-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID, typeClass, itemid);
        });
        html.find('.sbe-cut-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-copy-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-paste-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-clear-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Roll Formula/Expression                                          
    // ----------------------------------------------------------------  
    if (hasRollExp) {
      // find roll exp element
      let inputRollExp = sbe_item_sheet_get_input(html, 'rollexp', typeClass);
      if (inputRollExp != null && inputRollExp.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollExp);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollexp','','',inputRollExp)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollexp', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollexp', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollexp', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollexp', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollexp', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollExp.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items               
        html.find('.sbe-open-expression-editor-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP, typeClass, itemid);
        });
        html.find('.sbe-cut-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-copy-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-paste-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-clear-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Max Value                                                        
    // ---------------------------------------------------------------- 
    if (hasAutoMax) {
      // find field max
      let inputAutoMax = sbe_item_sheet_get_input(html, 'automax', typeClass);
      if (inputAutoMax != null && inputAutoMax.length > 0) {
        sbe_item_sheet_set_title_from_value(inputAutoMax);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'automax','','',inputAutoMax)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-automax', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-automax', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-automax', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-automax', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-automax', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputAutoMax.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items   
        html.find('.sbe-open-expression-editor-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX, typeClass, itemid);
        });
        html.find('.sbe-cut-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-copy-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-paste-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-clear-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Auto                                                             
    // ----------------------------------------------------------------        
    if (hasAuto) {
      // find field auto
      let inputAuto = sbe_item_sheet_get_input(html, 'auto', typeClass);
      if (inputAuto != null && inputAuto.length > 0) {
        sbe_item_sheet_set_title_from_value(inputAuto);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'auto','','',inputAuto)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-auto', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-auto', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-auto', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-auto', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-auto', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputAuto.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items     
        html.find('.sbe-open-expression-editor-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO, typeClass, itemid);
        });
        html.find('.sbe-cut-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-copy-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-paste-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-clear-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Check Group                                                      
    // ---------------------------------------------------------------- 
    if (hasCheckGroup) {
      // find the check group element
      let inputCheckGroup = sbe_item_sheet_get_input(html, 'checkgroup', typeClass);
      if (inputCheckGroup != null && inputCheckGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputCheckGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'checkgroup','','',inputCheckGroup)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-checkgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-validate-checkgroup', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-cut-checkgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-checkgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-checkgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-checkgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputCheckGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items 
        html.find('.sbe-open-expression-editor-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
        });
        html.find('.sbe-validate-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-copy-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-paste-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-clear-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // List(Options)                                                    
    // ---------------------------------------------------------------- 
    if (hasList) {
      // find the element which has the value
      let inputList = sbe_item_sheet_get_input(html, 'list', typeClass);
      if (inputList != null && inputList.length > 0) {
        sbe_item_sheet_set_title_from_value(inputList);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'list','','',inputList)
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-list', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-validate-list', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-cut-list', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-list', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-list', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-list', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputList.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-open-expression-editor-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
        });
        html.find('.sbe-validate-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
        });
        html.find('.sbe-cut-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-copy-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-paste-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-clear-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Font Group                                                       
    // ----------------------------------------------------------------                             
    if (hasFontGroup) {
      // find the element
      let inputFontGroup = sbe_item_sheet_get_input(html, 'fontgroup', typeClass);
      if (inputFontGroup != null && inputFontGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputFontGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'fontgroup','','',inputFontGroup)
                + sbe_item_sheet_dropdown_item('sbe-generate-fontgroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-fontgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-fontgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-fontgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-fontgroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-fontgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-fontgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputFontGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP, typeClass);
        });
        html.find('.sbe-open-expression-editor-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-copy-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-copy-fontgroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-paste-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-clear-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Input Group                                                      
    // ---------------------------------------------------------------- 
    if (hasInputGroup) {
      // find the element
      let inputInputGroup = sbe_item_sheet_get_input(html, 'inputgroup', typeClass);
      if (inputInputGroup != null && inputInputGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputInputGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'inputgroup','','',inputInputGroup)
                + sbe_item_sheet_dropdown_item('sbe-generate-inputgroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-inputgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-inputgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-inputgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-inputgroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-inputgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-inputgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputInputGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP, typeClass,true,propertydatatype);
        });
        html.find('.sbe-open-expression-editor-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-copy-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-copy-inputgroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-paste-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-clear-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Header Group                                                     
    // ---------------------------------------------------------------- 
    if (hasHeaderGroup) {
      // find the header group element
      let inputHeaderGroup = sbe_item_sheet_get_input(html, 'headergroup', typeClass);
      if (inputHeaderGroup != null && inputHeaderGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputHeaderGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'headergroup','','',inputHeaderGroup)
                + sbe_item_sheet_dropdown_item('sbe-generate-headergroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-headergroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-headergroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-headergroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-headergroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-headergroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-headergroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputHeaderGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP, typeClass);
        });
        html.find('.sbe-open-expression-editor-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-copy-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-copy-headergroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-paste-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-clear-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER);
        });
      }
    }
    // condistion visible
    if (hasConditionVisibleIf) {
      // find the visibleif element
      let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.ATTRIBUTE;
      let inputVisibleIf = sbe_item_sheet_get_input(html, sAttribute, typeClass);
      if (inputVisibleIf != null && inputVisibleIf.length > 0) 
        sbe_item_sheet_set_title_from_value(inputVisibleIf);{
        // adapt size
        inputVisibleIf[0].style.width = 'calc(100% - 25px)';
        // 
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, sAttribute,'','',inputVisibleIf)
                + sbe_item_sheet_dropdown_item('sbe-cut-' + sAttribute, 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-' + sAttribute, 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-' + sAttribute, 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-' + sAttribute, 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputVisibleIf.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-cut-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });
        html.find('.sbe-copy-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });

        html.find('.sbe-paste-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });
        html.find('.sbe-clear-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER);
        });
      }
    }
    if (hasConditionVisibleValue) {
      // find the visibleif element
      let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.ATTRIBUTE;
      let inputVisibleValue = sbe_item_sheet_get_input(html, sAttribute, typeClass);
      if (inputVisibleValue != null && inputVisibleValue.length > 0) {
        sbe_item_sheet_set_title_from_value(inputVisibleValue);
        // adapt size, special one
        inputVisibleValue[0].style.width = 'calc(100% - 25px)';
        // 
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, sAttribute,'','',inputVisibleValue)
                + sbe_item_sheet_dropdown_item('sbe-cut-' + sAttribute, 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-' + sAttribute, 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-' + sAttribute, 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-' + sAttribute, 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputVisibleValue.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-cut-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });
        html.find('.sbe-copy-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });

        html.find('.sbe-paste-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });
        html.find('.sbe-clear-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER);
        });
      }
    }
  }
});

Hooks.on("rendergActorSheet",async (gActorSheet, html) => {  
  console.warn('SBE  | rendergActorSheet');
  sbe_sheet_change_inputs_to_number_type(html);
  
  sbe_sheet_display_id_in_window_caption(html,'ACTOR', gActorSheet.id.replace('actor-',''));
  sbe_sheet_display_show_to_others_in_sheet_caption(html,'ACTOR', gActorSheet.id.replace('actor-',''),true,'sbe-info-form-show-all');
  
   
  if(gActorSheet.actor.data.data.istemplate){
    sbe_sheet_item_delete_protection(html);
    // tabs
    sbe_sheet_display_subitems_icons(html,'div.tab.properties > ol > li > h4.property-name',gActorSheet.actor,gActorSheet.actor.data.data.tabs);
    // citems
    sbe_sheet_display_subitems_icons(html,'div.tab.citems > ol > li > h4.property-name',gActorSheet.actor,gActorSheet.actor.data.data.citems);    
  } else {
    sbe_sheet_display_subitems_icons(html,'div.tab.citems > ol > li > h4.property-name',gActorSheet.actor,gActorSheet.actor.data.data.citems);
  }
});




Hooks.on("renderActorSheet",async (gActorSheet, html) => {  
  console.warn('SBE  | renderActorSheet');
  sbe_sheet_actor_filter_tables_totals(gActorSheet.actor); 
});





Hooks.on("renderSandboxExtensionInfoForm",async (app, html,data) => {  
  sbe_sheet_display_show_to_others_in_sheet_caption(html,app.info.type, app.info.id);
  await app.scrollBarTest(html);
  
  html.find('.window-resizable-handle').mouseup(ev => {
        ev.preventDefault();
        app.scrollBarTest(html);
    });
  
});

Hooks.on("renderChatMessage", async (app, html, data) => { 
  // look for citem-links class roll-citemlink
  let citemlink=$(html).find(".roll-citemlink")[0];
  if(citemlink!=null){ 
    const OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS);  
    const OPTION_USE_CITEM_INFO_FORM_FOR_GMS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS); 
    if ((OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS && !game.user.isGM ) || (OPTION_USE_CITEM_INFO_FORM_FOR_GMS && game.user.isGM ) ) {   //                 
          
      // get the item id from the element
      const item_id=citemlink.getAttribute("id"); 
      // remove eventlistener by cloning the element and replacing it                
      let elClone = citemlink.cloneNode(true);
      // remove class from clone
      elClone.classList.remove("roll-citemlink");
      // add class to element
      elClone.classList.add("sbe-info-citemlink");
      // add new event listener
      elClone.addEventListener("click", function(){ sbe_sheet_show_citem_info(item_id); });
      let parentnode=citemlink.parentNode;    
      // add new element
      parentnode.appendChild(elClone);
      // remove old element
      citemlink.remove();
    }
  }
  // find any messages by sbe.info
  let deletebutton = $(html).find(".sbe-info-chat-message-delete")[0];
  //console.log(deletebutton);
  if (deletebutton != null) {
      if (game.user.isGM) {
        let messageId = app.id;
        let msg = game.messages.get(messageId);
        $(html).find(".sbe-info-chat-message-delete").click(async ev => {
              msg.delete(html);
        });            
      }
      else {
          deletebutton.style.display = "none";
      }
  }
});

//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                   GM helper functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//  

function sbe_socket_manager(msg) {
  console.log('recieved data');
  console.log(msg);

  switch (msg.operation) {
    case('SHOW_PLAYERS'):
      let showme = false;
      // check if to show this player
      switch (msg.data.show.who) {
        case 'ALL':
          showme=true;
          break;
        case 'GM':
          if(game.user.isGM){
            showme=true;
          }
          break;
        default:
          // check for length
          if (msg.data.show.who.length>0){
            // split to array by semicolon
            const arrRecipients = msg.data.show.who.split(";");
            if(arrRecipients.includes(game.user.id)){
              showme=true;              
            }
          }
      }
      if (showme) {
        let options;
        switch (msg.data.type) {
          case('ITEM'):
            let item = game.items.get(msg.data.id);
            if (item != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: item.data.name,
                image: item.data.img,
                description: item.data.data.description
              };
            }
            break;
          case('ACTOR'):
            let actor = game.actors.get(msg.data.id)
            if (actor != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: actor.data.name,
                image: actor.data.img,
                description: actor.data.data.biography
              };
            }
            break;
          case('TOKEN'):
            let token = canvas.tokens.placeables.find(y => y.id == msg.data.id);
            if (token != null) {
              options = {
                show: msg.data.show,
                id: msg.data.id,
                type: msg.data.type,
                reshowable: false,
                name: token.data.name,
                image: token.data.img,
                description: token.actor.data.data.biography
              };
            }
            break;
        }
        if (options != null) {
          let f = new SandboxExtensionInfoForm(options).render(true, {focus: true});
        }
        break;
      }
  }
}
function sbe_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,compact_mode=false) {  
  let chatname='';
  let chatimage='';
  let whisperrecipients='';
  let objectname;
  let objectimage;
  let objectinfo;
  switch (showtype) {
    case('ITEM'):
      let item = game.items.get(showid);
      if (item != null) {
        objectname=item.data.name;
        objectimage=item.data.img;
        objectinfo=item.data.data.description;
      }
      break;
    case('ACTOR'):
      let actor = game.actors.get(showid)
      if (actor != null) {
        objectname=actor.data.name;
        objectimage=actor.data.img;
        objectinfo=actor.data.data.biography;
      }
      break;
    case('TOKEN'):
      let token = canvas.tokens.placeables.find(y => y.id == showid);
      if (token != null) {
        objectname= token.data.name;
        objectimage=token.data.img;
        objectinfo=token.actor.data.data.biography;
      }
      break;
  }    
  switch(what_show){
    case 'all':            
      break;
    case 'image-only':      
      objectname=null;
      objectinfo=null;
      break;
    case 'name-and-image':      
      objectinfo=null;
      break;
  }
  
  if (game.user.data.character!=null){ 
    let actor=game.actors.get(game.user.data.character);
    if(actor!=null){
      chatimage=actor.data.img;      
      chatname=actor.data.name;
    }        
  } else {
    chatimage = game.user.avatar;
    chatname = game.user.name;
  }  
  // determine recipiencts
  let targets=[];
  let iswhisper=false;
  switch(who_show){
    case 'ALL':      
      
      break;
    case 'GM':
      iswhisper=true;
      whisperrecipients='GM' ;
      // whisper to GMs
      targets= ChatMessage.getWhisperRecipients('GM');
      // add self
      targets.push(game.user.id);
      break;
    default:
      iswhisper=true;
      whisperrecipients= '';
      // parse name list
      const arrRecipients = who_show.split(";");
      let recipient;
      for (let i = 0; i < arrRecipients.length; i++){
        targets.push(arrRecipients[i]);
        recipient=game.users.get(arrRecipients[i]);
        if (recipient!=null){
          if(whisperrecipients.length==0){
            whisperrecipients=recipient.name;
          } else {
            whisperrecipients+=', ' + recipient.name;
          }
        }
      }
      // add self
      targets.push(game.user.id);
  }
  
  
  
  let rollData = {
      token:{
          img:chatimage,
          name:chatname
      },
      objectinfo: objectinfo,
      objectname:objectname,
      objectimage:objectimage,
      compact_mode:compact_mode,
      actor:chatname,
      user: game.user.name,
      isWhisper:iswhisper,
      whisperTo:whisperrecipients
    };
  renderTemplate("modules/sandbox-extensions/templates/sbe-info-chat-msg-all.hbs", rollData).then(html => {
      ChatMessage.create({
          content: html,
          whisper: targets
      });
  });                            
}

function sbe_sheet_showplayers_info_form(showid,showtype,showclass) {
  //console.warn('sbe_sheet_showplayers_info_form,' + showid + ','+showtype+','+showclass);
  //
  let objectname='';
  let datasource='';
  let token_actor_id='';
  switch (showtype) {
    case('ITEM'):
      let item = game.items.get(showid);
      if (item != null) {
        objectname=item.data.name;
        datasource=`<input type="hidden" id="show-info-content-datasource-item" name="show-info-content-datasource-item" value="ITEM">`;
      }
      break;
    case('ACTOR'):
      let actor = game.actors.get(showid)
      if (actor != null) {
        objectname=actor.data.name;
        datasource=`<input type="hidden" id="show-info-content-datasource-actor" name="show-info-content-datasource-actor" value="ACTOR">`;
      }
      break;
    case('TOKEN'):
      let token = canvas.tokens.placeables.find(y => y.id == showid);
      if (token != null) {
        objectname= token.data.name;
        // get the parent actor for the token for later use
        token_actor_id=token.data.actorId;        
        datasource=`
                     <br><label>From : </label>
                    <input class="sbe-info-form-option" type="radio" id="show-info-content-datasource-actor" name="show-info-content-datasource" value="ACTOR" >
                    <label class="sbe-info-form-option" for="show-info-content-datasource-actor">Actor</label>
                    <input class="sbe-info-form-option" type="radio" id="show-info-content-datasource-token" name="show-info-content-datasource" value="TOKEN" checked>
                    <label class="sbe-info-form-option" for="show-info-content-datasource-token">Token</label>
                    `;
      }
      break;
  }
  // generate dialog to ask userwhat data to show
  let htmlUsers='';
  // generate user list
  let users = game.users.filter(user => user.active);
  let actor;
  let actorimg="icons/svg/mystery-man.svg";
  let username='';
  let charactername='';
  let userid;
  // Build checkbox list for all active players
  users.forEach(user => {           
    username=user.name;
    userid=user.id;
    if (user.data.character!=null){             
      actor=game.actors.get(user.data.character);
      if(actor!=null){
        actorimg=actor.data.img;
      }
      charactername=user.charname;
      
    } else {
      charactername=user.name;      
      // use the user avatar if any
      if (user.avatar!=null){
        actorimg=user.avatar;
      }      
    }
    htmlUsers+='<div class="sbe-info-form-playerinfo"><input type="checkbox" class="sbe-info-form-playerselected" name="' + username +'" value="' + userid +'"  checked><img class="sbe-info-form-portrait-img"  src="' + actorimg +'"</img><p>' + charactername+'<br>[' + username  +']' + '</p></div>';
  });
  
  // 
  //
  let showAll='';
  let showImageOnly='';
  let showNameAndImage='';
  switch (showclass){
    case 'sbe-info-form-show-all':
      showAll='checked';      
      break;
    case 'sbe-info-form-show-name-and-image':
      showAll='disabled';
      showNameAndImage='checked';
      break;
    case 'sbe-info-form-show-image-only':
      showAll='disabled';
      showImageOnly='checked';
      showNameAndImage='disabled';
      break;
  }
  let d=new Dialog({
    title: `Show [` + showtype + '] ' + objectname + ' to others',
    content: `
          <style>
            
          </style>
          <script>
            function sbeshowInfoToggleUserSelection(){
              // get current value of "Selected users"
              const toselectedusers=document.getElementById("show-info-to-selected").checked;
              let fsSelectedUsers=document.getElementById("show-info-selected-users");
              if(toselectedusers){
                fsSelectedUsers.disabled = false;
              } else {
                fsSelectedUsers.disabled = true;
              }
            }
          </script>
            <form>
          <div class="sbe-info-form-column-float"> 
            <fieldset class="sbe-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show as</legend> 

                  <input class="sbe-info-form-option" type="radio" id="show-info-as-form" name="show-info-show-type" value="FORM" checked>
                  <label class="sbe-info-form-option" for="show-info-as-form">Pop-up</label><br>
               
                  
                  <input class="sbe-info-form-option" type="radio" id="show-info-as-chat" name="show-info-show-type" value="CHAT" >
                  <label class="sbe-info-form-option" for="show-info-as-chat">Chat</label><br>
                
                  <input class="sbe-info-form-option" type="radio" id="show-info-as-chat-compact" name="show-info-show-type" value="CHAT_COMPACT" >
                  <label class="sbe-info-form-option" for="show-info-as-chat-compact">Chat(compact)</label><br>
                
            </fieldset> 
          </div>
          <div class="sbe-info-form-column-float"> 
            <fieldset class="sbe-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show what</legend>
                                  
                  <input class="sbe-info-form-option" id="show-info-content-description" name="show-info-content" type="radio" value="all" ` + showAll + ` />
                  <label class="sbe-info-form-option" for="show-info-content-description">Image, name and info</label><br>
                                                     
                  <input class="sbe-info-form-option" id="show-info-content-name" name="show-info-content" type="radio" value="name-and-image" ` + showNameAndImage + ` />
                  <label class="sbe-info-form-option" for="show-info-content-name">Image and name</label><br>
                   
                  <input class="sbe-info-form-option" id="show-info-content-image" name="show-info-content" type="radio" value="image-only" ` + showImageOnly + `/>  
                  <label class="sbe-info-form-option" for="show-info-content-image">Image only</label>
                  `+datasource+`
              </fieldset>
          </div>
          
          <div class="sbe-info-form-column-float">
          <fieldset class="sbe-info-form-basic" style="text-align:left;">
                <legend style="text-align:left;">Show to</legend> 
                
                  <input class="sbe-info-form-option" type="radio" id="show-info-to-all" name="show-info-show-to" value="ALL" onclick="sbeshowInfoToggleUserSelection();" checked>
                  <label class="sbe-info-form-option" for="show-info-to-all">All players & GM</label><br>

                  <input class="sbe-info-form-option"  type="radio" id="show-info-to-gm" name="show-info-show-to" value="GM" onclick="sbeshowInfoToggleUserSelection();">
                  <label class="sbe-info-form-option" for="show-info-to-gm">GM only</label><br>
    
                  <input class="sbe-info-form-option" type="radio" id="show-info-to-selected" name="show-info-show-to" value="SELECTED" onclick="sbeshowInfoToggleUserSelection();">
                  <label class="sbe-info-form-option" for="show-info-to-selected">Selected players</label><br>
           </fieldset>
          </div>
          

          <fieldset id="show-info-selected-users" style="text-align:left;" disabled>
            <legend style="text-align:left;">Selected players</legend>
            `+htmlUsers+`
          </fieldset>   
                

      </form>
            `,
    buttons: {
      yes: {
        icon: "<i class='fas fa-check'></i>",
        label: `Show`,
        callback: async (html) => {
          // assemble data
          // what to show                    
          let who_show=(html.find('input[name="show-info-show-to"]:checked').val() || 'none'); 
          if(who_show=='SELECTED'){
            // get users
            const selectedplayers = document.getElementsByClassName("sbe-info-form-playerselected"); 
            if(selectedplayers.length>0){
              who_show='';
              // get them
              for (let i = 0; i < selectedplayers.length; i++){
                if(selectedplayers[i].checked){                          
                  who_show+=selectedplayers[i].value +';' ;                  
                }
              }
              if(who_show==''){
                who_show='none';
              }
            } else {
              who_show='none';
            }
          }
          const what_show=(html.find('input[name="show-info-content"]:checked').val() || 'none'); 
          const how_show=(html.find('input[name="show-info-show-type"]:checked').val() || 'none'); 
          // for tokens, check if user wanted to use data from the parent actor
          if(showtype=='TOKEN'){
            const datasource=(html.find('input[name="show-info-content-datasource"]:checked').val() || 'TOKEN');
            if(datasource=='ACTOR'){
              showtype='ACTOR';
              showid=token_actor_id;
            }
          }
          if(what_show !='none' && who_show !='none' && how_show!='none'){                        
            if(how_show=='CHAT' ){
              sbe_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,false);
            } else if(how_show=='CHAT_COMPACT'){
              sbe_sheet_showplayers_info_chat(showid,showtype,what_show,who_show,true);
            } else {
              // send through socket to client to show popup
              let show_name=false;
              let show_image=false;
              let show_description=false;            
              console.log('Show to players ' + showtype + ' : ' + showid );
              switch(what_show){
                case 'all':
                  show_name=true;
                  show_image=true;
                  show_description=true;
                  break;
                case 'image-only':
                  show_image=true;
                  break;
                case 'name-and-image':
                  show_name=true;
                  show_image=true;
                  break;
              }
              game.socket.emit("module.sandbox-extensions", {
                operation:'SHOW_PLAYERS',
                data:{
                  id: showid,
                  type:showtype,
                  class:showclass,
                  show:{
                    name:show_name,
                    image:show_image,
                    description:show_description,
                    who:who_show
                  }
                }
              });
            }
          } else{
            // notify user no msg will be sent
            ui.notifications.warn('Show to others | No content or recipients selected to show');
          }
        }
      },
      no: {
        icon: "<i class='fas fa-times'></i>",
        label: `Cancel`
      }
    },
    default: "yes",
    close: (html) => {
    }
  });
  d.options.width = 575;
  d.position.width = 575;
  d.options.height=0;
  d.position.height=0;
  d.options.resizable=true;
  d.render(true);
}

function sbe_sheet_display_show_to_others_in_sheet_caption(html, sheettype, id,reshowable=false,defaultshowclass='') {
  const OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION);
  if (OPTION_DISPLAY_SHOW_TO_OTHERS_IN_SHEET_CAPTION) {        
    
    if (html[0].classList.contains('sbe-info-form-reshowable')||reshowable){
      let showid;
      let showtype;
      let showclass;
    
      if(defaultshowclass!=''){
        showclass=defaultshowclass;
      } else{
        if (html[0].classList.contains('sbe-info-form-show-image-only')){
          showclass='sbe-info-form-show-image-only';
        }
        if (html[0].classList.contains('sbe-info-form-show-name-and-image')){
          showclass='sbe-info-form-show-name-and-image';
        }
        if (html[0].classList.contains('sbe-info-form-show-all')){
          showclass='sbe-info-form-show-all';
        }
      }
      let newelementid = 'sbe-show-others-' + id;
      let insertafterthis = html.find('.window-title');

      if (insertafterthis) {
        insertafterthis.after('<a id="' + newelementid + '" title="Show info to others"><i class="fas fa-eye"></i> Show</a>');
        switch (sheettype) {
          case 'ACTOR':
            // if the actorid is double(ie MwTr94GekOCihrC-6bX8wMQkdZ9OyOQa), then it is a unlinked token, 
            // need to get the actor from the canvas so use the secondary id            
            if (id.length > 16) {
              // get secondary actor id   
              const posdivider = id.indexOf("-") + 1;
              let actorid = id.substring(posdivider);
              showid=actorid;
              showtype='TOKEN';            
            } else {
              // normal actor
              showid=id;
              showtype='ACTOR';
            }                    
            break;
          case 'ITEM':          
            showid=id;
            showtype='ITEM';
            break;
        }
        html.find('#' + newelementid).click(ev => {      
          sbe_sheet_showplayers_info_form(showid,showtype,showclass);
        });

      }
    }
  }
}

function sbe_sheet_display_id_in_window_caption(html, sheettype, id) {
  const OPTION_DISPLAY_ID_IN_SHEET_CAPTION = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_DISPLAY_ID_IN_SHEET_CAPTION);
  if (OPTION_DISPLAY_ID_IN_SHEET_CAPTION) {
    if (game.user.isGM) {
      let foldername = '';
      let newelementid = 'sbe-show-in-console-' + id;      
      // get folder based on type
      switch (sheettype) {
        case 'ACTOR':
          let actor = game.actors.get(id);
          if (actor != null) {
            if (actor.folder != null) {
              foldername = actor.folder.name;
            }
          }
          break;
        case 'ITEM':
          let item = game.items.get(id);
          if (item != null) {
            if (item.folder != null) {
              foldername = item.folder.name;
            }
          }
          break;
      }
      if (foldername.length > 0) {
        foldername = ' in Folder [' + foldername + ']';
      }
      // get window title
      let insertafterthis = html.find('.window-title');
      if (insertafterthis) {
        insertafterthis.after('<a id="' + newelementid + '" title="' + sheettype + ' [' + id + ']' + foldername + '&#13;Click to show data in Console"><i class="fas fa-tag"></i> Info</a>');
        switch (sheettype) {
          case 'ACTOR':            
            // if the actorid is double(ie MwTr94GekOCihrC-6bX8wMQkdZ9OyOQa), then it is a unlinked token, 
            // need to get the actor from the canvas so use the secondary id            
            if (id.length > 16) {
              // get secondary actor id   
              const posdivider=id.indexOf("-")+1;
              let actorid = id.substring(posdivider);                                           
              html.find('#' + newelementid).click(ev => {
                let token = canvas.tokens.placeables.find(y=>y.id==actorid);                                          
                console.log(token.actor);
              });                              
            } else {
              // normal actor
              html.find('#' + newelementid).click(ev => {
               console.log(game.actors.get(id));
               });
            }                        
            break;
          case 'ITEM':
            html.find('#' + newelementid).click(ev => {
              console.log(game.items.get(id));
            });                        
            break;
        }
      }
    }
  }
}

//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                   Item delete protection functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
// 

function sbe_sheet_item_delete_protection(html) {
  const OPTION_ACTIVATE_ITEM_DELETE_PROTECTION = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION);
  if (OPTION_ACTIVATE_ITEM_DELETE_PROTECTION) {    
    let sheetelementid = html[0].id;
    // get window title
    let insertafterthis = html.find('.window-title');
    if (insertafterthis) {
      // create toggle button
      //let sToggle = '<input type="checkbox" id="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-checkbox" title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'"><a style="margin-left:0px;"><label for="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-label" title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'">'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-caption')+'</label></a>';
      let sToggle = '<input type="checkbox" id="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-checkbox" title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'"><label for="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-label"  title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'">'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-caption')+'</label>';
      // insert button
      insertafterthis.after(sToggle);
      // Trigger a toggle 
      sbe_sheet_toggle_delete_item_visible(html);        
      // add event listener for user to toggle
      html.find('#' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible').click(ev => {
        sbe_sheet_toggle_delete_item_visible(html);
      });
      
    }
  }
}

function sbe_sheet_toggle_delete_item_visible(html) {
  try {
    // get document from the element(used for popout combability)     
    let doc = html[0].ownerDocument;
    let sheetelementid;
    // for some updates the return html is a form
    if (html[0].nodeName == 'FORM') {
      sheetelementid = html[0].parentElement.parentElement.id;
    } else {
      sheetelementid = html[0].id;
    }
    let sheet = doc.getElementById(sheetelementid);
    if (sheet !== null) {
      //let deletes = sheet.getElementsByClassName(delete_btn_class);
      let deletes = sheet.querySelectorAll('.ci-delete, .item-delete,.citem-delete,.mod-delete');
      let chkelement = doc.getElementById(sheetelementid + '-sbe-sheet-toggle-delete-item-visible');
      let chkvalue = false;
      if (chkelement !== null) {
        chkvalue = chkelement.checked;
      }
      for (let i = 0; i < deletes.length; i++) {
        if (deletes[i].nodeName == 'A') {
          let style = getComputedStyle(deletes[i]);

          if (chkvalue) {
            deletes[i].style.display = 'inline';
          } else {
            deletes[i].style.display = 'none';
          }
        }
      }
    }
  } catch (err) {
    console.log('SBE   | sbe_sheet_toggle_delete_item_visible Err:' + err.message);
  }
}

//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                   Table filter functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//
async function sbe_sheet_actor_filter_tables_totals(actor) {
  const OPTION_USE_TABLE_FILTERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS);
  if (OPTION_USE_TABLE_FILTERS) {
    try {
      console.warn('SBE  | sbe_sheet_actor_filter_tables_totals');
      // loop all properties(attributes) of actor
      for (let property in actor.data.data.attributes) {
        // check if this is a table
        if (actor.data.data.attributes[property].hasOwnProperty('istable')) {
          // check if property is table
          if (actor.data.data.attributes[property]['istable'] == true) {
            // get the table property from the db
            let tableproperty = game.items.get(actor.data.data.attributes[property].id);
            // check for totals
            if (tableproperty.data.data.hastotals == true) {
              // check for filter for this table property
              let filter = sbe_property_has_valid_table_filter(tableproperty);
              if (filter != null) {
                // at this point, we have a table with totals and a filter            
                // time to recalculate those totals
                let totalGroupIKey = tableproperty.data.data.group.ikey;
                // get all citems for this actor with this group
                let gcitems = await actor.data.data.citems.filter(y => y.groups.some(x => x.ikey == totalGroupIKey));
                for (var propKey in actor.data.data.attributes[property].totals) {
                  let newtotal = 0;
                  let filter_passed_count = 0;
                  for (let q = 0; q < gcitems.length; q++) {
                    if (sbe_table_filter_passed(filter, gcitems[q], filter_passed_count)) {
                      // passsed
                      filter_passed_count = filter_passed_count + 1;
                      let total_citem = gcitems[q].attributes[propKey];
                      if (total_citem != null)
                        newtotal += Number(total_citem.value);
                    } else {
                      // dont add this
                    }
                  }
                  actor.data.data.attributes[property].totals[propKey].total = newtotal;
                  //console.warn(tableproperty.data.data.attKey + ' ' + propKey + ' total:' + newtotal);
                }
              }
            }
          }
        }
      }
    } catch (err) {
      console.error('SBE   | sbe_sheet_actor_filter_tables_totals Err:' + err.message);
    }
  }
}


async function sbe_sheet_actor_filter_tables(html){
  const OPTION_USE_TABLE_FILTERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS);  
  if(OPTION_USE_TABLE_FILTERS){
    try {  
      console.warn('SBE  | sbe_sheet_actor_filter_tables');
      let id;
      let actor;
      // get actor
      // get actor id from html      
      // for updates the return html is a form
      if (html[0].nodeName == 'FORM') {
        id=html[0].parentElement.parentElement.id.replace('actor-','');  
      } else {
        id=html[0].id.replace('actor-','');  
      }      
      // if the actorid is double(ie MwTr94GekOCihrC-6bX8wMQkdZ9OyOQa), then it is a unlinked token, 
      // need to get the actor from the canvas so use the secondary id            
      if (id.length > 16) {
        // token actor
        // get secondary actor id   
        const posdivider=id.indexOf("-")+1;
        let actorid = id.substring(posdivider);                                           
        // get token from canvas
        let token = canvas.tokens.placeables.find(y=>y.id==actorid);                         
        actor=token.actor;                                                                    
      } else {
        // normal actor                
        actor = game.actors.get(id);
      }      
      // get all tables
      let tables = html.find('table');
      let isfreetable;
      for (let i = 0; i < tables.length; i++) {
        // find table property by key
        let propertykey=tables[i].attributes.name.value.substr(tables[i].attributes.name.value.lastIndexOf(".") + 1);        
        let property = game.items.find(y=>(y.type=="property" && y.data.data.attKey==propertykey));
        if (property!=null){
          // check if this table property has a filter
          // check if this is a freetable
          isfreetable=property.data.data.isfreetable;          
          let filter=sbe_property_has_valid_table_filter(property);                                                          
          if(actor!=null && filter!=null){                           
            let filter_passed_count=0;
            // free tables not supported, cause free tables stores itd table data in each free table property, so it will never be supported cause there is no point
            if(!isfreetable){              
              let actorcitems=actor.data.data.citems;
              // now loop all rows backwards of this table and match each citem against the actors citems                
              for (let r= tables[i].tBodies[0].rows.length - 1; r >= 0; r--) {  
                if(tables[i].tBodies[0].rows[r].cells[0].classList.contains('linkable')){
                  let item_id=tables[i].tBodies[0].rows[r].cells[0].attributes["item_id"].value;
                  // find this citem in actorcitiem
                  let actorcitem=actorcitems.find(y=>y.id==item_id);
                  if(actorcitem!=null){
                    // found it. Check against filter                    
                    if(sbe_table_filter_passed(filter,actorcitem,filter_passed_count)){
                      // passsed
                      filter_passed_count = filter_passed_count + 1;
                    } else {
                      // remove this row
                      tables[i].deleteRow(tables[i].tBodies[0].rows[r].rowIndex);
                    }                                 
                  }
                }
              }  
            }
          }                                        
        }
      }
    } catch (err) {
      console.error('SBE   | sbe_sheet_actor_filter_tables Err:' + err.message);
    }
  }
}


function sbe_sheet_display_subitems_icons(html, identifier, container, containersubitemarray) {
  const OPTION_DISPLAY_SUBITEMS_ICONS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_DISPLAY_SUBITEMS_ICONS);
  if (OPTION_DISPLAY_SUBITEMS_ICONS) {
    try {
      let lielement;
      let subitemid;
      let subitem;
      let subitemslist;
      subitemslist = html.find(identifier);
      if (container != null) {
        for (let i = 0; i < subitemslist.length; i++) {
          lielement = $(subitemslist[i]).parents(".property");
          if (lielement != null) {
            if (containersubitemarray[lielement.data("itemId")].hasOwnProperty('id')) {
              subitemid = containersubitemarray[lielement.data("itemId")].id;
              subitem = game.items.get(subitemid);
              subitemslist[i].innerHTML = sbe_two_col_card('<img src="' + subitem.img + '" class="sbe-item-list-icon" /> ', subitemslist[i].innerHTML);
            }
          }
        }
      }
    } catch (err) {
      console.error('SBE   | sbe_sheet_display_subitems_icons Err:' + err.message);
    }
  }
}


async function sbe_sheet_use_citem_icon(html){
  const OPTION_USE_CITEM_ICON = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON);  
  if(OPTION_USE_CITEM_ICON){
    try {
      const OPTION_USE_CITEM_ICON_TABLE_SUFFIX=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_ICON_TABLE_SUFFIX); 
      let tables = html.find('table');
      for (let i = 0; i < tables.length; i++) {
        if(tables[i].attributes.name.value.endsWith(OPTION_USE_CITEM_ICON_TABLE_SUFFIX)){
          for (let r= 0; r < tables[i].tBodies[0].rows.length; r++) {
            if(tables[i].tBodies[0].rows[r].cells[0].classList.contains('linkable')){
              let item_id=tables[i].tBodies[0].rows[r].cells[0].attributes["item_id"].value;
              // get citem
              const citem=game.items.get(item_id);
              if(citem!=null){
                // get the image            
                const citemimg=citem.img;
                
                tables[i].tBodies[0].rows[r].cells[0].innerHTML=sbe_two_col_card('<img src="' + citemimg +'" class="sbe-citem-table-icon" /> ',  tables[i].tBodies[0].rows[r].cells[0].innerHTML);
              }
            }
          }
        }
      }
    } catch (err) {
      console.error('SBE   | sbe_sheet_use_citem_icon Err:' + err.message);
    }
  }
}

function sbe_two_col_card(left,right,type='table'){
  let htmltable=`
    <div class="sbe-two-col-card-wrapper">
  <div class="sbe-two-col-card-image-in-` +type+`">`+left+`</div>  
  <div class="sbe-two-col-card-name">`+right+`</div>
</div>
    `;
  return htmltable;
}



function sbe_sheet_use_citem_info_form(html){  
  const OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS);  
  const OPTION_USE_CITEM_INFO_FORM_FOR_GMS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_CITEM_INFO_FORM_FOR_GMS); 
  if ((OPTION_USE_CITEM_INFO_FORM_FOR_PLAYERS && !game.user.isGM ) || (OPTION_USE_CITEM_INFO_FORM_FOR_GMS && game.user.isGM ) ) {   //         
    sbe_sheet_relink_citems(html);      
  }
}

function sbe_sheet_relink_citems(html){
  try {
    // get document from the element(used for popout combability)     
    let doc = html[0].ownerDocument;
    let sheetelementid;
    // for some updates the return html is a form
    if (html[0].nodeName == 'FORM') {
      sheetelementid = html[0].parentElement.parentElement.id;
    } else {
      sheetelementid = html[0].id;
    }
    let sheet = doc.getElementById(sheetelementid);
    if (sheet !== null) {
      let linkables = sheet.querySelectorAll('.linkable.tablenamecell');
      let el;
      for (let i = 0; i < linkables.length; i++) {
        let item_id=linkables[i].attributes["item_id"].value;
        let item_cikey=linkables[i].attributes["item_cikey"].value;
        // remove eventlistener by cloning the element and replacing it                
        let elClone = linkables[i].cloneNode(true);
        // add new event listener
        elClone.addEventListener("click", function(){ sbe_sheet_show_citem_info(item_id); });
        linkables[i].parentNode.replaceChild(elClone, linkables[i]);
        
      }
    }
  } catch (err) {
    console.error('SBE   | sbe_sheet_relink_citems Err:' + err.message);
  }
}

function sbe_sheet_show_citem_info(item_id){
  let cItem = game.items.get(item_id);
  if (cItem!=null){
    let item_description=cItem.data.data.description;
    let item_name=cItem.data.data.attributes.name;
    let item_img=cItem.data.img;
    let options = {
        show:{
          name:true,
          image:true,
          description:true
        },
        id:item_id,    
        type:'ITEM',
        class:'sbe-info-form-show-all',
        reshowable:true,
        name: item_name,
        image: item_img,        
        description:item_description
      };                                                                   
    let f=new SandboxExtensionInfoForm(options).render(true,{focus:true});
  }
}


// IN development
function sbe_sheet_change_inputs_to_number_type(html) {
  const OPTION_CHANGE_INPUTS_TO_NUMBER_TYPE = false;
  if (OPTION_CHANGE_INPUTS_TO_NUMBER_TYPE) {
    console.warn('SBE  | sbe_sheet_change_inputs_to_number_type');
    // get all inputs
    let inputs = html.find('.sandbox-property-data-type-simplenumeric');

    for (let i = 0; i < inputs.length; i++) {
      inputs[i].type = "number";
      
    }
  }
}

                                                                 
                                                                  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       Sheet input functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  function sbe_item_sheet_set_title_from_value(inputelement){
    if (inputelement[0].value!==''){
      inputelement[0].title=inputelement[0].value;
    }
  }
  
  function sbe_item_sheet_get_input(html,sAttribute,sTypeClass){ 
    let objInput=null; 
    let sIdentifier= ITEMATTRIBUTE[sTypeClass.toUpperCase()][sAttribute.toUpperCase()].IDENTIFIER;
    objInput = html.find(`${sIdentifier}`);
    return objInput;
  }
  
  async function sbe_item_sheet_edit_input(html,oAttribute,typeClass,itemid,propertydatatype='',OPTION_USE_TABLE_FILTERS=false){
    let sExpression=sbe_item_sheet_get_input(html,oAttribute.ATTRIBUTE,typeClass)[0].value;
    let itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;
    let itemtargetelement=ITEMATTRIBUTE[typeClass.toUpperCase()][oAttribute.ATTRIBUTE.toUpperCase()].IDENTIFIER; 
    
    
    let options = {
        expression: sExpression,
        itemid: itemid,
        itemname:itemName,
        itemtype:typeClass.toLowerCase(),
        itemlabel:oAttribute.CAPTION,
        itemtargetelement:itemtargetelement,
        itemlinebreaker:oAttribute.LINEBREAKER
      }; 
    // check if this is a table filter
    if(propertydatatype=='table' && typeClass.toLowerCase()=='property' && OPTION_USE_TABLE_FILTERS){      
      let bOkToProceed=true;
      // check if any content/filter exists
      if (sExpression.length>0){
        // check if valid filter
        if (sbe_string_is_valid_table_filter(sExpression)==null){
          // ask user open table filter editor anyway(empty)
          bOkToProceed=await sbe_item_sheet_confirmdialog('Warning - Invalid Table Filter','This filter <br><div class="sbe-code-block-container"><p class="sbe-code-block-content">'+sExpression+'</p></div><br> is invalid, the table filter editor will display it as empty.<br>Do you want to proceed?<br>' );              
        }
      }
      
      if(bOkToProceed){
        new SandboxTableFilterEditorForm(options).render(true,{focus:true}); 
      }
    } else {
      new SandboxExpressionEditorForm(options).render(true,{focus:true}); 
    }
  }
                     
  function sbe_item_sheet_paste_input(html,oAttribute){
    navigator.clipboard.readText()
      .then(text => {
        // `text` contains the text read from the clipboard          
        let elementInput= null;                    
        let sIdentifier=oAttribute.IDENTIFIER;
        elementInput= html.find(`${sIdentifier}`);
        if (elementInput!=null && elementInput.length>0){
          elementInput[0].value= text;
          // trigger onchange event
          const event = new Event('change', { bubbles: true });  
          elementInput[0].dispatchEvent(event); 
        } 
      })
      .catch(err => {
        // maybe user didn't grant access to read from clipboard
        ui.notifications.warn('Error when attempting to paste to ' + oAttribute.CAPTION,err);
      });            
  }
   
  function sbe_item_sheet_cut_input(html,oAttribute,sPrefix='',sSuffix=''){ 
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    let sValue='';
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      sValue=elementInput[0].value;
      if (sValue.length>0){     
        let sEnclosed=sPrefix + sValue + sSuffix;
        navigator.clipboard.writeText(sEnclosed);
        // and empty it
        elementInput[0].value= '';
        // trigger onchange event
        const event = new Event('change', { bubbles: true });  
        elementInput[0].dispatchEvent(event);
        ui.notifications.info(oAttribute.CAPTION +" cut to Clipboard as ["+ sEnclosed +"]");
      }
      else{
        ui.notifications.warn(oAttribute.CAPTION +" not cut to Clipboard(empty string)");
      }
    }                                                            
  } 
  
    function sbe_item_sheet_changecase_input(html,oAttribute,casetype){ 
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    let sValue='';
    let sNewValue='';
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      sValue=elementInput[0].value;
      if (sValue.length>0){     
        switch(casetype){
          case stringCasing.CASING.CASE.UPPERCASE:
            sNewValue=sValue.toUpperCase();
            break;
          case stringCasing.CASING.CASE.LOWERCASE:
            sNewValue=sValue.toLowerCase();
            break;
          case stringCasing.CASING.CASE.TITLECASE:
            sNewValue=stringCasing.stringToTitleCase(sValue);
            break;
        }
        if (sValue != sNewValue){
          // and change it
          elementInput[0].value=sNewValue ;
          // trigger onchange event
          const event = new Event('change', { bubbles: true });  
          elementInput[0].dispatchEvent(event);
        }
      }
      
    }                                                            
  }
   
   
  function sbe_item_sheet_copy_input(html,oAttribute,sPrefix='',sSuffix=''){ 
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    let sValue='';
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      sValue=elementInput[0].value;
      if (sValue.length>0){     
        let sEnclosed=sPrefix + sValue + sSuffix;
        navigator.clipboard.writeText(sEnclosed);     
        ui.notifications.info(oAttribute.CAPTION +" copied to Clipboard as ["+ sEnclosed +"]");
      }
      else{
        ui.notifications.warn(oAttribute.CAPTION +" not copied to Clipboard(empty string)");
      }
    }                                                            
  }
  
  function sbe_item_sheet_copy_input_as_css(html,oAttribute){
    sbe_item_sheet_copy_input(html,oAttribute,'.sandbox.sheet .','{\n}');
  }
  
  function sbe_item_sheet_copy_input_as_actor_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'@{','}');                                                           
  }                           
  
  function sbe_item_sheet_copy_input_as_citem_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'#{','}');                                                           
  } 
  
  function sbe_item_sheet_copy_input_as_dialog_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'d{','}');                                                           
  }
  
  function sbe_item_sheet_validate_input(html,oAttribute,typeClass,itemid){  
    const enforcedvalidation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION);
    const itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;                                                    
    let validatingitemtype='';
    switch(typeClass) {
      case 'PROPERTY':
        validatingitemtype='property';              
        break;
      case "MULTIPANEL":
        validatingitemtype='multipanel';
        break; 
      case "PANEL":
        validatingitemtype='panel';
        break; 
      case "TAB":
        validatingitemtype='sheettab';
        break; 
      case "GROUP":
        validatingitemtype='group';
        break;   
      case "cITEM":            
        break;  
      default:
        break;            
    }         
    let elementInput= null;         
    switch(oAttribute.ATTRIBUTE){
      case 'key':       
        elementInput=sbe_item_sheet_get_input(html,'key',typeClass);
        if (elementInput!=null && elementInput.length>0){   
          let sKey=elementInput[0].value; 
          sbe_item_sheet_validate_key(validatingitemtype,itemName,itemid,typeClass,sKey,enforcedvalidation);
        }        
        break;
      case 'checkgroup':                  
        elementInput=sbe_item_sheet_get_input(html,'checkgroup',typeClass);
        if (elementInput!=null && elementInput.length>0){ 
          let sCheckGroup=elementInput[0].value;                                      
          sbe_item_sheet_validate_checkgroup(itemName,sCheckGroup,typeClass);
        } 
        break; 
      case 'list':                
        elementInput=sbe_item_sheet_get_input(html,'list',typeClass);
        if (elementInput!=null && elementInput.length>0){  
          let sList=elementInput[0].value;                                    
          sbe_item_sheet_validate_list(itemName,sList,typeClass);
        } 
        break;
      case 'tooltip':
        //
        
        const OPTION_USE_TABLE_FILTERS = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_TABLE_FILTERS);      
        elementInput=sbe_item_sheet_get_input(html,'tooltip',typeClass);
        if (elementInput!=null && elementInput.length>0 && OPTION_USE_TABLE_FILTERS){  
          let sTooltip=elementInput[0].value;                                    
          sbe_item_sheet_validate_table_filter(itemName,sTooltip,typeClass);
        }
        break;
      default:
        break;
    }                             
  }
  
  async function sbe_item_sheet_autogenerate_all(gItemSheet,html,typeClass){
    let bOkToProceed=true;  
    const bRequireConfirmation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE);
    if (bRequireConfirmation){
        bOkToProceed=await sbe_item_sheet_confirmdialog('Confirm Autogenerate All','This will overwrite fields with <b>Autogenerate</b> option, do you want to proceed?<br><br> To avoid this confirmation dialog, you can change <b>Confirm batch overwrite</b> in Settings' );
    }
      if (bOkToProceed){                 
        switch(typeClass) {     
          case 'PROPERTY':
            const datatype = sbe_item_sheet_get_input(html, ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE, 'PROPERTY')[0].value;
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            
            if(datatype!='table'){
              sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP,typeClass,false);
            }
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP,typeClass,false,datatype);  
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID,typeClass,false); 
            sbe_item_sheet_autogenerate_icon(html);
            break;
          case "MULTIPANEL":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP,typeClass,false);
            break; 
          case "PANEL":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP,typeClass,false);
            break; 
          case "TAB":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            break; 
          case "GROUP":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            break;   
          case "cITEM":            
            break;  
          default:
            break;            
        }
        // trigger onsubmit event                
        gItemSheet.submit();
        
      }
  }
    
  function sbe_item_sheet_autogenerate_input(html,oAttribute,typeClass,triggeronchange=true,datatype=''){ 
    let sKey='';
    let key_prefix='';
    let key_prefix_setting='';  
    let autogenerated='N/A';    
    let full_prefix=''; 
    let sItemName='';
    let sBase='';    
    
    const key_separator=stringCasing.CASING.SEPARATOR.KEY; 
    const css_separator=stringCasing.CASING.SEPARATOR.CSS;
    const keyCase=stringCasing.CASING.CASENR[sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE)];
    const cssCase=stringCasing.CASING.CASENR[sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE)];
    const useprefixsuffix=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX);
    const itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;
    if(useprefixsuffix){
      switch(typeClass) {
        case 'PROPERTY':
          // check if to use datatype as prefix
          const usedatatype=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX);
          if(usedatatype==false){
            key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY;
          }
          else{
            // get the datatype
            const datatype=sbe_item_sheet_get_input(html,ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE,'PROPERTY')[0].value;
            switch (datatype) {
              case 'simpletext':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT;
                break;
              case 'simplenumeric':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC;
                break;
              case 'checkbox':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX;
                break;
              case 'radio':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO;
                break;
              case 'textarea':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA;
                break;
              case 'list':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST;
                break;
              case 'label':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL;
                break;
              case 'badge':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE;
                break;
              case 'table':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE;
                break;
              case 'button':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON;
                break;
            }
          }
          break;
        case "MULTIPANEL":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL;
          break; 
        case "PANEL":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PANEL;
          break; 
        case "TAB":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_TAB;
          break; 
        case "GROUP":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_GROUP;
          break;   
        case "cITEM":            
          break;  
        default:
          break;            
      }         
      if(key_prefix_setting.length>0){
        key_prefix = sbe_item_sheet_get_game_setting(SandboxExtensions.ID,key_prefix_setting);
      } 
    }
    switch(oAttribute.ATTRIBUTE){
      case 'key':        
        // check if itemname already begins with prefix then dont add it                                                           
        if (key_prefix!=''){        
          full_prefix=key_prefix + key_separator;
          if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
            sKey=itemName;
          }
          else{
            sKey=full_prefix +  itemName;
          }
        }
        else{
          sKey=itemName;
        }                                                          
        sKey=sbe_item_sheet_to_slug(sKey,key_separator,keyCase); 
        autogenerated=sKey;                   
        break;
      case 'tag':                                            
        full_prefix=key_prefix + key_separator;              
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }                       
        autogenerated= sItemName; 
        break;
      case 'tooltip':         
        full_prefix=key_prefix + key_separator;
        sItemName='';       
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }             
        autogenerated= sItemName;
        break;
      case 'rollname':         
        if (typeClass=='PROPERTY'){            
          sBase=itemName;
        } 
        else if(typeClass=='cITEM'){   
          sBase='#{name}';
        }
        else{
          sBase=itemName;
        } 
        let suffix_rollname='';
        
        if(useprefixsuffix){
          suffix_rollname=' ' + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME); 
          
        }
        autogenerated= sBase +  suffix_rollname; 
        break;      
      case 'rollid':
        if (typeClass=='PROPERTY'){       
            sBase=html.find(`${ITEMATTRIBUTE.PROPERTY.KEY.IDENTIFIER}`)[0].value;
          }
        else{
          sBase=itemName;
        }  
        let suffix_rollid='';
        if(useprefixsuffix){
          suffix_rollid=key_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_ROLLID);    
        }
        let sRollID=sBase +  suffix_rollid;                                                                         
        autogenerated= sbe_item_sheet_to_slug(sRollID,key_separator,keyCase);
        break;
      case 'fontgroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value;
        let suffix_fontgroup='';
        if(useprefixsuffix){
          suffix_fontgroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP);    
        }
        let sFontGroup=sKey +  suffix_fontgroup;                 
        autogenerated=sbe_item_sheet_sanitize_css( sbe_item_sheet_to_slug(sFontGroup,css_separator,cssCase));
        break; 
      case 'inputgroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value; 
        let suffix_inputgroup='';
        if(useprefixsuffix){
          suffix_inputgroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP);      
        }
        
        let sInputGroup=sbe_item_sheet_sanitize_css( sbe_item_sheet_to_slug(sKey +  suffix_inputgroup,css_separator,cssCase)); 
        if(datatype.length>0){
        
          sInputGroup+= ' ' + sbe_item_sheet_sanitize_css( sbe_item_sheet_to_slug('sandbox-property-data-type-' + datatype,css_separator,cssCase));
        }
        autogenerated=sInputGroup; 
        break;
      case 'headergroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value; 
        let suffix_headergroup='';
        if(useprefixsuffix){
          suffix_headergroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP);     
        }
        let sHeaderGroup=sKey +  suffix_headergroup;                                                                        
        autogenerated= sbe_item_sheet_sanitize_css(sbe_item_sheet_to_slug(sHeaderGroup,css_separator,cssCase)); 
        break;
      default:
        break;
    }
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      elementInput[0].value= autogenerated;
      if(triggeronchange){
        // trigger onchange event
        const event = new Event('change', { bubbles: true });       
        elementInput[0].dispatchEvent(event); 
      }
    }     
  }
  
  async function sbe_item_sheet_autogenerate_icon(html,usedefault=false){     
    let iconbasefilename="modules/sandbox-extensions/styles/icons/sbe_property_";
    let icondefaultfilename='systems/sandbox/docs/icons/sh_prop_icon.png';    
    // get item id
    let sheetelementid;
    // for some updates the return html is a form
    if (html[0].nodeName == 'FORM') {
      sheetelementid = html[0].parentElement.parentElement.id;
    } else {
      sheetelementid = html[0].id;
    }
    let itemid=sheetelementid.replace('item-','');
    // get the property
    let property=await game.items.get(itemid);        
    if (property!=null){      
      let iconfile='';
      if(usedefault){
        iconfile=icondefaultfilename;
      } else{
        // get datatype        
        const datatype=sbe_item_sheet_get_input(html,ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE,'PROPERTY')[0].value;
        switch(datatype){
          case('label'):
            // check format for die format
            const labelformat=sbe_item_sheet_get_input(html,ITEMATTRIBUTE.PROPERTY.LABELFORMAT.ATTRIBUTE,'PROPERTY')[0].value;
            if(labelformat=='D'){
              iconfile=iconbasefilename + 'die.svg'; 
            } else {
              iconfile=iconbasefilename + datatype + '.svg'; 
            }
            break;            
          case('button'):
          case('checkbox'):
          case('list'):
          case('radio'):
          case('simplenumeric'):
          case('simpletext'):
          case('textarea'):
          case('table'):
          case('badge'):
            // assemble file path
            iconfile=iconbasefilename + datatype + '.svg';        
            break;
          default:
            // use sb default
            iconfile=icondefaultfilename;       
            break;
        }
        
      }      
      await property.update({[`img`]: `${iconfile}`});
    }

  }

  function sbe_item_sheet_sanitize_css(scss) {
    // /^[0-9]|^-([0-9])/gu  fill find string starting with a number OR 1 hyphen followed by number 
    let sreturn = scss;
    // CSS class name cannot start with a number 
    if (/^[0-9]/gu.test(sreturn)) {
      // add two hyphens
      sreturn = '--' + sreturn;
    }
    // or a single hyphen followed by a digit
    if(/^-([0-9])/gu.test(sreturn)){
      sreturn = '-' + sreturn;
    }
    return sreturn;
  }
 
  function sbe_item_sheet_clear_input(html,sIdentifier,triggeronchange=true){  
    let elementInput= null;
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      elementInput[0].value= '';
      if(triggeronchange){
        // trigger onchange event
        const event = new Event('change', { bubbles: true });       
        elementInput[0].dispatchEvent(event); 
      }
    }
  }
  
  async function sbe_item_sheet_clear_all(gItemSheet,html,typeClass){
    let bOkToProceed=true;  
    const bRequireConfirmation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE);
    if (bRequireConfirmation){
      bOkToProceed=await sbe_item_sheet_confirmdialog('Confirm Clear All','This will overwrite fields with <b>Clear</b> option, do you want to proceed?<br><br> To avoid this confirmation dialog, you can change <b>Confirm batch overwrite</b> in Settings' );
    }
    if (bOkToProceed){
      switch(typeClass) {    
        case 'PROPERTY':
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKEDPATH.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].UNCHECKEDPATH.IDENTIFIER,false);
          break;
        case "MULTIPANEL":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER,false);
          break; 
        case "PANEL":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER,false); 
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].IMAGEPATH.IDENTIFIER,false);
          break; 
        case "TAB":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].IMAGEPATH.IDENTIFIER,false);
          break; 
        case "GROUP":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          break;   
        case "cITEM":            
          break;  
        default:
          break;            
      }
      // trigger onsubmit event
      gItemSheet.submit();
    }
  }
  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       Item Sheet dropdowns                       
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  function sbe_item_sheet_dropdown_content_element (html,sItemID, sAttribute){
    let elementDropDownContent=html.find(`#`+ sItemID  + `-sbe-dropdown-`+ sAttribute +`-content`)[0];
    return elementDropDownContent;
  } 
  
  function sbe_item_sheet_dropdown_btn_element (html,sItemID, sAttribute,elementDropDownContent){
    let elementDropDownButton=html.find(`#`+ sItemID  + `-sbe-dropdown-`+ sAttribute +`-btn`)[0];
    if (elementDropDownButton!=null && elementDropDownContent!=null){                                                    
      // register event listeners for dropdown
      elementDropDownButton.addEventListener("click",function(){sbe_item_sheet_dropdown_toggle(elementDropDownButton,elementDropDownContent,true);} );        
    }
    else{
      console.error('SandBox Extensions | Error adding dropdown listeners for attribute ' + sAttribute);
    } 
    return elementDropDownButton;
  }
  
  // with exclude
  function sbe_item_sheet_dropdown_close_all(elementDropDownButton=null,elementDropDownContent=null){    
    // sbe-dropdown-content
    let dropdowns = document.getElementsByClassName("sbe-dropdown-content");    
    for (let i = 0; i < dropdowns.length; i++) {
      let openDropdown = dropdowns[i];
      if(elementDropDownContent!=null){        
        if (openDropdown.id!=elementDropDownContent.id) {
           sbe_item_sheet_hide_element(openDropdown);         
        } 
      }
      else{
        sbe_item_sheet_hide_element(openDropdown);
      }
    }  
    // adjust menu dropdowns
    let dropdownsbtns = document.getElementsByClassName("sbe-action-menu-label");    
    for (let i = 0; i < dropdownsbtns.length; i++) {
      let openDropdownbtn = dropdownsbtns[i]; 
      if(elementDropDownButton!=null){       
        if (openDropdownbtn.id!=elementDropDownButton.id) {
           
          if (openDropdownbtn.children.length == 2) {      
            openDropdownbtn.children[1].classList.remove("fa-caret-up");
            openDropdownbtn.children[1].classList.add("fa-caret-down");
            openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')            
          }         
        }
      }
      else{
        if (openDropdownbtn.children.length == 2) {      
            openDropdownbtn.children[1].classList.remove("fa-caret-up");
            openDropdownbtn.children[1].classList.add("fa-caret-down");
            openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')            
        } 
      }
    }
    
    // adjust dropdown buttons
    //sbe-dropdown-btn        
    dropdownsbtns = document.getElementsByClassName("sbe-dropdown-btn");    
    for (let i = 0; i < dropdownsbtns.length; i++) {
      let openDropdownbtn = dropdownsbtns[i]; 
      if(elementDropDownButton!=null){       
        if (openDropdownbtn.id!=elementDropDownButton.id) {
          openDropdownbtn.classList.remove("fa-caret-up");      
          openDropdownbtn.classList.add("fa-caret-down");
          openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')         
        }
      }
      else{
        openDropdownbtn.classList.remove("fa-caret-up");      
        openDropdownbtn.classList.add("fa-caret-down");
        openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')
      }
    }
  }   
  
  function sbe_item_sheet_dropdown_toggle (elementDropDownButton,elementDropDownContent,closeall=false){
    if(closeall){    
      // close all other dropdowns      
      sbe_item_sheet_dropdown_close_all(elementDropDownButton,elementDropDownContent);
    }
    // now toggle target  
    if (elementDropDownContent!=null){
      sbe_item_sheet_toggle_element_display(elementDropDownContent);
    }
    if (elementDropDownButton!=null){
      elementDropDownButton.classList.toggle("fa-caret-down");
      elementDropDownButton.classList.toggle("fa-caret-up");
      // if this is a menu
      if (elementDropDownButton.children.length == 2) { 
        elementDropDownButton.children[1].classList.toggle("fa-caret-down");
        elementDropDownButton.children[1].classList.toggle("fa-caret-up");
      } 

      if (elementDropDownButton.title==game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip') ){
        elementDropDownButton.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-hide-tooltip') 
      } 
      else{
        elementDropDownButton.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')
      } 
    }
  }
             
  function sbe_item_sheet_dropdown_header(sItemID, sItemClass,sCaption='',sIcon='',inputelement=null){ 
    let sHeaderIcon='';   
    let sHeader='';
    let dropdownbuttomheight='';
    if(inputelement!==null && inputelement.length>0 ){
      const cssObj = getComputedStyle(inputelement[0],null);
      let height = cssObj.getPropertyValue("height");            
      dropdownbuttomheight='style="height:' + height + '"';      
    }
    if (sCaption!=''){
      if(sIcon!=''){
        sHeaderIcon=`<i class="`+ sIcon+`" ></i>`;
      }
      sHeader=`<div  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`"  class="sbe-dropdown">
          <label id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-btn" class="sbe-action-menu-label" title="`+game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')+`">`+sHeaderIcon+ ` ` + sCaption +` <i class="sbe-dropdown-menu-btn-icon fas fa-caret-down"></i></label> 
          <ul id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-content" class="sbe-dropdown-content sbe-dropdown-menu">`;
    } 
    else{ 
      
      sHeader=`<div  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`"  class="sbe-dropdown" style="line-height: 0px;">
          <i `+dropdownbuttomheight+`  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-btn" class="sbe-dropdown-btn  fas fa-caret-down" title="`+game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')+`"></i> 
          <ul id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-content" class="sbe-dropdown-content">`;
    }
    return sHeader;
  }   
  
 function sbe_item_sheet_dropdown_footer(){
   let sFooter=`</ul>
        </div>`;
   return sFooter;
 } 
 
  function sbe_item_sheet_dropdown_item(sItemClass,sItemFontAwesomeIcon,sItemCustomIcon=''){
    let sItem='';
    if (sItemCustomIcon==''){
      sItem='<li class="sbe-dropdown-item '+ sItemClass + '"  title="'+game.i18n.localize('sandbox-extensions.'+sItemClass+'-tooltip')+'"><i class="sbe-dropdown-item-icon ' + sItemFontAwesomeIcon +'" ></i> '+ game.i18n.localize('sandbox-extensions.'+sItemClass+'-caption')+' ' +'</li>';
    }
    else{
      sItem='<li class="sbe-dropdown-item '+ sItemClass + '"  title="'+game.i18n.localize('sandbox-extensions.'+sItemClass+'-tooltip')+'"><i class="sbe-dropdown-item-icon"><img class="sbe-dropdown-item-custom-icon" src="modules/sandbox-extensions/styles/icons/'+sItemCustomIcon+'" alt="'+sItemCustomIcon+'"></i> '+ game.i18n.localize('sandbox-extensions.'+sItemClass+'-caption')+' ' +'</li>';
    }      
    return sItem;
  }
  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                 Item Sheet Validation functions                  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  function sbe_item_sheet_validate_table_filter(itemName, tableFilter,typeClass) {  
    let sHeader= 'Table filter validation for ' + typeClass + ' [' + itemName +']';       
    
    if (tableFilter.length>0 && sbe_string_is_valid_table_filter(tableFilter)==null){                                                  
      let msg='Table Filter is invalid';        
      ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);                               
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  } 
  
  // function for validate check group
  function sbe_item_sheet_validate_checkgroup(itemName, validatingCheckgroup,typeClass) {  
    let sHeader= 'Check Group validation for ' + typeClass + ' [' + itemName +']';       
    // look for spaces, special characters, only allow semicolons,underscores, hyphens
    let format = /[ `½§£¤!@#$%^&*()+=\[\]{}':"\\|,.<>\/?~]/;
    if (format.test(validatingCheckgroup)){                                                  
      let msg='Check Group contains invalid characters';        
      ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);                               
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  } 
  
  // function for validate lists
  function sbe_item_sheet_validate_list(itemName, validatingList,typeClass) {  
    let sHeader= 'Options(a,b,c) validation for ' + typeClass + ' [' + itemName +']';       
    // look for spaces
    let format = /\s/;
    if (format.test(validatingList)){                                                  
      let msg='Options(a,b,c) contains invalid characters';        
      ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);                               
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  }
  
  // function for checking if this key is valid
  function sbe_item_sheet_validate_key(validatingitemtype,itemName, validatingitemid,typeClass,sKey,enforcedvalidation) {  
    let sHeader= 'Key validation for key [' + sKey + '] for ' + typeClass + ' [' + itemName +']'; 
    // use module validate function      
    const  objResult = SandboxKeyValidate(validatingitemtype,validatingitemid,sKey,enforcedvalidation);
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){    
      objResult.warnings.forEach(function(msg){
        ui.notifications.warn(sHeader + ' returned validation warning:<br>' + msg);      
      });  
       objResult.errors.forEach(function(msg){
        ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);      
      });                   
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  }
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                        Support functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//
  async function sbe_item_sheet_confirmdialog(sTitle,sQuestion){
    let dialog=new Promise((resolve,reject)=>{
      new Dialog({
        title: sTitle,
        content: '<p>' + sQuestion + '</p>' ,
        buttons: {
          ok: {
            icon:'<i class ="fas fa-check"></i>',
            label: "Ok",            
            callback: () => {resolve(true)}
          },
          cancel: { 
            icon:'<i class ="fas fa-times"></i>',
            label: "Cancel",            
            callback: () => {resolve(false)}
          }
        },
        default: "ok",
        close:  () => {resolve(false) }   
      }).render(true);             
    }); 
    let answer=await dialog;
    return answer;    
   }


function sbe_item_sheet_toggle_element_display(element) {
  if (element.style.display == "none" || element.style.display == "") {
    element.style.display = "block";
    // attempt to set the width of this
    try {
      // get parent
      let parentelement = element.parentElement;
      let inputelement = parentelement.previousSibling;
      const dropdownbuttonwidth = 25;
      let adjustedwidth = inputelement.clientWidth + dropdownbuttonwidth;
      element.style.width = adjustedwidth + 'px';
    } catch (err) {
      console.error('SBE - Error setting dropdown width ||'+ err);
    }
  } else {
    element.style.display = "none";
  }
} 
  
  function sbe_item_sheet_show_element(element){    
    element.style.display = "block";                  
  }
  function sbe_item_sheet_hide_element(element){    
    element.style.display = "none";                  
  }
 
  function sbe_item_sheet_get_game_setting(moduleID,settingName){
    let setting=game.settings.get(moduleID, settingName);    
    if (!setting) {
      return  '';
    }
    else{
      return setting;
    }
  }

                                                                 
  function sbe_item_sheet_to_slug(text,separator,useCase=stringCasing.CASING.CASE.NONE){
    let sReturn=text;
    const transliteratenonlatin=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN);
    const enforcedvalidation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION);
    if(transliteratenonlatin||enforcedvalidation){
      // alphabet transliterations
      sReturn=transliterate(sReturn);
    }
    
    if(enforcedvalidation){
      sReturn=sReturn.replace(INVALID_KEY_CHARACTERS.ENFORCED, '_'); 
    }
    else{
      sReturn=sReturn.replace(INVALID_KEY_CHARACTERS.DEFAULT, '_');          
    }          
    switch(useCase){
      case stringCasing.CASING.CASE.NONE:
        // no change        
        break;
      case stringCasing.CASING.CASE.LOWERCASE:
        sReturn=sReturn.toLowerCase();
        break;
      case stringCasing.CASING.CASE.UPPERCASE:
         sReturn=sReturn.toUpperCase();
        break;
      case stringCasing.CASING.CASE.TITLECASE:           
          sReturn=sReturn.replaceAll(stringCasing.CASING.SEPARATOR.KEY,' ');
          sReturn=sReturn.replaceAll(stringCasing.CASING.SEPARATOR.CSS,' ');
          sReturn= stringCasing.stringToTitleCase(sReturn);                             
        break;    
    }        
    if(separator==stringCasing.CASING.SEPARATOR.KEY){
      sReturn=sReturn.replaceAll(stringCasing.CASING.SEPARATOR.CSS, separator) ;
    }  
    if(separator==stringCasing.CASING.SEPARATOR.CSS){
      sReturn=sReturn.replaceAll(stringCasing.CASING.SEPARATOR.KEY, separator) ;
    }        
    sReturn=sReturn.replace(/\s+/g, separator) ; 
    sReturn=sReturn.trim();
    return sReturn;
  }  

function sbe_running_required_game_system(requiredsystem,requiredversion,exactversion=false){
  let runningsystemname=game.system.data.name; // sandbox
  let runningversion=game.system.data.version;
  let returnvalue=false; // assume fail
  if  (runningsystemname==requiredsystem || requiredsystem==""){ 
  	let result=runningversion.localeCompare(requiredversion, undefined, { numeric: true, sensitivity: 'base' });
    if(exactversion){
      if(result==0){
      	returnvalue=true;
      }
    }
    else{
      if(result==1 || result==0){
      	returnvalue=true;
      }
    }
  }
  return returnvalue;
}
  
 
  





 