   // export const needed by ModuleSettingsForm
   export const _module_id='sandbox-extensions';  // modules true name(id)
   export const _module_ignore_settings=[];       // array of strings containing settings that should not be displayed, can be empty []
     
   import { ModuleSettingsForm } from "./module-settings-form.js";
   import { SandboxKeyCheckerForm } from "./sandbox-key-checker-form.js";
   import { INVALID_KEY_CHARACTERS } from "./sandbox-key-validate.js";
   import { SandboxKeyValidate } from "./sandbox-key-validate.js";
   
   import { SandboxExpressionEditorForm } from "./sandbox-expression-editor-form.js";
  
   import { transliterate  } from "./transliteration_2.1.8_bundle.esm.min.js";       
   
   class SandboxExtensions {
    lastItemId='';
    static ID = _module_id ;  // moduleID         
    
    static CONSTANTS={
      CASE:{                
        NONE:"None",
        LOWERCASE:"Lower case",
        UPPERCASE:"Upper case",
        TITLECASE:"Title case"
      },
      CASENR:["None","Lower case","Upper case","Title case"],
      SEPARATOR:{
        KEY:"_",
        CSS:"-"
      }
    }
    
    static SETTINGS =  { 
      AUTOGEN :{                           
        SETTINGS_FORM: 'SETTINGS_FORM',
        KEY_CHECKER_FORM: 'KEY_CHECKER_FORM',
        
        PREFIX_PROPERTY: 'PREFIX_PROPERTY',
        
        PREFIX_PROPERTY_SIMPLETEXT: 'PREFIX_PROPERTY_SIMPLETEXT',
        PREFIX_PROPERTY_SIMPLENUMERIC: 'PREFIX_PROPERTY_SIMPLENUMERIC',
        PREFIX_PROPERTY_CHECKBOX: 'PREFIX_PROPERTY_CHECKBOX',
        PREFIX_PROPERTY_RADIO: 'PREFIX_PROPERTY_RADIO',
        PREFIX_PROPERTY_TEXTAREA: 'PREFIX_PROPERTY_TEXTAREA',
        PREFIX_PROPERTY_LIST: 'PREFIX_PROPERTY_LIST',
        PREFIX_PROPERTY_LABEL: 'PREFIX_PROPERTY_LABEL',
        PREFIX_PROPERTY_BADGE: 'PREFIX_PROPERTY_BADGE',
        PREFIX_PROPERTY_TABLE: 'PREFIX_PROPERTY_TABLE',
        PREFIX_PROPERTY_BUTTON: 'PREFIX_PROPERTY_BUTTON',
        
        PREFIX_PANEL: 'PREFIX_PANEL', 
        PREFIX_MULTIPANEL: 'PREFIX_MULTIPANEL',
        PREFIX_GROUP: 'PREFIX_GROUP',
        PREFIX_TAB: 'PREFIX_TAB',
        SUFFIX_FONTGROUP:'SUFFIX_FONTGROUP',
        SUFFIX_INPUTGROUP:'SUFFIX_INPUTGROUP',
        SUFFIX_HEADERGROUP:'SUFFIX_HEADERGROUP',
        SUFFIX_ROLLID:'SUFFIX_ROLLID', 
        SUFFIX_ROLLNAME:'SUFFIX_ROLLNAME',
        OPTION_KEY_CONVERT_TO_CASE:'OPTION_KEY_CONVERT_TO_CASE',
        OPTION_CSS_CONVERT_TO_CASE:'OPTION_CSS_CONVERT_TO_CASE',
        OPTION_ENFORCED_VALIDATION:'OPTION_ENFORCED_VALIDATION',
        OPTION_CONFIRM_BATCH_OVERWRITE:'OPTION_CONFIRM_BATCH_OVERWRITE',
        OPTION_SHOW_ITEM_HELPERS:'OPTION_SHOW_ITEM_HELPERS',
        OPTION_ACTIVATE_ITEM_DELETE_PROTECTION:'OPTION_ACTIVATE_ITEM_DELETE_PROTECTION',
        OPTION_USE_DATATYPE_PREFIX:'OPTION_USE_DATATYPE_PREFIX',
        OPTION_USE_PREFIX_SUFFIX:'OPTION_USE_PREFIX_SUFFIX',
        OPTION_TRANSLITERATE_NON_LATIN:'OPTION_TRANSLITERATE_NON_LATIN',
        OPTION_SET_DEFAULT_ITEM_TAB:'OPTION_SET_DEFAULT_ITEM_TAB',
        OPTION_ADAPT_ITEM_SHEET_POSITION:'OPTION_ADAPT_ITEM_SHEET_POSITION',
        OPTION_NUMBER:'OPTION_NUMBER',
        OPTION_BOOLEAN:'OPTION_BOOLEAN',
        OPTION_FILEPICKER:'OPTION_FILEPICKER'
      }
    }    
    
    static DEFAULT_SETTINGS={  
      AUTOGEN :{
        PREFIX_PROPERTY: 'PROPERTY',
        
        PREFIX_PROPERTY_SIMPLETEXT: 'TXT',
        PREFIX_PROPERTY_SIMPLENUMERIC: 'NUM',
        PREFIX_PROPERTY_CHECKBOX: 'CHK',
        PREFIX_PROPERTY_RADIO: 'RDO',
        PREFIX_PROPERTY_TEXTAREA: 'TXA',
        PREFIX_PROPERTY_LIST: 'LST',
        PREFIX_PROPERTY_LABEL: 'LBL',
        PREFIX_PROPERTY_BADGE: 'BDG',
        PREFIX_PROPERTY_TABLE: 'TBL',
        PREFIX_PROPERTY_BUTTON: 'BTN',
        
        PREFIX_PANEL: 'PANEL', 
        PREFIX_MULTIPANEL: 'MULTIPANEL',
        PREFIX_GROUP: 'GROUP',
        PREFIX_TAB: 'TAB',
        SUFFIX_FONTGROUP:'FONTGROUP',
        SUFFIX_INPUTGROUP:'INPUTGROUP',
        SUFFIX_HEADERGROUP:'HEADERGROUP',
        SUFFIX_ROLLID:'ROLL',
        SUFFIX_ROLLNAME:'Roll',
        OPTION_KEY_CONVERT_TO_CASE:2,
        OPTION_CSS_CONVERT_TO_CASE:1,
        OPTION_ENFORCED_VALIDATION:'', // empty means false, non-empty is true
        OPTION_CONFIRM_BATCH_OVERWRITE:true,
        OPTION_SHOW_ITEM_HELPERS:true,
        OPTION_ACTIVATE_ITEM_DELETE_PROTECTION:true,
        OPTION_USE_DATATYPE_PREFIX:true,
        OPTION_USE_PREFIX_SUFFIX:true,
        OPTION_TRANSLITERATE_NON_LATIN:true,
        OPTION_SET_DEFAULT_ITEM_TAB:true,
        OPTION_ADAPT_ITEM_SHEET_POSITION:true
      }
    }      
    //                                                                  
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    //                                                                  
    //                          Class Methods                           
    //                                                                  
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    //                                                                  
    
    // ---------------------------------------------------------------- 
    // Initialize                                                       
    // ----------------------------------------------------------------     
    static initialize() {     
      // ---------------------------------------------------------------- 
      // Settings registrations for menus in Settings form                                           
      // ----------------------------------------------------------------  
      // menu for KEY_CHECKER_FORM
      game.settings.registerMenu(this.ID, this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Name`,
        label: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Name`,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Hint`,
        icon: "fas fa-arrow-alt-circle-right",
        type: SandboxKeyCheckerForm,
        restricted: true
        }); 
      // menu for the Module Setting Form 
      game.settings.registerMenu(this.ID, this.SETTINGS.AUTOGEN.SETTINGS_FORM, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
        label: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Hint`,
        icon: "fas fa-cog",
        type: ModuleSettingsForm,
        restricted: true
      }); 
      // ---------------------------------------------------------------- 
      // Settings registrations for module                                           
      // ----------------------------------------------------------------  
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}`,
        type: Boolean,
        scope: 'user',
        config: true,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION}.Hint`        
      });             
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Hint`        
      });         
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION}.Hint`        
      });       
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB}.Hint`        
      });      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}`,
        type: String, 
        choices: {
          0: this.CONSTANTS.CASE.NONE,
          1: this.CONSTANTS.CASE.LOWERCASE,
          2: this.CONSTANTS.CASE.UPPERCASE,
          3: this.CONSTANTS.CASE.TITLECASE
        },        
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}`,
        type: String, 
        choices: {
          0: this.CONSTANTS.CASE.NONE,
          1: this.CONSTANTS.CASE.LOWERCASE,
          2: this.CONSTANTS.CASE.UPPERCASE,
          3: this.CONSTANTS.CASE.TITLECASE
        },        
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Hint`        
      });
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN}.Hint`        
      });
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX}.Hint`        
      });
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Hint`        
      }); 
      //
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON}.Hint`        
      });
      
      
      //
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PANEL, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PANEL}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PANEL}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PANEL}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_GROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_GROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_GROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_GROUP}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_TAB, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_TAB}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_TAB}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_TAB}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Hint`        
      });         
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_ROLLID, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_ROLLID}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Hint`        
      });      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME}.Hint`        
      });                         
    }
  } 
  
  //                                                                  
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  //                                                                  
  //                           Module hooks                           
  //                                                                  
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  // 
  
  Hooks.once('init', () => {     
    SandboxExtensions.initialize();
  });
  
  const TYPECLASS={
    ITEM:'ITEM',
    PROPERTY:'PROPERTY',
    MULTIPANEL:'MULTIPANEL',
    PANEL:'PANEL',
    TAB:'TAB',
    GROUP:'GROUP',
    CITEM:'CITEM'
  };
  
  // constants used based on item sheet html()
  // The order attributes appear in this object are used for exports
  const ITEMATTRIBUTE={
    ITEM:{
      NAME:                  {ATTRIBUTE:'name',              IDENTIFIER:'input[name="name"]',                CAPTION:'Name'               ,LINEBREAKER:''    ,DEFAULT:''}, 
      TYPECLASS:             {ATTRIBUTE:'typeclass',         IDENTIFIER:'.typelabel',                        CAPTION:'Item Type'          ,LINEBREAKER:''    ,DEFAULT:''}
    },  
    
    PROPERTY:{
      DATATYPE:              {ATTRIBUTE:'datatype',          IDENTIFIER:'select[name="data.datatype"]',      CAPTION:'Data Type'          ,LINEBREAKER:''    ,DEFAULT:''},
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.attKey"]',         CAPTION:'Key'                ,LINEBREAKER:''    ,DEFAULT:''},
      DEFAULT:               {ATTRIBUTE:'default',           IDENTIFIER:'input[name="data.defvalue"]',       CAPTION:'Default Value'      ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.tag"]',            CAPTION:'Tag'                ,LINEBREAKER:''    ,DEFAULT:''}, 
      TOOLTIP:               {ATTRIBUTE:'tooltip',           IDENTIFIER:'textarea[name="data.tooltip"]',     CAPTION:'Tooltip'            ,LINEBREAKER:''    ,DEFAULT:''},
      
      ISHIDDEN:              {ATTRIBUTE:'ishidden',          IDENTIFIER:'input[name="data.ishidden"]',       CAPTION:'Hidden'             ,LINEBREAKER:''    ,DEFAULT:'false'},
      EDITABLE:              {ATTRIBUTE:'editable',          IDENTIFIER:'input[name="data.editable"]',       CAPTION:'Editable'           ,LINEBREAKER:''    ,DEFAULT:'true'}, 
      HASLABEL:              {ATTRIBUTE:'haslabel',          IDENTIFIER:'input[name="data.haslabel"]',       CAPTION:'Has Label'          ,LINEBREAKER:''    ,DEFAULT:'true'},     
      LABELSIZE:             {ATTRIBUTE:'labelsize',         IDENTIFIER:'select[name="data.labelsize"]',     CAPTION:'Label Size'         ,LINEBREAKER:''    ,DEFAULT:'Fit'},
      LABELFORMAT:           {ATTRIBUTE:'labelformat',       IDENTIFIER:'select[name="data.labelformat"]',   CAPTION:'Label Format'       ,LINEBREAKER:''    ,DEFAULT:'Normal'},
      INPUTSIZE:             {ATTRIBUTE:'inputsize',         IDENTIFIER:'select[name="data.inputsize"]',     CAPTION:'Input Size'         ,LINEBREAKER:''    ,DEFAULT:'Fit'}, 
       
      FONTGROUP:             {ATTRIBUTE:'fontgroup',         IDENTIFIER:'input[name="data.fontgroup"]',      CAPTION:'Font Group'         ,LINEBREAKER:' '    ,DEFAULT:''},      
      INPUTGROUP:            {ATTRIBUTE:'inputgroup',        IDENTIFIER:'input[name="data.inputgroup"]',     CAPTION:'Input Group'        ,LINEBREAKER:' '    ,DEFAULT:''},      
      
      MACRO:                 {ATTRIBUTE:'macro',         IDENTIFIER:'select[name="data.macroid"]',     CAPTION:'Macro'         ,LINEBREAKER:''    ,DEFAULT:'No Macro'},
       
      ROLLABLE:              {ATTRIBUTE:'rollable',          IDENTIFIER:'input[name="data.hasroll"]',        CAPTION:'Rollable'           ,LINEBREAKER:''    ,DEFAULT:'false'},   
      ROLLNAME:              {ATTRIBUTE:'rollname',          IDENTIFIER:'input[name="data.rollname"]',       CAPTION:'Roll Name'          ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      ROLLID:                {ATTRIBUTE:'rollid',            IDENTIFIER:'input[name="data.rollid"]',         CAPTION:'Roll ID'            ,LINEBREAKER:''    ,DEFAULT:''},  
      ROLLEXP:               {ATTRIBUTE:'rollexp',           IDENTIFIER:'input[name="data.rollexp"]',        CAPTION:'Roll Formula'       ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      
      HASDIALOG:             {ATTRIBUTE:'hasdialog',         IDENTIFIER:'input[name="data.hasdialog"]',      CAPTION:'Has Dialog'         ,LINEBREAKER:''    ,DEFAULT:'false'}, 
      DIALOGPANEL:           {ATTRIBUTE:'dialogpanel',       IDENTIFIER:'input[name="data.dialogName"]',     CAPTION:'Dialog Panel'       ,LINEBREAKER:''    ,DEFAULT:''}, 
      
      AUTO:                  {ATTRIBUTE:'auto',              IDENTIFIER:'input[name="data.auto"]',           CAPTION:'Auto'               ,LINEBREAKER:'  '    ,DEFAULT:''},
      AUTOMAX:               {ATTRIBUTE:'automax',           IDENTIFIER:'input[name="data.automax"]',        CAPTION:'Max Value'          ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      MAXVISIBLE:            {ATTRIBUTE:'maxvisible',        IDENTIFIER:'input[name="data.maxvisible"]',     CAPTION:'Max Visible'        ,LINEBREAKER:''    ,DEFAULT:'true'},
      MAXTOP:                {ATTRIBUTE:'maxtop',            IDENTIFIER:'input[name="data.maxtop"]',         CAPTION:'Max Top'            ,LINEBREAKER:''    ,DEFAULT:'true'},
      
      CHECKGROUP:            {ATTRIBUTE:'checkgroup',        IDENTIFIER:'input[name="data.checkgroup"]',     CAPTION:'Check Group'        ,LINEBREAKER:';'    ,DEFAULT:''},
      CUSTOMIMAGE:           {ATTRIBUTE:'customimage',       IDENTIFIER:'input[name="data.customcheck"]',    CAPTION:'Custom Image'       ,LINEBREAKER:''    ,DEFAULT:'false'},
      CHECKEDPATH:           {ATTRIBUTE:'checkedpath',       IDENTIFIER:'input[name="data.onPath"]',         CAPTION:'Checked Path'       ,LINEBREAKER:''    ,DEFAULT:''},
      UNCHECKEDPATH:         {ATTRIBUTE:'uncheckedpath',     IDENTIFIER:'input[name="data.offPath"]',        CAPTION:'Unchecked Path'     ,LINEBREAKER:''    ,DEFAULT:''},
            
      RADIOTYPE:             {ATTRIBUTE:'radiotype',         IDENTIFIER:'select[name="data.radiotype"]',     CAPTION:'Radio Type'         ,LINEBREAKER:''    ,DEFAULT:'Circle'},
      LIST:                  {ATTRIBUTE:'list',              IDENTIFIER:'input[name="data.listoptions"]',    CAPTION:'Options (a,b,c)'    ,LINEBREAKER:','    ,DEFAULT:''},
      
      GROUP:                 {ATTRIBUTE:'group',             IDENTIFIER:'input[name="data.group.name"]',     CAPTION:'Group'              ,LINEBREAKER:''    ,DEFAULT:''},
      HASHEADER:             {ATTRIBUTE:'hasheader',         IDENTIFIER:'input[name="data.hasheader"]',      CAPTION:'Has Header'         ,LINEBREAKER:''    ,DEFAULT:'true'},
      COLUMNNAME:            {ATTRIBUTE:'columnname',        IDENTIFIER:'input[name="data.namecolumn"]',     CAPTION:'ColumnName'         ,LINEBREAKER:''    ,DEFAULT:''},
      ISFREE:                {ATTRIBUTE:'isfree',            IDENTIFIER:'input[name="data.isfreetable"]',    CAPTION:'Is Free'            ,LINEBREAKER:''    ,DEFAULT:'false'},
      TRANSFERABLE:          {ATTRIBUTE:'transferable',      IDENTIFIER:'input[name="data.transferrable"]',  CAPTION:'Transferable'       ,LINEBREAKER:''    ,DEFAULT:'false'},
      HEIGHT:                {ATTRIBUTE:'height',            IDENTIFIER:'select[name="data.tableheight"]',   CAPTION:'Height'             ,LINEBREAKER:''    ,DEFAULT:'FREE'},
      ITEMNAMES:             {ATTRIBUTE:'itemnames',         IDENTIFIER:'select[name="data.onlynames"]',     CAPTION:'Item Names'         ,LINEBREAKER:''    ,DEFAULT:'YES'},
      SHOWUNITS:             {ATTRIBUTE:'showunits',         IDENTIFIER:'input[name="data.hasunits"]',       CAPTION:'Show Units'         ,LINEBREAKER:''    ,DEFAULT:'true'},
      SHOWUSES:              {ATTRIBUTE:'showuses',          IDENTIFIER:'input[name="data.hasuses"]',        CAPTION:'Show Uses'          ,LINEBREAKER:''    ,DEFAULT:'true'},
      SHOWACTIVATION:        {ATTRIBUTE:'showactivation',    IDENTIFIER:'input[name="data.hasactivation"]',  CAPTION:'Show Activation'    ,LINEBREAKER:''    ,DEFAULT:'false'},
      SHOWTOTALS:            {ATTRIBUTE:'showtotals',        IDENTIFIER:'input[name="data.hastotals"]',      CAPTION:'Show Totals'        ,LINEBREAKER:''    ,DEFAULT:'false'}
    },    
    
    MULTIPANEL:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.panelKey"]',       CAPTION:'Panel Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      WIDTH:                 {ATTRIBUTE:'width',             IDENTIFIER:'select[name="data.width"]',         CAPTION:'Width'              ,LINEBREAKER:''    ,DEFAULT:'1'},
      HEADERGROUP:           {ATTRIBUTE:'headergroup',       IDENTIFIER:'input[name="data.headergroup"]',    CAPTION:'Header Group'       ,LINEBREAKER:' '   ,DEFAULT:''},
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},                    
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''}
    },
    
    PANEL:{ 
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.panelKey"]',       CAPTION:'Panel Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      WIDTH:                 {ATTRIBUTE:'width',             IDENTIFIER:'select[name="data.width"]',         CAPTION:'Width'              ,LINEBREAKER:''    ,DEFAULT:'1'},
       
      COLUMNS:               {ATTRIBUTE:'columns',           IDENTIFIER:'select[name="data.columns"]',       CAPTION:'Columns'            ,LINEBREAKER:''    ,DEFAULT:'1'},
      CONTENTALIGNMENT:      {ATTRIBUTE:'contentalignment',  IDENTIFIER:'select[name="data.contentalign"]',  CAPTION:'Content Alignment'  ,LINEBREAKER:''    ,DEFAULT:'left'},
      LABELALIGNMENT:        {ATTRIBUTE:'labelalignment',    IDENTIFIER:'select[name="data.alignment"]',     CAPTION:'Label Alignment'    ,LINEBREAKER:''    ,DEFAULT:'left'},
      TITLEBACKGROUND:       {ATTRIBUTE:'titlebackground',   IDENTIFIER:'select[name="data.backg"]',         CAPTION:'Title Background'   ,LINEBREAKER:''    ,DEFAULT:'DEFAULT'},
      ISIMAGE:               {ATTRIBUTE:'isimage',           IDENTIFIER:'input[name="data.isimg"]',          CAPTION:'Is Image'           ,LINEBREAKER:''    ,DEFAULT:'false'},
      IMAGEPATH:             {ATTRIBUTE:'imgsrc',            IDENTIFIER:'input[name="data.imgsrc"]',         CAPTION:'Image Path'         ,LINEBREAKER:''    ,DEFAULT:''},       
       
      FONTGROUP:             {ATTRIBUTE:'fontgroup',         IDENTIFIER:'input[name="data.fontgroup"]',      CAPTION:'Font Group'         ,LINEBREAKER:' '   ,DEFAULT:''},      
      INPUTGROUP:            {ATTRIBUTE:'inputgroup',        IDENTIFIER:'input[name="data.inputgroup"]',     CAPTION:'Input Group'        ,LINEBREAKER:' '   ,DEFAULT:''},
      HEADERGROUP:           {ATTRIBUTE:'headergroup',       IDENTIFIER:'input[name="data.headergroup"]',    CAPTION:'Header Group'       ,LINEBREAKER:' '   ,DEFAULT:''},
      
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''}                      
    },
    
    TAB:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.tabKey"]',         CAPTION:'Tab Key'            ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      CONTROL:               {ATTRIBUTE:'control',           IDENTIFIER:'select[name="data.controlby"]',     CAPTION:'Control'            ,LINEBREAKER:''    ,DEFAULT:'public'},
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''} 
    },
          
    GROUP:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.groupKey"]',       CAPTION:'Group Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      ISUNIQUE:              {ATTRIBUTE:'isunique',          IDENTIFIER:'input[name="data.isUnique"]',       CAPTION:'Is Unique'          ,LINEBREAKER:''    ,DEFAULT:'false'}     
    },
    
    CITEM:{
      ROLLEXP:               {ATTRIBUTE:'rollexp',           IDENTIFIER:'input[name="data.roll"]',           CAPTION:'Roll Formula'       ,LINEBREAKER:'  '  ,DEFAULT:''}, 
      ROLLNAME:              {ATTRIBUTE:'rollname',          IDENTIFIER:'input[name="data.rollname"]',       CAPTION:'Roll Name'          ,LINEBREAKER:'  '  ,DEFAULT:''}, 
      ROLLID:                {ATTRIBUTE:'rollid',            IDENTIFIER:'input[name="data.rollid"]',         CAPTION:'Roll ID'            ,LINEBREAKER:''    ,DEFAULT:''}
    }
  };
const ITEM_SHEET_DEFAULT_HEIGHT=500+25; // default + detail menu height

const ITEM_SHEET_HEIGHT={
  PROPERTY:ITEM_SHEET_DEFAULT_HEIGHT,
  PANEL:ITEM_SHEET_DEFAULT_HEIGHT + 75,
  MULTIPANEL:ITEM_SHEET_DEFAULT_HEIGHT,
  GROUP:ITEM_SHEET_DEFAULT_HEIGHT,
  TAB:ITEM_SHEET_DEFAULT_HEIGHT,
  CITEM:ITEM_SHEET_DEFAULT_HEIGHT
}; 

const ITEM_SHEET_PROPERTY_HEIGHT={
  
    SIMPLETEXT     : 875,
    SIMPLENUMERIC  : 890,
    CHECKBOX       : 800,
    RADIO          : 875,
    TEXTAREA       : 815,
    LIST           : 890,
    LABEL          : 700,
    BADGE          : 875,
    TABLE          : 875,
    BUTTON         : 550
  
}; 
const ITEM_SHEET_DEFAULT_WIDTH=630;

const ITEM_SHEET_TABS={
  PROPERTY:{
    DESCRIPTION:'description',
    DETAILS:'details'
  },
  PANEL:{
    DESCRIPTION:'description',
    DETAILS:'details',
    PROPERTIES:'properties'
  },
  MULTIPANEL:{
    DESCRIPTION:'description',
    DETAILS:'details',
    PANELS:'properties'
  },
  GROUP:{
    DESCRIPTION:'description',
    DETAILS:'details',
    PROPERTIES:'properties'
  },
  TAB:{
    DESCRIPTION:'description',
    DETAILS:'details',
    PANELS:'properties'
  },
  CITEM:{
    DESCRIPTION:'description',
    ATTRIBUTES:'attributes',
    GROUPS:'groups',
    MODS:'mods'
  }
};
   
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       Sheet hook functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//     

Hooks.on('renderItemSheet', (gItemSheet, html) => {
  sbe_item_sheet_delete_protection(html);
  const showitemhelpers = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_SHOW_ITEM_HELPERS);
  if (showitemhelpers) {
    let itemName;
    let hasKey = false;
    let hasTag = false;
    let hasTooltip = false;
    let hasFontGroup = false;
    let hasInputGroup = false;
    let hasHeaderGroup = false;
    let hasRollExp = false;
    let hasRollName = false;
    let hasRollID = false;
    let hasAuto = false;
    let hasAutoMax = false;
    let hasDefault = false;
    let hasCheckGroup = false;
    let hasList = false;
    let hasConditionVisibleIf = false;
    let hasConditionVisibleValue = false;
    let detailstabname='details';
    

    let itemid = gItemSheet.object.data._id;
    if (itemid != '') {
      SandboxExtensions.lastItemId = itemid;
    } else {
      // cant get the itemid
      console.error("SandboxExtensions || Cant get itemid, reusing last from class object");
      itemid = SandboxExtensions.lastItemId;
    }
    
    // get the name of the item
    itemName = sbe_item_sheet_get_input(html, 'name', 'ITEM')[0].value;
    // find typeclass
    const typeClass = html.find(`${ITEMATTRIBUTE.ITEM.TYPECLASS.IDENTIFIER}`)[0].innerText;
    let sheetheight=ITEM_SHEET_HEIGHT[typeClass]; 
    // depending on typeclass
    switch (typeClass) {
      case 'PROPERTY':
        hasKey = true;
        hasTag = true;
        hasTooltip = true;
        hasFontGroup = true;
        hasInputGroup = true;
        hasRollExp = true;
        hasRollName = true;
        hasRollID = true;
        hasAuto = true;
        hasAutoMax = true;
        hasDefault = true;
        hasCheckGroup = true;
        hasList = true;
        
        break;
      case "MULTIPANEL":
        hasKey = true;
        hasTag = true;
        hasHeaderGroup = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;
        break;
      case "PANEL":
        hasKey = true;
        hasTag = true;
        hasFontGroup = true;
        hasInputGroup = true;
        hasHeaderGroup = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;
        
        break;
      case "TAB":
        hasKey = true;
        hasTag = true;
        hasConditionVisibleIf = true;
        hasConditionVisibleValue = true;
        break;
      case "GROUP":
        hasKey = true;
        break;
      case "cITEM":
        hasRollExp = true;
        hasRollName = true;
        hasRollID = true;
        detailstabname='attributes';
        break;
      default:
      // nothing
    }
   
    
    const adaptitemsheetgeometrics = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ADAPT_ITEM_SHEET_POSITION);
    if (adaptitemsheetgeometrics) {
      if (game.user.isGM) {
        // make room for details menu by  increasing the item sheet window height                    
        // for updates the return html is a form
        if (html[0].nodeName !== 'FORM') {
          if (typeClass === 'PROPERTY') {
            const datatype = sbe_item_sheet_get_input(html, ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE, 'PROPERTY')[0].value;
            sheetheight = ITEM_SHEET_PROPERTY_HEIGHT[datatype.toUpperCase()];
          }
          // center window
          let newtop = (window.innerHeight - (sheetheight)) / 2;
          if (newtop < 0) {
            newtop = 0;
          }
          gItemSheet.setPosition({top: newtop});
          gItemSheet.setPosition({height: sheetheight, width: ITEM_SHEET_DEFAULT_WIDTH});
        }
      }
    }
  
    const setdefaultitemtab = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_SET_DEFAULT_ITEM_TAB);
    if (setdefaultitemtab ) {
      if (game.user.isGM) {
        if (html[0].nodeName !== 'FORM') {
          // activate tab
          gItemSheet._tabs[0].activate(detailstabname);
        }
      }
    }
    // ---------------------------------------------------------------- 
    // details menu     
    // ----------------------------------------------------------------
    let elementDetails = 'div[data-tab="details"]> div:nth-child(1)';
  
    let divDetails = html.find(`${elementDetails}`);
    if (divDetails != null && divDetails.length > 0) {

      let sMenu = `        
            <div class="sbe-sheet-item-menu"> 
              <label id="sbe-action-menu-autogenerate-all-visible-fields" class="sbe-action-menu-label" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-autogenerate-all-visible-fields-tooltip') + `"><i class="fas fa-magic"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-autogenerate-all-visible-fields-caption') + `</label>
              <label id="sbe-action-menu-validate-all-visible-fields" class="sbe-action-menu-label" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-validate-all-visible-fields-tooltip') + `"><i class="fas fa-spell-check"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-validate-all-visible-fields-caption') + `</label>
               `
              + sbe_item_sheet_dropdown_header(itemid, 'exports', 'Copy As', 'fas fa-copy')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-html', 'fab fa-html5')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-markdown', 'fab fa-markdown')
              + sbe_item_sheet_dropdown_item('sbe-export-copy-visible-as-plaintext', 'fas fa-table')
              + sbe_item_sheet_dropdown_footer()
              + `
              <label id="sbe-action-menu-clear-all-visible-fields" class="sbe-action-menu-label" style="" title="` + game.i18n.localize('sandbox-extensions.sbe-action-menu-clear-all-visible-fields-tooltip') + `"><i class="fas fa-times-circle"></i> ` + game.i18n.localize('sandbox-extensions.sbe-action-menu-clear-all-visible-fields-caption') + `</label>          
              <label id="sbe-item-sheet-display-sandbox-extensions-config" class="sbe-action-menu-label" style="" title="` + game.i18n.localize('sandbox-extensions.sbe-item-sheet-display-sandbox-extensions-config-tooltip') + `"><i class="fas fa-cog"></i> ` + game.i18n.localize('sandbox-extensions.sbe-item-sheet-display-sandbox-extensions-config-caption') + `</label>

            </div>
            <div class="sbe-sheet-item-menu-placeholder"></div> `;
      divDetails.before(sMenu);
      let sAttribute = 'exports';
      // register event listeners for labels 
      html.find('#sbe-item-sheet-display-sandbox-extensions-config').click(ev => {
        let f = new ModuleSettingsForm();
        f.render(true);
      });
      // auto generate all       
      html.find('#sbe-action-menu-autogenerate-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        sbe_item_sheet_autogenerate_all(gItemSheet,html, typeClass);
      });
      // validate all
      html.find('#sbe-action-menu-validate-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        switch (typeClass) {
          case 'PROPERTY':
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
            break;
          case "MULTIPANEL":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "PANEL":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "TAB":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "GROUP":
            sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
            break;
          case "cITEM":
            break;
          default:
            break;
        }
      });
      // clear all
      html.find('#sbe-action-menu-clear-all-visible-fields').click(ev => {
        sbe_item_sheet_dropdown_close_all();
        sbe_item_sheet_clear_all(gItemSheet,html, typeClass);
      });
      // register event listeners for dropdown      
      let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
      let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
      // register event listeners for dropdown items
      html.find('.sbe-export-copy-visible-as-html').click(ev => {
        sbe_item_sheet_export_data_html(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
      html.find('.sbe-export-copy-visible-as-markdown').click(ev => {
        sbe_item_sheet_export_data_markdown(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
      html.find('.sbe-export-copy-visible-as-plaintext').click(ev => {
        sbe_item_sheet_export_data_plaintext(html, typeClass);
        sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
      });
    }
    // ---------------------------------------------------------------- 
    // Key                                                              
    // ----------------------------------------------------------------                 
    if (hasKey) {
      // find the element which the key
      let inputKey = sbe_item_sheet_get_input(html, 'key', typeClass);
      
      if (inputKey != null && inputKey.length > 0) {
        sbe_item_sheet_set_title_from_value(inputKey);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.ATTRIBUTE, '', '', inputKey)
                + sbe_item_sheet_dropdown_item('sbe-generate-key', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-validate-key', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-cut-key', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-key', 'fas fa-copy');
        if (typeClass.toUpperCase() === 'PROPERTY') {
          sDropDown += sbe_item_sheet_dropdown_item('sbe-copy-key-as-actor-property', 'fas fa-at')
                  + sbe_item_sheet_dropdown_item('sbe-copy-key-as-citem-property', 'fas fa-hashtag')
                  + sbe_item_sheet_dropdown_item('sbe-copy-key-as-dialog-property', 'far fa-window-maximize', 'd.svg');
        }
        sDropDown += sbe_item_sheet_dropdown_item('sbe-paste-key', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-key', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputKey.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items   
        html.find('.sbe-generate-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass);
        });
        html.find('.sbe-validate-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY, typeClass, itemid);
        });
        html.find('.sbe-cut-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-actor-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_actor_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-citem-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_citem_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-copy-key-as-dialog-property').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_dialog_property(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-paste-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].KEY);
        });
        html.find('.sbe-clear-key').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()][sAttribute.toUpperCase()].IDENTIFIER);
        });
      }
    }

    // ---------------------------------------------------------------- 
    // Default Value                                                          
    // ----------------------------------------------------------------  
    if (hasDefault) {
      // find the element which has the value
      let inputDefault = sbe_item_sheet_get_input(html, 'default', typeClass);
      ;
      if (inputDefault != null && inputDefault.length > 0) {
        sbe_item_sheet_set_title_from_value(inputDefault);
        // insert a dropdown at the end of this element
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.ATTRIBUTE;
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'default')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-default', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-default', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-default', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-default', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-default', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputDefault.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-open-expression-editor-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT, typeClass, itemid);
        });
        html.find('.sbe-cut-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
        html.find('.sbe-copy-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
        html.find('.sbe-clear-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.IDENTIFIER);
        });
        html.find('.sbe-paste-default').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Tag/Title                                                        
    // ---------------------------------------------------------------- 
    if (hasTag) {
      // find the element
      let inputTag = sbe_item_sheet_get_input(html, 'tag', typeClass);
      if (inputTag != null && inputTag.length > 0) {
        sbe_item_sheet_set_title_from_value(inputTag);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'tag')
                + sbe_item_sheet_dropdown_item('sbe-generate-tag', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-cut-tag', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-tag', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-tag', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-tag', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputTag.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG, typeClass);
        });
        html.find('.sbe-cut-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-copy-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-paste-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG);
        });
        html.find('.sbe-clear-tag').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Tooltip                                                          
    // ----------------------------------------------------------------    
    if (hasTooltip) {
      // find the element
      let inputTooltip = sbe_item_sheet_get_input(html, 'tooltip', typeClass);
      if (inputTooltip != null && inputTooltip.length > 0) {
        sbe_item_sheet_set_title_from_value(inputTooltip);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'tooltip')
                + sbe_item_sheet_dropdown_item('sbe-generate-tooltip', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-cut-tooltip', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-tooltip', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-tooltip', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-tooltip', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputTooltip.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items 
        html.find('.sbe-generate-tooltip').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP, typeClass);
        });
        html.find('.sbe-cut-tooltip').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
        });
        html.find('.sbe-copy-tooltip').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
        });
        html.find('.sbe-paste-tooltip').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP);
        });
        html.find('.sbe-clear-tooltip').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Roll Name                                                        
    // ----------------------------------------------------------------  
    if (hasRollName) {
      // find roll name
      let inputRollName = sbe_item_sheet_get_input(html, 'rollname', typeClass);
      if (inputRollName != null && inputRollName.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollName);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollname')
                + sbe_item_sheet_dropdown_item('sbe-generate-rollname', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollname', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollname', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollname', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollname', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollname', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollName.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items        
        html.find('.sbe-generate-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME, typeClass);
        });
        html.find('.sbe-open-expression-editor-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME, typeClass, itemid);
        });
        html.find('.sbe-cut-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-copy-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-paste-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME);
        });
        html.find('.sbe-clear-rollname').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Roll ID                                                          
    // ----------------------------------------------------------------     
    if (hasRollID) {
      // find roll id
      let inputRollID = sbe_item_sheet_get_input(html, 'rollid', typeClass);
      if (inputRollID != null && inputRollID.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollID);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollid')
                + sbe_item_sheet_dropdown_item('sbe-generate-rollid', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollid', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollid', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollid', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollid', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollid', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollID.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items         
        let sBase;
        html.find('.sbe-generate-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID, typeClass);
        });
        html.find('.sbe-open-expression-editor-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID, typeClass, itemid);
        });
        html.find('.sbe-cut-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-copy-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-paste-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID);
        });
        html.find('.sbe-clear-rollid').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Roll Formula/Expression                                          
    // ----------------------------------------------------------------  
    if (hasRollExp) {
      // find roll exp element
      let inputRollExp = sbe_item_sheet_get_input(html, 'rollexp', typeClass);
      if (inputRollExp != null && inputRollExp.length > 0) {
        sbe_item_sheet_set_title_from_value(inputRollExp);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'rollexp')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-rollexp', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-rollexp', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-rollexp', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-rollexp', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-rollexp', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputRollExp.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items               
        html.find('.sbe-open-expression-editor-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP, typeClass, itemid);
        });
        html.find('.sbe-cut-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-copy-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-paste-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP);
        });
        html.find('.sbe-clear-rollexp').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Max Value                                                        
    // ---------------------------------------------------------------- 
    if (hasAutoMax) {
      // find field max
      let inputAutoMax = sbe_item_sheet_get_input(html, 'automax', typeClass);
      if (inputAutoMax != null && inputAutoMax.length > 0) {
        sbe_item_sheet_set_title_from_value(inputAutoMax);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'automax')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-automax', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-automax', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-automax', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-automax', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-automax', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputAutoMax.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items   
        html.find('.sbe-open-expression-editor-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX, typeClass, itemid);
        });
        html.find('.sbe-cut-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-copy-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-paste-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX);
        });
        html.find('.sbe-clear-automax').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Auto                                                             
    // ----------------------------------------------------------------        
    if (hasAuto) {
      // find field auto
      let inputAuto = sbe_item_sheet_get_input(html, 'auto', typeClass);
      if (inputAuto != null && inputAuto.length > 0) {
        sbe_item_sheet_set_title_from_value(inputAuto);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'auto')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-auto', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-auto', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-auto', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-auto', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-auto', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputAuto.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items     
        html.find('.sbe-open-expression-editor-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO, typeClass, itemid);
        });
        html.find('.sbe-cut-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-copy-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-paste-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO);
        });
        html.find('.sbe-clear-auto').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Check Group                                                      
    // ---------------------------------------------------------------- 
    if (hasCheckGroup) {
      // find the check group element
      let inputCheckGroup = sbe_item_sheet_get_input(html, 'checkgroup', typeClass);
      if (inputCheckGroup != null && inputCheckGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputCheckGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'checkgroup')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-checkgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-validate-checkgroup', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-cut-checkgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-checkgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-checkgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-checkgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputCheckGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items 
        html.find('.sbe-open-expression-editor-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
        });
        html.find('.sbe-validate-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-copy-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-paste-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP);
        });
        html.find('.sbe-clear-checkgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // List(Options)                                                    
    // ---------------------------------------------------------------- 
    if (hasList) {
      // find the element which has the value
      let inputList = sbe_item_sheet_get_input(html, 'list', typeClass);
      if (inputList != null && inputList.length > 0) {
        sbe_item_sheet_set_title_from_value(inputList);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'list')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-list', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-validate-list', 'fas fa-spell-check')
                + sbe_item_sheet_dropdown_item('sbe-cut-list', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-list', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-list', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-list', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputList.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-open-expression-editor-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
        });
        html.find('.sbe-validate-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_validate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST, typeClass, itemid);
        });
        html.find('.sbe-cut-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-copy-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-paste-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST);
        });
        html.find('.sbe-clear-list').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Font Group                                                       
    // ----------------------------------------------------------------                             
    if (hasFontGroup) {
      // find the element
      let inputFontGroup = sbe_item_sheet_get_input(html, 'fontgroup', typeClass);
      if (inputFontGroup != null && inputFontGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputFontGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'fontgroup')
                + sbe_item_sheet_dropdown_item('sbe-generate-fontgroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-fontgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-fontgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-fontgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-fontgroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-fontgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-fontgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputFontGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP, typeClass);
        });
        html.find('.sbe-open-expression-editor-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-copy-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-copy-fontgroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-paste-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP);
        });
        html.find('.sbe-clear-fontgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Input Group                                                      
    // ---------------------------------------------------------------- 
    if (hasInputGroup) {
      // find the element
      let inputInputGroup = sbe_item_sheet_get_input(html, 'inputgroup', typeClass);
      if (inputInputGroup != null && inputInputGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputInputGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'inputgroup')
                + sbe_item_sheet_dropdown_item('sbe-generate-inputgroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-inputgroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-inputgroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-inputgroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-inputgroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-inputgroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-inputgroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputInputGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP, typeClass);
        });
        html.find('.sbe-open-expression-editor-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-copy-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-copy-inputgroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-paste-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP);
        });
        html.find('.sbe-clear-inputgroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER);
        });
      }
    }
    // ---------------------------------------------------------------- 
    // Header Group                                                     
    // ---------------------------------------------------------------- 
    if (hasHeaderGroup) {
      // find the header group element
      let inputHeaderGroup = sbe_item_sheet_get_input(html, 'headergroup', typeClass);
      if (inputHeaderGroup != null && inputHeaderGroup.length > 0) {
        sbe_item_sheet_set_title_from_value(inputHeaderGroup);
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, 'headergroup')
                + sbe_item_sheet_dropdown_item('sbe-generate-headergroup', 'fas fa-magic')
                + sbe_item_sheet_dropdown_item('sbe-open-expression-editor-headergroup', 'fas fa-code')
                + sbe_item_sheet_dropdown_item('sbe-cut-headergroup', 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-headergroup', 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-copy-headergroup-as-css', 'fab fa-css3-alt')
                + sbe_item_sheet_dropdown_item('sbe-paste-headergroup', 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-headergroup', 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputHeaderGroup.after(sDropDown);
        // register event listeners for dropdown
        let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.ATTRIBUTE;
        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-generate-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_autogenerate_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP, typeClass);
        });
        html.find('.sbe-open-expression-editor-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_edit_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP, typeClass, itemid);
        });
        html.find('.sbe-cut-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-copy-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-copy-headergroup-as-css').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input_as_css(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-paste-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP);
        });
        html.find('.sbe-clear-headergroup').click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER);
        });
      }
    }
    // condistion visible
    if (hasConditionVisibleIf) {
      // find the visibleif element
      let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.ATTRIBUTE;
      let inputVisibleIf = sbe_item_sheet_get_input(html, sAttribute, typeClass);
      if (inputVisibleIf != null && inputVisibleIf.length > 0) 
        sbe_item_sheet_set_title_from_value(inputVisibleIf);{
        // adapt size
        inputVisibleIf[0].style.width = 'calc(100% - 25px)';
        // 
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, sAttribute)
                + sbe_item_sheet_dropdown_item('sbe-cut-' + sAttribute, 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-' + sAttribute, 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-' + sAttribute, 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-' + sAttribute, 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputVisibleIf.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-cut-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });
        html.find('.sbe-copy-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });

        html.find('.sbe-paste-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF);
        });
        html.find('.sbe-clear-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER);
        });
      }
    }
    if (hasConditionVisibleValue) {
      // find the visibleif element
      let sAttribute = ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.ATTRIBUTE;
      let inputVisibleValue = sbe_item_sheet_get_input(html, sAttribute, typeClass);
      if (inputVisibleValue != null && inputVisibleValue.length > 0) {
        sbe_item_sheet_set_title_from_value(inputVisibleValue);
        // adapt size, special one
        inputVisibleValue[0].style.width = 'calc(100% - 25px)';
        // 
        // insert a dropdown at the end of this element
        let sDropDown = sbe_item_sheet_dropdown_header(itemid, sAttribute)
                + sbe_item_sheet_dropdown_item('sbe-cut-' + sAttribute, 'fas fa-cut')
                + sbe_item_sheet_dropdown_item('sbe-copy-' + sAttribute, 'fas fa-copy')
                + sbe_item_sheet_dropdown_item('sbe-paste-' + sAttribute, 'fas fa-paste')
                + sbe_item_sheet_dropdown_item('sbe-clear-' + sAttribute, 'fas fa-times-circle')
                + sbe_item_sheet_dropdown_footer();
        inputVisibleValue.after(sDropDown);
        // register event listeners for dropdown

        let elementDropDownContent = sbe_item_sheet_dropdown_content_element(html, itemid, sAttribute);
        let elementDropDownButton = sbe_item_sheet_dropdown_btn_element(html, itemid, sAttribute, elementDropDownContent);
        // register event listeners for dropdown items
        html.find('.sbe-cut-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_cut_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });
        html.find('.sbe-copy-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_copy_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });

        html.find('.sbe-paste-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_paste_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE);
        });
        html.find('.sbe-clear-' + sAttribute).click(ev => {
          sbe_item_sheet_dropdown_toggle(elementDropDownButton, elementDropDownContent);
          sbe_item_sheet_clear_input(html, ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER);
        });
      }
    }
  }
});


Hooks.on("renderActorSheet", (gActorSheet, html) => {
  sbe_item_sheet_delete_protection(html);
});


//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                   Item delete protection functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//   
function sbe_item_sheet_delete_protection(html) {
  const OPTION_ACTIVATE_ITEM_DELETE_PROTECTION = sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ACTIVATE_ITEM_DELETE_PROTECTION);
  if (OPTION_ACTIVATE_ITEM_DELETE_PROTECTION) {    
    let sheetelementid = html[0].id;
    // get window title
    let insertafterthis = html.find('.window-title');
    if (insertafterthis) {
      // create toggle button
      let sToggle = '<input type="checkbox" id="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-checkbox" title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'"><label for="' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible" class="sbe-sheet-toggle-delete-item-visible-label" title="'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-tooltip')+'">'+game.i18n.localize('sandbox-extensions.sbe-sheet-toggle-delete-item-visible-label-caption')+'</label>';
      // insert button
      insertafterthis.after(sToggle);
      // Trigger a toggle when document is loaded, 
      $(document).ready(function () {
        sbe_sheet_toggle_delete_item_visible(html);
      });
      html.find('#' + sheetelementid + '-sbe-sheet-toggle-delete-item-visible').click(ev => {
        sbe_sheet_toggle_delete_item_visible(html);
      });
      
    }
  }
}

function sbe_sheet_toggle_delete_item_visible(html) {
  try {
    // get document from the element(used for popout combability)     
    let doc = html[0].ownerDocument;
    let sheetelementid;
    // for some updates the return html is a form
    if (html[0].nodeName == 'FORM') {
      sheetelementid = html[0].parentElement.parentElement.id;
    } else {
      sheetelementid = html[0].id;
    }
    let sheet = doc.getElementById(sheetelementid);
    if (sheet !== null) {
      //let deletes = sheet.getElementsByClassName(delete_btn_class);
      let deletes = sheet.querySelectorAll('.ci-delete, .item-delete,.citem-delete,.mod-delete');
      let chkelement = doc.getElementById(sheetelementid + '-sbe-sheet-toggle-delete-item-visible');
      let chkvalue = false;
      if (chkelement !== null) {
        chkvalue = chkelement.checked;
      }
      for (let i = 0; i < deletes.length; i++) {
        if (deletes[i].nodeName == 'A') {
          let style = getComputedStyle(deletes[i]);

          if (chkvalue) {
            deletes[i].style.display = 'inline';
          } else {
            deletes[i].style.display = 'none';
          }
        }
      }
    }
  } catch (err) {
    console.log('SBE   | sbe_sheet_toggle_delete_item_visible Err:' + err.message);
  }
}
                                                                 
                                                                  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       Sheet input functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  function sbe_item_sheet_set_title_from_value(inputelement){
    if (inputelement[0].value!==''){
      inputelement[0].title=inputelement[0].value;
    }
  }
  
  function sbe_item_sheet_get_input(html,sAttribute,sTypeClass){ 
    let objInput=null; 
    let sIdentifier= ITEMATTRIBUTE[sTypeClass.toUpperCase()][sAttribute.toUpperCase()].IDENTIFIER;
    objInput = html.find(`${sIdentifier}`);
    return objInput;
  }
  
  function sbe_item_sheet_edit_input(html,oAttribute,typeClass,itemid){
    let sExpression=sbe_item_sheet_get_input(html,oAttribute.ATTRIBUTE,typeClass)[0].value;
    let itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;
    let itemtargetelement=ITEMATTRIBUTE[typeClass.toUpperCase()][oAttribute.ATTRIBUTE.toUpperCase()].IDENTIFIER;    
    let options = {
        expression: sExpression,
        itemid: itemid,
        itemname:itemName,
        itemtype:typeClass.toLowerCase(),
        itemlabel:oAttribute.CAPTION,
        itemtargetelement:itemtargetelement,
        itemlinebreaker:oAttribute.LINEBREAKER
      };                                                                   
    new SandboxExpressionEditorForm(options).render(true,{focus:true}); 
  }
                     
  function sbe_item_sheet_paste_input(html,oAttribute){
    navigator.clipboard.readText()
      .then(text => {
        // `text` contains the text read from the clipboard          
        let elementInput= null;                    
        let sIdentifier=oAttribute.IDENTIFIER;
        elementInput= html.find(`${sIdentifier}`);
        if (elementInput!=null && elementInput.length>0){
          elementInput[0].value= text;
          // trigger onchange event
          const event = new Event('change', { bubbles: true });  
          elementInput[0].dispatchEvent(event); 
        } 
      })
      .catch(err => {
        // maybe user didn't grant access to read from clipboard
        ui.notifications.warn('Error when attempting to paste to ' + oAttribute.CAPTION,err);
      });            
  }
   
  function sbe_item_sheet_cut_input(html,oAttribute,sPrefix='',sSuffix=''){ 
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    let sValue='';
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      sValue=elementInput[0].value;
      if (sValue.length>0){     
        let sEnclosed=sPrefix + sValue + sSuffix;
        navigator.clipboard.writeText(sEnclosed);
        // and empty it
        elementInput[0].value= '';
        // trigger onchange event
        const event = new Event('change', { bubbles: true });  
        elementInput[0].dispatchEvent(event);
        ui.notifications.info(oAttribute.CAPTION +" cut to Clipboard as ["+ sEnclosed +"]");
      }
      else{
        ui.notifications.warn(oAttribute.CAPTION +" not cut to Clipboard(empty string)");
      }
    }                                                            
  }   
   
   
  function sbe_item_sheet_copy_input(html,oAttribute,sPrefix='',sSuffix=''){ 
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    let sValue='';
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      sValue=elementInput[0].value;
      if (sValue.length>0){     
        let sEnclosed=sPrefix + sValue + sSuffix;
        navigator.clipboard.writeText(sEnclosed);     
        ui.notifications.info(oAttribute.CAPTION +" copied to Clipboard as ["+ sEnclosed +"]");
      }
      else{
        ui.notifications.warn(oAttribute.CAPTION +" not copied to Clipboard(empty string)");
      }
    }                                                            
  }
  
  function sbe_item_sheet_copy_input_as_css(html,oAttribute){
    sbe_item_sheet_copy_input(html,oAttribute,'.sandbox.sheet .','{\n}');
  }
  
  function sbe_item_sheet_copy_input_as_actor_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'@{','}');                                                           
  }                           
  
  function sbe_item_sheet_copy_input_as_citem_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'#{','}');                                                           
  } 
  
  function sbe_item_sheet_copy_input_as_dialog_property(html,oAttribute){ 
    sbe_item_sheet_copy_input(html,oAttribute,'d{','}');                                                           
  }
  
  function sbe_item_sheet_validate_input(html,oAttribute,typeClass,itemid){  
    const enforcedvalidation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION);
    const itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;                                                    
    let validatingitemtype='';
    switch(typeClass) {
      case 'PROPERTY':
        validatingitemtype='property';              
        break;
      case "MULTIPANEL":
        validatingitemtype='multipanel';
        break; 
      case "PANEL":
        validatingitemtype='panel';
        break; 
      case "TAB":
        validatingitemtype='sheettab';
        break; 
      case "GROUP":
        validatingitemtype='group';
        break;   
      case "cITEM":            
        break;  
      default:
        break;            
    }         
    let elementInput= null;         
    switch(oAttribute.ATTRIBUTE){
      case 'key':       
        elementInput=sbe_item_sheet_get_input(html,'key',typeClass);
        if (elementInput!=null && elementInput.length>0){   
          let sKey=elementInput[0].value; 
          sbe_item_sheet_validate_key(validatingitemtype,itemName,itemid,typeClass,sKey,enforcedvalidation);
        }        
        break;
      case 'checkgroup':                  
        elementInput=sbe_item_sheet_get_input(html,'checkgroup',typeClass);
        if (elementInput!=null && elementInput.length>0){ 
          let sCheckGroup=elementInput[0].value;                                      
          sbe_item_sheet_validate_checkgroup(itemName,sCheckGroup,typeClass);
        } 
        break; 
      case 'list':                
        elementInput=sbe_item_sheet_get_input(html,'list',typeClass);
        if (elementInput!=null && elementInput.length>0){  
          let sList=elementInput[0].value;                                    
          sbe_item_sheet_validate_list(itemName,sList,typeClass);
        } 
        break;
      default:
        break;
    }                             
  }
  
  async function sbe_item_sheet_autogenerate_all(gItemSheet,html,typeClass){
    let bOkToProceed=true;  
    const bRequireConfirmation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE);
    if (bRequireConfirmation){
        bOkToProceed=await sbe_item_sheet_confirmdialog('Confirm Autogenerate All','This will overwrite fields with <b>Autogenerate</b> option, do you want to proceed?<br><br> To avoid this confirmation dialog, you can change <b>Confirm batch overwrite</b> in Settings' );
    }
      if (bOkToProceed){     
        switch(typeClass) {     
          case 'PROPERTY':
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP,typeClass,false);  
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID,typeClass,false);                        
            break;
          case "MULTIPANEL":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP,typeClass,false);
            break; 
          case "PANEL":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP,typeClass,false);
            break; 
          case "TAB":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG,typeClass,false);
            break; 
          case "GROUP":
            sbe_item_sheet_autogenerate_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY,typeClass,false);
            break;   
          case "cITEM":            
            break;  
          default:
            break;            
        }
        // trigger onsubmit event                
        gItemSheet.submit();
        
      }
  }
    
  function sbe_item_sheet_autogenerate_input(html,oAttribute,typeClass,triggeronchange=true){ 
    let sKey='';
    let key_prefix='';
    let key_prefix_setting='';  
    let autogenerated='N/A';    
    let full_prefix=''; 
    let sItemName='';
    let sBase='';        
    const key_separator=SandboxExtensions.CONSTANTS.SEPARATOR.KEY; 
    const css_separator=SandboxExtensions.CONSTANTS.SEPARATOR.CSS;
    const keyCase=SandboxExtensions.CONSTANTS.CASENR[sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE)];
    const cssCase=SandboxExtensions.CONSTANTS.CASENR[sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE)];
    const useprefixsuffix=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_PREFIX_SUFFIX);
    const itemName=sbe_item_sheet_get_input(html,'name','ITEM')[0].value;
    if(useprefixsuffix){
      switch(typeClass) {
        case 'PROPERTY':
          // check if to use datatype as prefix
          const usedatatype=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_USE_DATATYPE_PREFIX);
          if(usedatatype==false){
            key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY;
          }
          else{
            // get the datatype
            const datatype=sbe_item_sheet_get_input(html,ITEMATTRIBUTE.PROPERTY.DATATYPE.ATTRIBUTE,'PROPERTY')[0].value;
            switch (datatype) {
              case 'simpletext':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLETEXT;
                break;
              case 'simplenumeric':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_SIMPLENUMERIC;
                break;
              case 'checkbox':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_CHECKBOX;
                break;
              case 'radio':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_RADIO;
                break;
              case 'textarea':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TEXTAREA;
                break;
              case 'list':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LIST;
                break;
              case 'label':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_LABEL;
                break;
              case 'badge':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BADGE;
                break;
              case 'table':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_TABLE;
                break;
              case 'button':
                key_prefix_setting = SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY_BUTTON;
                break;
            }
          }
          break;
        case "MULTIPANEL":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL;
          break; 
        case "PANEL":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PANEL;
          break; 
        case "TAB":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_TAB;
          break; 
        case "GROUP":
          key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_GROUP;
          break;   
        case "cITEM":            
          break;  
        default:
          break;            
      }         
      if(key_prefix_setting.length>0){
        key_prefix = sbe_item_sheet_get_game_setting(SandboxExtensions.ID,key_prefix_setting);
      } 
    }
    switch(oAttribute.ATTRIBUTE){
      case 'key':        
        // check if itemname already begins with prefix then dont add it                                                           
        if (key_prefix!=''){        
          full_prefix=key_prefix + key_separator;
          if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
            sKey=itemName;
          }
          else{
            sKey=full_prefix +  itemName;
          }
        }
        else{
          sKey=itemName;
        }                                                          
        sKey=sbe_item_sheet_to_slug(sKey,key_separator,keyCase); 
        autogenerated=sKey;                   
        break;
      case 'tag':                                            
        full_prefix=key_prefix + key_separator;              
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }                       
        autogenerated= sItemName; 
        break;
      case 'tooltip':         
        full_prefix=key_prefix + key_separator;
        sItemName='';       
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }             
        autogenerated= sItemName;
        break;
      case 'rollname':         
        if (typeClass=='PROPERTY'){            
          sBase=itemName;
        } 
        else if(typeClass=='cITEM'){   
          sBase='#{name}';
        }
        else{
          sBase=itemName;
        } 
        let suffix_rollname='';
        
        if(useprefixsuffix){
          suffix_rollname=' ' + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_ROLLNAME); 
          
        }
        autogenerated= sBase +  suffix_rollname; 
        break;      
      case 'rollid':
        if (typeClass=='PROPERTY'){       
            sBase=html.find(`${ITEMATTRIBUTE.PROPERTY.KEY.IDENTIFIER}`)[0].value;
          }
        else{
          sBase=itemName;
        }  
        let suffix_rollid='';
        if(useprefixsuffix){
          suffix_rollid=key_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_ROLLID);    
        }
        let sRollID=sBase +  suffix_rollid;                                                                         
        autogenerated= sbe_item_sheet_to_slug(sRollID,key_separator,keyCase);
        break;
      case 'fontgroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value;
        let suffix_fontgroup='';
        if(useprefixsuffix){
          suffix_fontgroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP);    
        }
        let sFontGroup=sKey +  suffix_fontgroup;                 
        autogenerated=sbe_item_sheet_sanitize_css( sbe_item_sheet_to_slug(sFontGroup,css_separator,cssCase));
        break; 
      case 'inputgroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value; 
        let suffix_inputgroup='';
        if(useprefixsuffix){
          suffix_inputgroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP);      
        }
        let sInputGroup=sKey +  suffix_inputgroup;                                                                        
        autogenerated=sbe_item_sheet_sanitize_css( sbe_item_sheet_to_slug(sInputGroup,css_separator,cssCase)); 
        break;
      case 'headergroup':         
        sKey=sbe_item_sheet_get_input(html,'key',typeClass)[0].value; 
        let suffix_headergroup='';
        if(useprefixsuffix){
          suffix_headergroup=css_separator + sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP);     
        }
        let sHeaderGroup=sKey +  suffix_headergroup;                                                                        
        autogenerated= sbe_item_sheet_sanitize_css(sbe_item_sheet_to_slug(sHeaderGroup,css_separator,cssCase)); 
        break;
      default:
        break;
    }
    let elementInput= null;
    let sIdentifier=oAttribute.IDENTIFIER;
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      elementInput[0].value= autogenerated;
      if(triggeronchange){
        // trigger onchange event
        const event = new Event('change', { bubbles: true });       
        elementInput[0].dispatchEvent(event); 
      }
    }     
  }
   
  function sbe_item_sheet_sanitize_css(scss) {
    // /^[0-9]|^-([0-9])/gu  fill find string starting with a number OR 1 hyphen followed by number 
    let sreturn = scss;
    // CSS class name cannot start with a number 
    if (/^[0-9]/gu.test(sreturn)) {
      // add two hyphens
      sreturn = '--' + sreturn;
    }
    // or a single hyphen followed by a digit
    if(/^-([0-9])/gu.test(sreturn)){
      sreturn = '-' + sreturn;
    }
    return sreturn;
  }
 
  function sbe_item_sheet_clear_input(html,sIdentifier,triggeronchange=true){  
    let elementInput= null;
    elementInput= html.find(`${sIdentifier}`);
    if (elementInput!=null && elementInput.length>0){
      elementInput[0].value= '';
      if(triggeronchange){
        // trigger onchange event
        const event = new Event('change', { bubbles: true });       
        elementInput[0].dispatchEvent(event); 
      }
    }
  }
  
  async function sbe_item_sheet_clear_all(gItemSheet,html,typeClass){
    let bOkToProceed=true;  
    const bRequireConfirmation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CONFIRM_BATCH_OVERWRITE);
    if (bRequireConfirmation){
      bOkToProceed=await sbe_item_sheet_confirmdialog('Confirm Clear All','This will overwrite fields with <b>Clear</b> option, do you want to proceed?<br><br> To avoid this confirmation dialog, you can change <b>Confirm batch overwrite</b> in Settings' );
    }
    if (bOkToProceed){
      switch(typeClass) {    
        case 'PROPERTY':
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TOOLTIP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLEXP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLNAME.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].ROLLID.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].AUTO.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].AUTOMAX.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].DEFAULT.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].LIST.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].CHECKEDPATH.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].UNCHECKEDPATH.IDENTIFIER,false);
          break;
        case "MULTIPANEL":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER,false);
          break; 
        case "PANEL":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].FONTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].INPUTGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].HEADERGROUP.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEVALUE.IDENTIFIER,false); 
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].IMAGEPATH.IDENTIFIER,false);
          break; 
        case "TAB":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].TAG.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].VISIBLEIF.IDENTIFIER,false);
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].IMAGEPATH.IDENTIFIER,false);
          break; 
        case "GROUP":
          sbe_item_sheet_clear_input(html,ITEMATTRIBUTE[typeClass.toUpperCase()].KEY.IDENTIFIER,false);
          break;   
        case "cITEM":            
          break;  
        default:
          break;            
      }
      // trigger onsubmit event
      gItemSheet.submit();
    }
  }
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                           Data Export                            
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  

async function sbe_item_sheet_get_export_options(exportformat){
    let dialog=new Promise((resolve,reject)=>{
      new Dialog({
        title: exportformat + ' Export Options',
        content: `
        <fieldset style="text-align:left;">
          <legend style="text-align:left">Export Data Options</legend>
          <table>
            <tr>
              <th> </th><th>Option</th><th>Description</th>
            </tr> 
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-empty" name="include-empty" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-empty" style="white-space:nowrap;">  Include Empty</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include attributes with no value</td>
            </tr>
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-defaults" name="include-default" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-defaults" style="white-space:nowrap;">  Include Defaults</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include attributes with default values</td>
            </tr>
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-sub-items" name="includesubitems" value="true"></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-sub-items" style="white-space:nowrap;"> Include Subitems</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include Properties for Panels/Groups, Panels for MultiPanels/Tabs</td>
            </tr>            
          </table>
        </fieldset> 
        
        <fieldset style="text-align:left;">
          <legend style="text-align:left">Export Format Options</legend>
          <table>
            <tr>
              <th> </th><th>Option</th><th>Description</th>
            </tr>                        
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-doublecolumn" name="compact" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-doublecolumn" style="white-space:nowrap;"> Double Column Mode</label></td>              
              <td style="vertical-align: top;">Present data in double column mode(space saving mode)</td>
            </tr>
          </table>
        </fieldset>  
        <hr>
        `,
        buttons: {
          ok: {
            icon:'<i class ="fas fa-check"></i>',
            label: "Ok",            
            callback: (html) => {              
              let doublecolumn=   html.find('#sbe-export-options-doublecolumn')[0].checked;
              let includeempty=   html.find('#sbe-export-options-include-empty')[0].checked;
              let includedefaults=html.find('#sbe-export-options-include-defaults')[0].checked;
              let includesubitems=html.find('#sbe-export-options-include-sub-items')[0].checked;
              let options={exportformat:exportformat,doublecolumn:doublecolumn,includeempty:includeempty,includedefaults:includedefaults,includesubitems:includesubitems};
              resolve(options);
            }
          },
          cancel: { 
            icon:'<i class ="fas fa-times"></i>',
            label: "Cancel",            
            callback: (html) => {              
              resolve(null);
            }
          }
        },
        default: "ok",
        close:  html => {                            
        }   
      }).render(true);             
    });    
    console.log('sbe_item_sheet_get_text_export_options');
    let options=await dialog;  
    if (options===null){
      //throw new Error("User aborted options by clicking Cancel button.");
    }
    return options;
  }



async function sbe_item_sheet_export_data_text_table(html, typeClass,exportformat) {
  let exportoptions = await sbe_item_sheet_get_export_options(exportformat);
  if (exportoptions !== null) {
    let exportdata = sbe_item_sheet_export_data(html, typeClass, exportoptions);        
    let sFormattedData;
    switch(exportformat){
      case 'Markdown':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions);
        break;
      case 'PlainText':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions,'','---'); 
        break;
      case 'HTML':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions,'','');
      default:
        break;
    }
    
    navigator.clipboard.writeText(sFormattedData);
    ui.notifications.info('Data formatted as ' + exportformat +' table copied to Clipboard');
  }
}
function sbe_item_sheet_export_data_plaintext(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'PlainText');  
}
function sbe_item_sheet_export_data_markdown(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'Markdown');  
}
function sbe_item_sheet_export_data_html(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'HTML');  
}
  

function sbe_item_sheet_format_data_text(data, exportoptions, attributeformat = '**', alignment = ':---') {
  let sReturn = '';
  let iColAttributeWidth = 'Attribute'.length;
  let iColValueWidth = 'Value'.length;
  let sAttribute = '';
  let sValue = '';
  const MAXWIDTH=80;
  // determine columns widths
  for (let i = 0; i < data.length; i++) {
    if (data[i][0].length > iColAttributeWidth) {
      iColAttributeWidth = data[i][0].length;
    }
    if (data[i][1].length > iColValueWidth) {
      iColValueWidth = data[i][1].length;
    }
  }
  if(iColValueWidth>MAXWIDTH){
    iColValueWidth=MAXWIDTH;
  }
  if(iColAttributeWidth>MAXWIDTH){
    iColAttributeWidth=MAXWIDTH;
  }
  
  if (!exportoptions.doublecolumn) {
    // add header
    if(exportoptions.exportformat=='HTML'){
      sReturn = '<table>\n<tr><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th></tr>\n';
    }
    else{
      sReturn = '| ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ') + ' |' + '\n';
      sReturn += '| ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-') + ' |' + '\n';
    }
    // add each row
    for (let i = 0; i < data.length; i++) {
      sAttribute = attributeformat + data[i][0].toString() + attributeformat;
      sValue = data[i][1].toString();
      if(exportoptions.exportformat=='HTML'){
        sReturn += '<tr><td><b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td></tr>\n';
      }
      else{
        sReturn += '| ' + sAttribute.padEnd(iColAttributeWidth, ' ');
        sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ') + ' |' + '\n';
      }
    }
    if(exportoptions.exportformat=='HTML'){
        sReturn += '</table>\n';
    }
  } 
  else {    
    let bSecondColAdded = false;
    // add header
    if(exportoptions.exportformat=='HTML'){
      sReturn = '<table>\n<tr><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th></tr>\n';
    }
    else{
      sReturn = '| ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ') + ' |' + '\n';
      sReturn += '| ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-') + ' |' + '\n';
    }
    
    for (let i = 0; i < data.length; i++) {
      sAttribute = attributeformat + data[i][0].toString() + attributeformat;
      sValue = data[i][1].toString();
      if(exportoptions.exportformat=='HTML'){
        sReturn += '<tr><td> <b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td>';
      }
      else{
        sReturn += '| ' + sAttribute.padEnd(iColAttributeWidth, ' ');
        sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ');
      }
      bSecondColAdded = false;
      while (i + 1 < data.length && !bSecondColAdded) {
        i = i + 1;
        sAttribute = attributeformat + data[i][0].toString() + attributeformat;
        sValue = data[i][1].toString();
        // add second col
        if(exportoptions.exportformat=='HTML'){
          sReturn += '<td ><b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td></tr>\n';
        }
        else{
          sReturn += ' | ' + sAttribute.padEnd(iColAttributeWidth, ' ');
          sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ') + ' |' + '\n';
        }
        bSecondColAdded = true;
      }
      if (!bSecondColAdded) {
        // add empty
        if(exportoptions.exportformat=='HTML'){
          sReturn += '<td style="font-weight:bold"></td><td style="font-family:monospace"></td></tr>\n';
        }
        else{
          sReturn += ' | ' + ''.padEnd(iColAttributeWidth, ' ');
          sReturn += ' | ' + ''.padEnd(iColValueWidth, ' ') + ' |' + '\n';
        }
      }
    }
    if(exportoptions.exportformat=='HTML'){
        sReturn += '</table>\n';
    }
  }
  return sReturn;
}
  
  // returns a two dimensional array fieldname:fieldvalue
  function sbe_item_sheet_export_data(html,sTypeClass,exportoptions){
    let data=[];
    let sPanelKey='';      
    // general attributes
    data.push(['Item Type',sTypeClass]);
    sbe_export_data_attribute(data,html,ITEMATTRIBUTE.ITEM.NAME,exportoptions);
    // item type specific attributes  
    switch(sTypeClass.toUpperCase()){
      case TYPECLASS.PROPERTY:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        break;
      case TYPECLASS.MULTIPANEL:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if (exportoptions.includesubitems) {
          // now get the panels for this multipanel 
          sPanelKey = html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let multipanel = game.items.find(y => y.type == 'multipanel' && y.data.data.panelKey == sPanelKey);
          if (multipanel != null) {
            let sPanelName = '';
            for (let i = 0; i < multipanel.data.data.panels.length; i++) {
              sPanelName = multipanel.data.data.panels[i].name;
              data.push(['Panel ' + i.toString().padStart(2, '0'), sPanelName]);
            }
          }
        }
        break;
      case TYPECLASS.PANEL:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the properties for this panel 
          sPanelKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let panel= game.items.find(y=>y.type=='panel'&& y.data.data.panelKey == sPanelKey);          
          if (panel!=null) {
            let sPropertyName='';
            for (let i = 0; i < panel.data.data.properties.length; i++) {
              sPropertyName=panel.data.data.properties[i].name;
              data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName]);
            }            
          }
        }
        break;
      case TYPECLASS.TAB:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the panels for this tab 
          let sTabKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let tab= game.items.find(y=>y.type=='sheettab'&& y.data.data.tabKey == sTabKey);          
          if (tab!=null) {          
            let sPanelName='';
            for (let i = 0; i < tab.data.data.panels.length; i++) {
              sPanelName=tab.data.data.panels[i].name;
              data.push(['Panel ' + i.toString().padStart(2, '0'),sPanelName]);
            }            
          } 
        }
        break;
      case TYPECLASS.GROUP:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the properties for this group 
          let sGroupKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let group= game.items.find(y=>y.type=='group'&& y.data.data.groupKey == sGroupKey);          
          if (group!=null) {
            let sPropertyName=''; 
            let isConstant=false;
            //debugger;
            for (let i = 0; i < group.data.data.properties.length; i++) {
              sPropertyName=group.data.data.properties[i].name; 
              isConstant=group.data.data.properties[i].isconstant;
              if(isConstant){
                data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName +' [Constant]' ]);
              }
              else{
                data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName]);
              }
            }            
          }
        }
        break;
      case TYPECLASS.CITEM:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        break;
      default:
        break;
    }
    return data;
  }
  
  function sbe_export_data_attribute(data,html,oAttribute,exportoptions){
    let sValue='';
    let bExportThis=true;
    let element=html.find(oAttribute.IDENTIFIER);
    if (element!=null && element.length>0) {
      switch(element[0].tagName.toLowerCase()) {    
        case 'input':
          if (element[0].type=="checkbox"){ 
            sValue=element[0].checked.toString();
          } 
          else{
            sValue=element[0].value;  
           } 
          break; 
        case 'textarea':
          sValue=element[0].value;
          break
        case 'select':
          sValue=element[0].selectedOptions[0].text;
          break;
      } 
      // now for options
      if(sValue==oAttribute.DEFAULT){
        if(!exportoptions.includedefaults){
          bExportThis=false;
        }
      }
      if(sValue.length==0){
        if(!exportoptions.includeempty){
          bExportThis=false;
        }
      }
      if (bExportThis) {
        if (oAttribute.LINEBREAKER != '') {
          // replace linebreakers
          switch (exportoptions.exportformat) {
            case 'HTML':
              sValue=sValue.replace(/\t/g, '&emsp;'); 
              sValue = sValue.split(oAttribute.LINEBREAKER).join("<br/>\n");
              //sValue='<div style="font-family:monospace">' + sValue +'</div>';
              break;
            case 'PlainText':
              sValue = sValue.split(oAttribute.LINEBREAKER).join("\n");
              break;
            case 'Markdown':
              // replace tabs
              //sValue=sValue.replace(/\t/g, '&emsp;');              
              // escape all specials markdown characters
             //sValue = sValue.replace(/\\(\*|_|`|~|\\)/g, '$1'); // unescape any "backslashed" character
             //sValue = sValue.replace(/(\*|_|`|~|\\)/g, '\\$1'); // escape *, _, `, ~, \

             sValue =sValue.split(oAttribute.LINEBREAKER).join("<br/>")  ;
             // sValue='\`\`\`' + sValue +'\`\`\`';
              break;
          }
        }
        data.push([oAttribute.CAPTION, sValue]);
      }
    }
    
  } 
  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                       Item Sheet dropdowns                       
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  function sbe_item_sheet_dropdown_content_element (html,sItemID, sAttribute){
    let elementDropDownContent=html.find(`#`+ sItemID  + `-sbe-dropdown-`+ sAttribute +`-content`)[0];
    return elementDropDownContent;
  } 
  
  function sbe_item_sheet_dropdown_btn_element (html,sItemID, sAttribute,elementDropDownContent){
    let elementDropDownButton=html.find(`#`+ sItemID  + `-sbe-dropdown-`+ sAttribute +`-btn`)[0];
    if (elementDropDownButton!=null && elementDropDownContent!=null){                                                    
      // register event listeners for dropdown
      elementDropDownButton.addEventListener("click",function(){sbe_item_sheet_dropdown_toggle(elementDropDownButton,elementDropDownContent,true);} );        
    }
    else{
      console.error('SandBox Extensions | Error adding dropdown listeners for attribute ' + sAttribute);
    } 
    return elementDropDownButton;
  }
  
  // with exclude
  function sbe_item_sheet_dropdown_close_all(elementDropDownButton=null,elementDropDownContent=null){    
    // sbe-dropdown-content
    let dropdowns = document.getElementsByClassName("sbe-dropdown-content");    
    for (let i = 0; i < dropdowns.length; i++) {
      let openDropdown = dropdowns[i];
      if(elementDropDownContent!=null){        
        if (openDropdown.id!=elementDropDownContent.id) {
           sbe_item_sheet_hide_element(openDropdown);         
        } 
      }
      else{
        sbe_item_sheet_hide_element(openDropdown);
      }
    }  
    // adjust menu dropdowns
    let dropdownsbtns = document.getElementsByClassName("sbe-action-menu-label");    
    for (let i = 0; i < dropdownsbtns.length; i++) {
      let openDropdownbtn = dropdownsbtns[i]; 
      if(elementDropDownButton!=null){       
        if (openDropdownbtn.id!=elementDropDownButton.id) {
           
          if (openDropdownbtn.children.length == 2) {      
            openDropdownbtn.children[1].classList.remove("fa-caret-up");
            openDropdownbtn.children[1].classList.add("fa-caret-down");
            openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')            
          }         
        }
      }
      else{
        if (openDropdownbtn.children.length == 2) {      
            openDropdownbtn.children[1].classList.remove("fa-caret-up");
            openDropdownbtn.children[1].classList.add("fa-caret-down");
            openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')            
        } 
      }
    }
    
    // adjust dropdown buttons
    //sbe-dropdown-btn        
    dropdownsbtns = document.getElementsByClassName("sbe-dropdown-btn");    
    for (let i = 0; i < dropdownsbtns.length; i++) {
      let openDropdownbtn = dropdownsbtns[i]; 
      if(elementDropDownButton!=null){       
        if (openDropdownbtn.id!=elementDropDownButton.id) {
          openDropdownbtn.classList.remove("fa-caret-up");      
          openDropdownbtn.classList.add("fa-caret-down");
          openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')         
        }
      }
      else{
        openDropdownbtn.classList.remove("fa-caret-up");      
        openDropdownbtn.classList.add("fa-caret-down");
        openDropdownbtn.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')
      }
    }
  }   
  
  function sbe_item_sheet_dropdown_toggle (elementDropDownButton,elementDropDownContent,closeall=false){
    if(closeall){    
      // close all other dropdowns      
      sbe_item_sheet_dropdown_close_all(elementDropDownButton,elementDropDownContent);
    }
    // now toggle target  
    if (elementDropDownContent!=null){
      sbe_item_sheet_toggle_element_display(elementDropDownContent);
    }
    if (elementDropDownButton!=null){
      elementDropDownButton.classList.toggle("fa-caret-down");
      elementDropDownButton.classList.toggle("fa-caret-up");
      // if this is a menu
      if (elementDropDownButton.children.length == 2) { 
        elementDropDownButton.children[1].classList.toggle("fa-caret-down");
        elementDropDownButton.children[1].classList.toggle("fa-caret-up");
      } 

      if (elementDropDownButton.title==game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip') ){
        elementDropDownButton.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-hide-tooltip') 
      } 
      else{
        elementDropDownButton.title=game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')
      } 
    }
  }
             
  function sbe_item_sheet_dropdown_header(sItemID, sItemClass,sCaption='',sIcon=''){ 
    let sHeaderIcon='';   
    let sHeader='';
    if (sCaption!=''){
      if(sIcon!=''){
        sHeaderIcon=`<i class="`+ sIcon+`" ></i>`;
      }
      sHeader=`<div  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`"  class="sbe-dropdown">
          <label id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-btn" class="sbe-action-menu-label" title="`+game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')+`">`+sHeaderIcon+ ` ` + sCaption +` <i class="sbe-dropdown-menu-btn-icon fas fa-caret-down"></i></label> 
          <ul id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-content" class="sbe-dropdown-content sbe-dropdown-menu">`;
    } 
    else{ 
      
      sHeader=`<div  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`"  class="sbe-dropdown">
          <i  id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-btn" class="sbe-dropdown-btn  fas fa-caret-down" title="`+game.i18n.localize('sandbox-extensions.sbe-dropdown-btn-show-tooltip')+`"></i> 
          <ul id="`+sItemID+`-sbe-dropdown-`+sItemClass+`-content" class="sbe-dropdown-content">`;
    }
    return sHeader;
  }   
  
 function sbe_item_sheet_dropdown_footer(){
   let sFooter=`</ul>
        </div>`;
   return sFooter;
 } 
 
  function sbe_item_sheet_dropdown_item(sItemClass,sItemFontAwesomeIcon,sItemCustomIcon=''){
    let sItem='';
    if (sItemCustomIcon==''){
      sItem='<li class="sbe-dropdown-item '+ sItemClass + '"  title="'+game.i18n.localize('sandbox-extensions.'+sItemClass+'-tooltip')+'"><i class="sbe-dropdown-item-icon ' + sItemFontAwesomeIcon +'" ></i> '+ game.i18n.localize('sandbox-extensions.'+sItemClass+'-caption')+' ' +'</li>';
    }
    else{
      sItem='<li class="sbe-dropdown-item '+ sItemClass + '"  title="'+game.i18n.localize('sandbox-extensions.'+sItemClass+'-tooltip')+'"><i class="sbe-dropdown-item-icon"><img class="sbe-dropdown-item-custom-icon" src="modules/sandbox-extensions/styles/icons/'+sItemCustomIcon+'" alt="'+sItemCustomIcon+'"></i> '+ game.i18n.localize('sandbox-extensions.'+sItemClass+'-caption')+' ' +'</li>';
    }      
    return sItem;
  }
  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                 Item Sheet Validation functions                  
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
  
  // function for validate check group
  function sbe_item_sheet_validate_checkgroup(itemName, validatingCheckgroup,typeClass) {  
    let sHeader= 'Check Group validation for ' + typeClass + ' [' + itemName +']';       
    // look for spaces, special characters, only allow semicolons,underscores, hyphens
    let format = /[ `½§£¤!@#$%^&*()+=\[\]{}':"\\|,.<>\/?~]/;
    if (format.test(validatingCheckgroup)){                                                  
      let msg='Check Group contains invalid characters';        
      ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);                               
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  } 
  
  // function for validate lists
  function sbe_item_sheet_validate_list(itemName, validatingList,typeClass) {  
    let sHeader= 'Options(a,b,c) validation for ' + typeClass + ' [' + itemName +']';       
    // look for spaces
    let format = /\s/;
    if (format.test(validatingList)){                                                  
      let msg='Options(a,b,c) contains invalid characters';        
      ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);                               
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  }
  
  // function for checking if this key is valid
  function sbe_item_sheet_validate_key(validatingitemtype,itemName, validatingitemid,typeClass,sKey,enforcedvalidation) {  
    let sHeader= 'Key validation for key [' + sKey + '] for ' + typeClass + ' [' + itemName +']'; 
    // use module validate function      
    const  objResult = SandboxKeyValidate(validatingitemtype,validatingitemid,sKey,enforcedvalidation);
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){    
      objResult.warnings.forEach(function(msg){
        ui.notifications.warn(sHeader + ' returned validation warning:<br>' + msg);      
      });  
       objResult.errors.forEach(function(msg){
        ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);      
      });                   
    }     
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  }
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                        Support functions                         
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//
  async function sbe_item_sheet_confirmdialog(sTitle,sQuestion){
    let dialog=new Promise((resolve,reject)=>{
      new Dialog({
        title: sTitle,
        content: '<p>' + sQuestion + '</p>' ,
        buttons: {
          ok: {
            icon:'<i class ="fas fa-check"></i>',
            label: "Ok",            
            callback: () => {resolve(true)}
          },
          cancel: { 
            icon:'<i class ="fas fa-times"></i>',
            label: "Cancel",            
            callback: () => {resolve(false)}
          }
        },
        default: "ok",
        close:  () => {resolve(false) }   
      }).render(true);             
    }); 
    let answer=await dialog;
    return answer;    
   }


function sbe_item_sheet_toggle_element_display(element) {
  if (element.style.display == "none" || element.style.display == "") {
    element.style.display = "block";
    // attempt to set the width of this
    try {
      // get parent
      let parentelement = element.parentElement;
      let inputelement = parentelement.previousSibling;
      const dropdownbuttonwidth = 25;
      let adjustedwidth = inputelement.clientWidth + dropdownbuttonwidth;
      element.style.width = adjustedwidth + 'px';
    } catch (err) {
      console.error('SBE - Error setting dropdown width ||'+ err);
    }
  } else {
    element.style.display = "none";
  }
} 
  
  function sbe_item_sheet_show_element(element){    
    element.style.display = "block";                  
  }
  function sbe_item_sheet_hide_element(element){    
    element.style.display = "none";                  
  }
 
  function sbe_item_sheet_get_game_setting(moduleID,settingName){
    let setting=game.settings.get(moduleID, settingName);
    if (!setting) {
      return  '';
    }
    else{
      return setting;
    }
  }

                                                                 
  function sbe_item_sheet_to_slug(text,separator,useCase=SandboxExtensions.CONSTANTS.CASE.NONE){
    let sReturn=text;
    const transliteratenonlatin=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_TRANSLITERATE_NON_LATIN);
    const enforcedvalidation=sbe_item_sheet_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION);
    if(transliteratenonlatin||enforcedvalidation){
      // alphabet transliterations
      sReturn=transliterate(sReturn);
    }
    
    if(enforcedvalidation){
      sReturn=sReturn.replace(INVALID_KEY_CHARACTERS.ENFORCED, '_'); 
    }
    else{
      sReturn=sReturn.replace(INVALID_KEY_CHARACTERS.DEFAULT, '_');          
    }          
    switch(useCase){
      case SandboxExtensions.CONSTANTS.CASE.NONE:
        // no change        
        break;
      case SandboxExtensions.CONSTANTS.CASE.LOWERCASE:
        sReturn=sReturn.toLowerCase();
        break;
      case SandboxExtensions.CONSTANTS.CASE.UPPERCASE:
         sReturn=sReturn.toUpperCase();
        break;
      case SandboxExtensions.CONSTANTS.CASE.TITLECASE:           
          sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.KEY,' ');
          sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.CSS,' ');
          sReturn= sbe_item_sheet_to_title_case(sReturn);                             
        break;    
    }        
    if(separator==SandboxExtensions.CONSTANTS.SEPARATOR.KEY){
      sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.CSS, separator) ;
    }  
    if(separator==SandboxExtensions.CONSTANTS.SEPARATOR.CSS){
      sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.KEY, separator) ;
    }        
    sReturn=sReturn.replace(/\s+/g, separator) ; 
    sReturn=sReturn.trim();
    return sReturn;
  }             
  
 
  
  function sbe_item_sheet_to_title_case(str) {
  return str.replace(
    /\w\S*/g,
    function(txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    }
  );
}




 