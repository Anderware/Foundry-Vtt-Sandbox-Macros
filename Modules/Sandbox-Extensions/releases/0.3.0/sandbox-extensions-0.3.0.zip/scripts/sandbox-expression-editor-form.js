const _title="Sandbox Expression Editor";
import { SandboxKeyValidate } from "./sandbox-key-validate.js";
import { _module_id } from   './sandbox-extensions.js';
import { ModuleSettingsForm } from "./module-settings-form.js";
export class SandboxExpressionEditorForm extends FormApplication {
  static expression='';
  static item=''; 
  static isSplittedByTwoSpaces=false;
  static isSplittedByComma=false;
  static isSplittedBySemiColon=false;
  
  constructor(options) {
    super();
    this.expression = options.expression || null;
    this.itemid = options.itemid || null     ;
    this.itemname = options.itemname || null; 
    this.itemtype= options.itemtype || null;
    this.itemlabel= options.itemlabel || null;
    this.itemtargetelement=options.itemtargetelement||null;
    this.itemlinebreaker=options.itemlinebreaker||null;
    if (this.itemlinebreaker==null){   
      this.itemlinebreaker="  "; // default is two spaces
    }
    
    if (this.itemlinebreaker==","){
      this.isSplittedByComma=true;
    }
    else if(this.itemlinebreaker==";"){
      this.isSplittedBySemiColon=true;
    }   
    else if(this.itemlinebreaker==" "){
      this.isSplittedBySingleSpace=true;
    }
    else{
      this.isSplittedByTwoSpaces=true;
    }
    
    if (this.expression!=null){
      if(this.expression.length>0){                
        //const regex = \b\s\s\b/g;  // replace two spaces with new line
        this.expression=this.expression.split(this.itemlinebreaker).join("\n")
      }
    }
  }

  static initialize() {
    
    console.log('Initialized SandboxExpressionEditorForm' );
  }   
    
  static get defaultOptions() {
    const defaults = super.defaultOptions;  
    const overrides = {
      height: '600',
      width:'750',
      id: 'sandbox-expression-editor-form',
      template: `modules/sandbox-extensions/templates/sandbox-expression-editor-form.hbs`,
      title: _title,
      userId: game.userId,
      closeOnSubmit: true, // do not close when submitted
      submitOnChange: false, // submit when any input changes 
      resizable:true
    };  
    const mergedOptions = foundry.utils.mergeObject(defaults, overrides);    
    return mergedOptions;
  }  
  
  activateListeners(html) {
    super.activateListeners(html);
    html.find('button[name="update-expression"]').click(this._onUpdateExpression.bind(this));  
    html.find('button[name="update-expression-and-close"]').click(this._onUpdateExpressionAndClose.bind(this));
    html.find('button[name="close-editor"]').click(this._onCloseEditor.bind(this));
    html.find('#DisplaySandboxExtensionConfig').click(this._onDisplaySandboxExtensionConfig.bind(this));
    html.find('.paste-text-from-clipboard').click(this._onPaste.bind(this));  
    html.find('.copy-selection').click(this._onCopySelection.bind(this));
    html.find('.copy-expression').click(this._onCopyExpression.bind(this));
    html.find('.copy-expression-pre-formatted').click(this._onCopyExpressionPreFormatted.bind(this));  
    
    
    this.codeEditor = CodeMirror.fromTextArea(html.find(".sandbox-expression-editor-textarea")[0], { 
      mode: "sandbox-expression",             // A mode like "javascript" or "css"
      ...CodeMirror.userSettings,     // A special helper described later
      lineNumbers: false,              // CM has a number of settings you can configure
      inputStyle: "contenteditable",
      autofocus: true,
      matchBrackets: true
    });


    html.find('.sandbox-expression-editor-form-content').resize(this._onEditorResize.bind(this));
    
  }
  
  getData(options) {      
    let data; 
    data={
      expression:this.expression,
      itemname:this.itemname,
      itemtype:this.itemtype,
      itemlabel:this.itemlabel,               
      isSplittedBySingleSpace:this.isSplittedBySingleSpace,
      isSplittedByTwoSpaces:this.isSplittedByTwoSpaces,
      isSplittedBySemiColon:this.isSplittedBySemiColon,
      isSplittedByComma:this.isSplittedByComma
    }
    return data;
  }    
     
  async _onEditorResize(event){
    event.preventDefault();  
    console.log('resix');
    this.codeEditor.refresh();
  }
  
  async _onUpdateExpressionAndClose(event) {
    document.querySelector('button[name="update-expression"]').click();
    document.querySelector('button[name="close-editor"]').click(); 
  }  
  
  async _onUpdateExpression(event) { 
    event.preventDefault(); 
    this.codeEditor.save();
    let sTargetSelector='';
    //sTargetSelector ="#item-"+ this.itemid +" > section > form > section > div.tab.biography.scrollable.active > div:nth-child(3) > div > div:nth-child(3) > div > input[type=text]"; 
    
    sTargetSelector="#item-"+ this.itemid +" " + this.itemtargetelement;
    let target = document.querySelector(sTargetSelector)  
    // check if target item sheet is still open, if not re -open it
    if (target==null){
      let item=game.items.get(this.itemid);
      if (item!=null){
        // open item sheet
        item.sheet.render(true);         
      }                 
      ui.notifications.warn('Expression Editor: <br>Unable to update item expression when target item sheet is closed. <br>Attempts to open the item sheet again.  <br>Try again when its open'); 
      this.bringToTop();
    }    
    else{        
      let expression=document.getElementById('sandbox-expression-editor-expression');
      if (expression!=null){
        let sExpression=expression.value
        sExpression=sExpression.replace(/\r\n|\r|\n/g,this.itemlinebreaker);
        // check for tabs when not using (two)spaces
        if(this.isSplittedBySemiColon || this.isSplittedByComma ){
          // get rid of tabs and white spaces
          sExpression=sExpression.replace(/\s/g,''); 
        }
        target.value=sExpression;
        // trigger onchange event
        const event = new Event('change', { bubbles: true });  
        target.dispatchEvent(event); 
      } 
    }          
  } 
  
  _onCloseEditor(event) {
    this.close();
  }
        
  _onDisplaySandboxExtensionConfig(event) { 
    event.preventDefault();
    //console.log('display conf'); 
    let f = new ModuleSettingsForm(); 
    f.render(true);
  }   
  
  async _updateObject(event, formData) {
    const expandedData = foundry.utils.expandObject(formData);
    console.log(expandedData);

  }
  
  async _onPaste(event){  
    event.preventDefault();   
    navigator.clipboard.readText()
      .then(text => {
        // `text` contains the text read from the clipboard          
        let doc = this.codeEditor.getDoc();        
        doc.replaceSelection(text); 
      })
      .catch(err => {
        // maybe user didn't grant access to read from clipboard
        ui.notifications.warn('Error when attempting to paste to ' + oAttribute.CAPTION,err);
      });                                                       
  }  
  
  async _onCopySelection(event){  
    this.codeEditor.save();  
    let doc = this.codeEditor.getDoc();        
    let sExpression=doc.getSelection();
    if (sExpression.length>0){            
      navigator.clipboard.writeText(sExpression);
    }                                                       
  }
  
  
  async _onCopyExpression(event){  
    this.codeEditor.save();   
    let expression=document.getElementById('sandbox-expression-editor-expression');
    if (expression!=null){
      let sExpression=expression.value      
      navigator.clipboard.writeText(sExpression);
    }                                                       
  }
  
    async _onCopyExpressionPreFormatted(event){ 
    this.codeEditor.save();    
    let expression=document.getElementById('sandbox-expression-editor-expression');
    if (expression!=null){
      let sExpression=`\`\`\`tp\n` + expression.value + `\n` + `\`\`\``  ;      
      navigator.clipboard.writeText(sExpression);
    }                                                       
  }
  
}