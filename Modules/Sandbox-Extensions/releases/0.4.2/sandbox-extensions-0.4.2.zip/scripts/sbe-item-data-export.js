import { ITEMATTRIBUTE } from "./sbe-constants-item.js"
import { TYPECLASS } from "./sbe-constants-item.js"
//                                                                  //                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                         Public(Exported) functions                           
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  

export function sbe_item_sheet_export_data_plaintext(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'PlainText');  
}

export function sbe_item_sheet_export_data_markdown(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'Markdown');  
}

export function sbe_item_sheet_export_data_html(html, typeClass) {
  sbe_item_sheet_export_data_text_table(html, typeClass,'HTML');  
}

//                                                                  //                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
//                                                                  
//                         Private functions                           
//                                                                  
// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
// 


async function sbe_item_sheet_export_data_text_table(html, typeClass,exportformat) {
  let exportoptions = await sbe_item_sheet_get_export_options(exportformat);
  if (exportoptions !== null) {
    let exportdata = sbe_item_sheet_export_data(html, typeClass, exportoptions);        
    let sFormattedData;
    switch(exportformat){
      case 'Markdown':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions);
        break;
      case 'PlainText':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions,'','---'); 
        break;
      case 'HTML':
        sFormattedData = sbe_item_sheet_format_data_text(exportdata,exportoptions,'','');
      default:
        break;
    }
    
    navigator.clipboard.writeText(sFormattedData);
    ui.notifications.info('Data formatted as ' + exportformat +' table copied to Clipboard');
  }
}



async function sbe_item_sheet_get_export_options(exportformat){
    let dialog=new Promise((resolve,reject)=>{
      new Dialog({
        title: exportformat + ' Export Options',
        content: `
        <fieldset style="text-align:left;">
          <legend style="text-align:left">Export Data Options</legend>
          <table>
            <tr>
              <th> </th><th>Option</th><th>Description</th>
            </tr> 
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-empty" name="include-empty" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-empty" style="white-space:nowrap;">  Include Empty</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include attributes with no value</td>
            </tr>
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-defaults" name="include-default" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-defaults" style="white-space:nowrap;">  Include Defaults</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include attributes with default values</td>
            </tr>
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-include-sub-items" name="includesubitems" value="true"></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-include-sub-items" style="white-space:nowrap;"> Include Subitems</label></td>              
              <td style="vertical-align: top;padding-left:3px;">Include Properties for Panels/Groups, Panels for MultiPanels/Tabs</td>
            </tr>            
          </table>
        </fieldset> 
        
        <fieldset style="text-align:left;">
          <legend style="text-align:left">Export Format Options</legend>
          <table>
            <tr>
              <th> </th><th>Option</th><th>Description</th>
            </tr>                        
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-doublecolumn" name="compact" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-doublecolumn" style="white-space:nowrap;"> Double Column Mode</label></td>              
              <td style="vertical-align: top;">Present data in double column mode(space saving mode)</td>
            </tr>
            <tr>
              <td style="vertical-align: top;"><input type="checkbox" id="sbe-export-options-styleexport" name="styleexport" value="true" checked></td>
              <td style="vertical-align: top;padding-right:10px;"><label for="sbe-export-options-styleexport" style="white-space:nowrap;"> Style Export</label></td>              
              <td style="vertical-align: top;">Styles export with font options</td>
            </tr>
          </table>
        </fieldset>  
        <hr>
        `,
        buttons: {
          ok: {
            icon:'<i class ="fas fa-check"></i>',
            label: "Ok",            
            callback: (html) => {              
              let doublecolumn=   html.find('#sbe-export-options-doublecolumn')[0].checked;
              let includeempty=   html.find('#sbe-export-options-include-empty')[0].checked;
              let includedefaults=html.find('#sbe-export-options-include-defaults')[0].checked;
              let includesubitems=html.find('#sbe-export-options-include-sub-items')[0].checked;
              let styleexport=   html.find('#sbe-export-options-styleexport')[0].checked;
              let options={exportformat:exportformat,doublecolumn:doublecolumn,includeempty:includeempty,includedefaults:includedefaults,includesubitems:includesubitems,styleexport:styleexport};
              resolve(options);
            }
          },
          cancel: { 
            icon:'<i class ="fas fa-times"></i>',
            label: "Cancel",            
            callback: (html) => {              
              resolve(null);
            }
          }
        },
        default: "ok",
        close:  html => {                            
        }   
      }).render(true);             
    });    
    console.log('sbe_item_sheet_get_text_export_options');
    let options=await dialog;  
    if (options===null){
      //throw new Error("User aborted options by clicking Cancel button.");
    }
    return options;
  }






  

function sbe_item_sheet_format_data_text(data, exportoptions, attributeformat = '**', alignment = ':---') {
  let sReturn = '';
  let iColAttributeWidth = 'Attribute'.length;
  let iColValueWidth = 'Value'.length;
  let sAttribute = '';
  let sValue = '';
  const MAXWIDTH=80;
  // determine columns widths
  for (let i = 0; i < data.length; i++) {
    if (data[i][0].length > iColAttributeWidth) {
      iColAttributeWidth = data[i][0].length;
    }
    if (data[i][1].length > iColValueWidth) {
      iColValueWidth = data[i][1].length;
    }
  }
  if(iColValueWidth>MAXWIDTH){
    iColValueWidth=MAXWIDTH;
  }
  if(iColAttributeWidth>MAXWIDTH){
    iColAttributeWidth=MAXWIDTH;
  }
  
  if(!exportoptions.styleexport){
    attributeformat='';
  }
  
  if (!exportoptions.doublecolumn) {
    // add header
    if(exportoptions.exportformat=='HTML'){
      if(exportoptions.styleexport){
        sReturn = '<table>\n<tr><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th></tr>\n';
      } else {
        sReturn = '<table>\n<tr><th>Attribute</th><th>Value</th></tr>\n';
      }
    }
    else{
      sReturn = '| ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ') + ' |' + '\n';
      sReturn += '| ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-') + ' |' + '\n';
    }
    // add each row
    for (let i = 0; i < data.length; i++) {
      sAttribute = attributeformat + data[i][0].toString() + attributeformat;
      sValue = data[i][1].toString();
      if(exportoptions.exportformat=='HTML'){
        if(exportoptions.styleexport){
          sReturn += '<tr><td><b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td></tr>\n';
        } else {
          sReturn += '<tr><td><b>' + sAttribute +'</b></td><td>'  + sValue +'</td></tr>\n';
        }
      }
      else{
        sReturn += '| ' + sAttribute.padEnd(iColAttributeWidth, ' ');
        sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ') + ' |' + '\n';
      }
    }
    if(exportoptions.exportformat=='HTML'){
        sReturn += '</table>\n';
    }
  } 
  else {    
    let bSecondColAdded = false;
    // add header
    if(exportoptions.exportformat=='HTML'){
      if(exportoptions.styleexport){
        sReturn = '<table>\n<tr><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th><th style="text-align:left">Attribute</th><th style="text-align:left">Value</th></tr>\n';
      } else {
        sReturn = '<table>\n<tr><th>Attribute</th><th>Value</th><th>Attribute</th><th>Value</th></tr>\n';
      }
    }
    else{
      sReturn = '| ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Attribute' + attributeformat).padEnd(iColAttributeWidth, ' ');
      sReturn += ' | ' + (attributeformat + 'Value' + attributeformat).padEnd(iColValueWidth, ' ') + ' |' + '\n';
      sReturn += '| ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColAttributeWidth, '-');
      sReturn += ' | ' + alignment.padEnd(iColValueWidth, '-') + ' |' + '\n';
    }
    
    for (let i = 0; i < data.length; i++) {
      sAttribute = attributeformat + data[i][0].toString() + attributeformat;
      sValue = data[i][1].toString();
      if(exportoptions.exportformat=='HTML'){
        if(exportoptions.styleexport){
          sReturn += '<tr><td> <b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td>';
        } else {
          sReturn += '<tr><td> <b>' + sAttribute +'</b></td><td>'  + sValue +'</td>';
        }
      }
      else{
        sReturn += '| ' + sAttribute.padEnd(iColAttributeWidth, ' ');
        sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ');
      }
      bSecondColAdded = false;
      while (i + 1 < data.length && !bSecondColAdded) {
        i = i + 1;
        sAttribute = attributeformat + data[i][0].toString() + attributeformat;
        sValue = data[i][1].toString();
        // add second col
        if(exportoptions.exportformat=='HTML'){
          if(exportoptions.styleexport){
            sReturn += '<td ><b>' + sAttribute +'</b></td><td style="font-family:monospace">'  + sValue +'</td></tr>\n';
          } else {
            sReturn += '<td ><b>' + sAttribute +'</b></td><td>'  + sValue +'</td></tr>\n';
          }
        }
        else{
          sReturn += ' | ' + sAttribute.padEnd(iColAttributeWidth, ' ');
          sReturn += ' | ' + sValue.padEnd(iColValueWidth, ' ') + ' |' + '\n';
        }
        bSecondColAdded = true;
      }
      if (!bSecondColAdded) {
        // add empty
        if(exportoptions.exportformat=='HTML'){
          if(exportoptions.styleexport){
            sReturn += '<td style="font-weight:bold"></td><td style="font-family:monospace"></td></tr>\n';
          } else {
            sReturn += '<td></td><td></td></tr>\n';
          }
        }
        else{
          sReturn += ' | ' + ''.padEnd(iColAttributeWidth, ' ');
          sReturn += ' | ' + ''.padEnd(iColValueWidth, ' ') + ' |' + '\n';
        }
      }
    }
    if(exportoptions.exportformat=='HTML'){
        sReturn += '</table>\n';
    }
  }
  return sReturn;
}
  
  // returns a two dimensional array fieldname:fieldvalue
  function sbe_item_sheet_export_data(html,sTypeClass,exportoptions){
    let data=[];
    let sPanelKey='';      
    // general attributes
    data.push(['Item Type',sTypeClass]);
    sbe_export_data_attribute(data,html,ITEMATTRIBUTE.ITEM.NAME,exportoptions);
    // item type specific attributes  
    switch(sTypeClass.toUpperCase()){
      case TYPECLASS.PROPERTY:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        break;
      case TYPECLASS.MULTIPANEL:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if (exportoptions.includesubitems) {
          // now get the panels for this multipanel 
          sPanelKey = html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let multipanel = game.items.find(y => y.type == 'multipanel' && y.data.data.panelKey == sPanelKey);
          if (multipanel != null) {
            let sPanelName = '';
            for (let i = 0; i < multipanel.data.data.panels.length; i++) {
              sPanelName = multipanel.data.data.panels[i].name;
              data.push(['Panel ' + i.toString().padStart(2, '0'), sPanelName]);
            }
          }
        }
        break;
      case TYPECLASS.PANEL:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the properties for this panel 
          sPanelKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let panel= game.items.find(y=>y.type=='panel'&& y.data.data.panelKey == sPanelKey);          
          if (panel!=null) {
            let sPropertyName='';
            for (let i = 0; i < panel.data.data.properties.length; i++) {
              sPropertyName=panel.data.data.properties[i].name;
              data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName]);
            }            
          }
        }
        break;
      case TYPECLASS.TAB:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the panels for this tab 
          let sTabKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let tab= game.items.find(y=>y.type=='sheettab'&& y.data.data.tabKey == sTabKey);          
          if (tab!=null) {          
            let sPanelName='';
            for (let i = 0; i < tab.data.data.panels.length; i++) {
              sPanelName=tab.data.data.panels[i].name;
              data.push(['Panel ' + i.toString().padStart(2, '0'),sPanelName]);
            }            
          } 
        }
        break;
      case TYPECLASS.GROUP:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        if(exportoptions.includesubitems){
          // now get the properties for this group 
          let sGroupKey=html.find(ITEMATTRIBUTE[sTypeClass.toUpperCase()].KEY.IDENTIFIER)[0].value;
          let group= game.items.find(y=>y.type=='group'&& y.data.data.groupKey == sGroupKey);          
          if (group!=null) {
            let sPropertyName=''; 
            let isConstant=false;
            for (let i = 0; i < group.data.data.properties.length; i++) {
              sPropertyName=group.data.data.properties[i].name; 
              isConstant=group.data.data.properties[i].isconstant;
              if(isConstant){
                data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName +' [Constant]' ]);
              }
              else{
                data.push(['Property ' + i.toString().padStart(2, '0'),sPropertyName]);
              }
            }            
          }
        }
        break;
      case TYPECLASS.CITEM:
        Object.keys(ITEMATTRIBUTE[sTypeClass.toUpperCase()]).forEach(attribute =>
          sbe_export_data_attribute(data,html,ITEMATTRIBUTE[sTypeClass.toUpperCase()][attribute],exportoptions)        
        );
        break;
      default:
        break;
    }
    return data;
  }
  
  function sbe_export_data_attribute(data,html,oAttribute,exportoptions){
    let sValue='';
    let bExportThis=true;
    let element=html.find(oAttribute.IDENTIFIER);
    if (element!=null && element.length>0) {
      switch(element[0].tagName.toLowerCase()) {    
        case 'input':
          if (element[0].type=="checkbox"){ 
            sValue=element[0].checked.toString();
          } 
          else{
            sValue=element[0].value;  
           } 
          break; 
        case 'textarea':
          sValue=element[0].value;
          break
        case 'select':
          sValue=element[0].selectedOptions[0].text;
          break;
      } 
      // now for options
      if(sValue==oAttribute.DEFAULT){
        if(!exportoptions.includedefaults){
          bExportThis=false;
        }
      }
      if(sValue.length==0){
        if(!exportoptions.includeempty){
          bExportThis=false;
        }
      }
      if (bExportThis) {
        if (oAttribute.LINEBREAKER != '') {
          // replace linebreakers
          switch (exportoptions.exportformat) {
            case 'HTML':
              sValue=sValue.replace(/\t/g, '&emsp;'); 
              sValue = sValue.split(oAttribute.LINEBREAKER).join("<br/>\n");
              //sValue='<div style="font-family:monospace">' + sValue +'</div>';
              break;
            case 'PlainText':
              sValue = sValue.split(oAttribute.LINEBREAKER).join("\n");
              break;
            case 'Markdown':
              // replace tabs
              //sValue=sValue.replace(/\t/g, '&emsp;');              
              // escape all specials markdown characters
             //sValue = sValue.replace(/\\(\*|_|`|~|\\)/g, '$1'); // unescape any "backslashed" character
             //sValue = sValue.replace(/(\*|_|`|~|\\)/g, '\\$1'); // escape *, _, `, ~, \

             sValue =sValue.split(oAttribute.LINEBREAKER).join("<br/>")  ;
             // sValue='\`\`\`' + sValue +'\`\`\`';
              break;
          }
        }
        data.push([oAttribute.CAPTION, sValue]);
      }
    }
    
  } 


