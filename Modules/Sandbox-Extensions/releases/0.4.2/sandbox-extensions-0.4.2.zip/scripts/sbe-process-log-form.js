const _title = "Sandbox Extensions Process Log Form";
import { _module_id } from   './sandbox-extensions.js';
import { ModuleSettingsForm } from "./module-settings-form.js";

export class SandboxExtensionsProcessLogForm extends FormApplication {
  static processid = '';
  static titletext = '';
  static formtext = '';
  static processfunction; // will be a reference to the actual function to call, set in the constructor
  static logtableconfiguration; // wil be a json with columns names/types
  
  static doc;  // will contain the forms owner document
  static err_count;
  static warning_count;
  static item_count;
  static table_body;

  constructor(options) {
    super();
    this.processid = options.processid || null;
    this.titletext = options.titletext || null;

    this.formtext = options.formtext || null;
    this.processfunction = options.processfunction || null;
    this.logtableconfiguration = options.logtableconfiguration || null;
    
  }

  static initialize() {
    console.log('Initialized ' + _title);
    
    
  }

  static get defaultOptions() {
    const defaults = super.defaultOptions;
    const overrides = {
      height: 'auto',
      width: 'auto',
      id: this.processid,
      template: `modules/sandbox-extensions/templates/sbe-process-log-form.hbs`,
      title: this.titletext,
      userId: game.userId,
      closeOnSubmit: false, // do not close when submitted
      submitOnChange: false, // submit when any input changes 
      resizable: true
    };
    const mergedOptions = foundry.utils.mergeObject(defaults, overrides);
    return mergedOptions;
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find('button[name="runprocess"]').click(this._onRunProcess.bind(this));
    html.find('#DisplaySandboxExtensionConfig').click(this._onDisplaySandboxExtensionConfig.bind(this));

  }
  // this is whatever data to be displayed initially is handled
  getData(options) {
    let data;
    // set form text, process id, table id, table columns etc
    data={
      processid:this.processid,
      titletext:this.titletext,
      formtext:this.formtext
    };
    return data;
  }

  _onDisplaySandboxExtensionConfig(event) {
    event.preventDefault();
    let f = new ModuleSettingsForm();
    f.render(true);
  }

  // main workhorse
  async _onRunProcess(event) {
    event.preventDefault();
    
    // get the ownder document based on the process id
    this.doc = document.getElementById(this.processid).ownerDocument;
    // get elements
    this.item_count=this.doc.getElementById('process_item_count');
    this.error_count=this.doc.getElementById('process_error_count');
    this.warning_count=this.doc.getElementById('process_warning_count');
    
    
    // disable button
    let runbutton = this.doc.getElementById('runprocess');
    runbutton.disabled = true;

    // clear table, filters and counters   
    this.Form_Reset();

    // show wait
    let wait = this.doc.getElementById('sbe-log-item-please-wait');
    wait.style.display = 'block';
    await this.doEvents();

    // Main function
    this.processfunction();


    // hide wait   
    wait.style.display = 'none';
    // enable button
    runbutton.disabled = false;
  }
  
  SetErrorCount(newvalue){
    this.error_count.value=newvalue;
    if(this.error_count.value>0){
      this.error_count.style.backgroundColor ='red';
    }
    else{
      this.error_count.style.backgroundColor ='initial';
    }
  }
  
  SetWarningCount(newvalue){
    this.warning_count.value=newvalue;
    if(this.warning_count.value>0){
      this.warning_count.style.backgroundColor ='red';
    }
    else{
      this.warning_count.style.backgroundColor ='initial';
    }
  }
  
  SetItemCount(newvalue){
    this.item_count.value=newvalue;
  }
  
  IncItemCount(){
    this.item_count.value=parseInt(this.item_count.value, 10) + 1;
  }
  
  IncErrorCount(){
    this.error_count.value=parseInt(this.error_count.value, 10) + 1;
    this.error_count.style.backgroundColor ='red';
  }
  
  IncWarningCount(){
    this.warning_count.value=parseInt(this.error_count.value, 10) + 1;
    this.warning_count.style.backgroundColor ='yellow';
  }

  Form_Reset() {
    // reet search filters
    this.Filter_Reset();
    // reset counters
    this.SetErrorCount(0);
    this.SetWarningCount(0);
    this.SetItemCount(0);
    // empty log table
    let table = this.doc.querySelector('#' + this.processid + '_tbody');; 
    // empty gear tables
    if (table.rows.length>0){
      for(let i=table.rows.length;i>=1;i--){
        table.deleteRow(-1);	
      }
    }
  }
  
  Filter_Reset(){
    
  }



  // Support functions
  doEvents() {
    return this.pause(100);
  }
  
  async pause(t) {
  var promise = new Promise(
          function (resolve, reject) {
          setTimeout(
                  function () {
                  resolve();
                  }, t);
          });
          return promise;
  }

};



