  // constants used for handling items
  // 
  export  const TYPECLASS={
    ITEM:'ITEM',
    PROPERTY:'PROPERTY',
    MULTIPANEL:'MULTIPANEL',
    PANEL:'PANEL',
    TAB:'TAB',
    GROUP:'GROUP',
    CITEM:'CITEM'
  };
  
  // The order attributes appear in this object are used for exports
  export const ITEMATTRIBUTE={
    ITEM:{
      NAME:                  {ATTRIBUTE:'name',              IDENTIFIER:'input[name="name"]',                CAPTION:'Name'               ,LINEBREAKER:''    ,DEFAULT:''}, 
      TYPECLASS:             {ATTRIBUTE:'typeclass',         IDENTIFIER:'.typelabel',                        CAPTION:'Item Type'          ,LINEBREAKER:''    ,DEFAULT:''}
    },  
    
    PROPERTY:{
      DATATYPE:              {ATTRIBUTE:'datatype',          IDENTIFIER:'select[name="data.datatype"]',      CAPTION:'Data Type'          ,LINEBREAKER:''    ,DEFAULT:''},
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.attKey"]',         CAPTION:'Key'                ,LINEBREAKER:''    ,DEFAULT:''},
      DEFAULT:               {ATTRIBUTE:'default',           IDENTIFIER:'input[name="data.defvalue"]',       CAPTION:'Default Value'      ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.tag"]',            CAPTION:'Tag'                ,LINEBREAKER:''    ,DEFAULT:''}, 
      TOOLTIP:               {ATTRIBUTE:'tooltip',           IDENTIFIER:'textarea[name="data.tooltip"]',     CAPTION:'Tooltip'            ,LINEBREAKER:''    ,DEFAULT:''},
      
      ISHIDDEN:              {ATTRIBUTE:'ishidden',          IDENTIFIER:'input[name="data.ishidden"]',       CAPTION:'Hidden'             ,LINEBREAKER:''    ,DEFAULT:'false'},
      EDITABLE:              {ATTRIBUTE:'editable',          IDENTIFIER:'input[name="data.editable"]',       CAPTION:'Editable'           ,LINEBREAKER:''    ,DEFAULT:'true'}, 
      HASLABEL:              {ATTRIBUTE:'haslabel',          IDENTIFIER:'input[name="data.haslabel"]',       CAPTION:'Has Label'          ,LINEBREAKER:''    ,DEFAULT:'true'},     
      LABELSIZE:             {ATTRIBUTE:'labelsize',         IDENTIFIER:'select[name="data.labelsize"]',     CAPTION:'Label Size'         ,LINEBREAKER:''    ,DEFAULT:'Fit'},
      LABELFORMAT:           {ATTRIBUTE:'labelformat',       IDENTIFIER:'select[name="data.labelformat"]',   CAPTION:'Label Format'       ,LINEBREAKER:''    ,DEFAULT:'Normal'},
      INPUTSIZE:             {ATTRIBUTE:'inputsize',         IDENTIFIER:'select[name="data.inputsize"]',     CAPTION:'Input Size'         ,LINEBREAKER:''    ,DEFAULT:'Fit'}, 
       
      FONTGROUP:             {ATTRIBUTE:'fontgroup',         IDENTIFIER:'input[name="data.fontgroup"]',      CAPTION:'Font Group'         ,LINEBREAKER:' '    ,DEFAULT:''},      
      INPUTGROUP:            {ATTRIBUTE:'inputgroup',        IDENTIFIER:'input[name="data.inputgroup"]',     CAPTION:'Input Group'        ,LINEBREAKER:' '    ,DEFAULT:''},      
      
      MACRO:                 {ATTRIBUTE:'macro',         IDENTIFIER:'select[name="data.macroid"]',     CAPTION:'Macro'         ,LINEBREAKER:''    ,DEFAULT:'No Macro'},
       
      ROLLABLE:              {ATTRIBUTE:'rollable',          IDENTIFIER:'input[name="data.hasroll"]',        CAPTION:'Rollable'           ,LINEBREAKER:''    ,DEFAULT:'false'},   
      ROLLNAME:              {ATTRIBUTE:'rollname',          IDENTIFIER:'input[name="data.rollname"]',       CAPTION:'Roll Name'          ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      ROLLID:                {ATTRIBUTE:'rollid',            IDENTIFIER:'input[name="data.rollid"]',         CAPTION:'Roll ID'            ,LINEBREAKER:''    ,DEFAULT:''},  
      ROLLEXP:               {ATTRIBUTE:'rollexp',           IDENTIFIER:'input[name="data.rollexp"]',        CAPTION:'Roll Formula'       ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      
      HASDIALOG:             {ATTRIBUTE:'hasdialog',         IDENTIFIER:'input[name="data.hasdialog"]',      CAPTION:'Has Dialog'         ,LINEBREAKER:''    ,DEFAULT:'false'}, 
      DIALOGPANEL:           {ATTRIBUTE:'dialogpanel',       IDENTIFIER:'input[name="data.dialogName"]',     CAPTION:'Dialog Panel'       ,LINEBREAKER:''    ,DEFAULT:''}, 
      
      AUTO:                  {ATTRIBUTE:'auto',              IDENTIFIER:'input[name="data.auto"]',           CAPTION:'Auto'               ,LINEBREAKER:'  '    ,DEFAULT:''},
      AUTOMAX:               {ATTRIBUTE:'automax',           IDENTIFIER:'input[name="data.automax"]',        CAPTION:'Max Value'          ,LINEBREAKER:'  '    ,DEFAULT:''}, 
      MAXVISIBLE:            {ATTRIBUTE:'maxvisible',        IDENTIFIER:'input[name="data.maxvisible"]',     CAPTION:'Max Visible'        ,LINEBREAKER:''    ,DEFAULT:'true'},
      MAXTOP:                {ATTRIBUTE:'maxtop',            IDENTIFIER:'input[name="data.maxtop"]',         CAPTION:'Max Top'            ,LINEBREAKER:''    ,DEFAULT:'true'},
      
      CHECKGROUP:            {ATTRIBUTE:'checkgroup',        IDENTIFIER:'input[name="data.checkgroup"]',     CAPTION:'Check Group'        ,LINEBREAKER:';'    ,DEFAULT:''},
      CUSTOMIMAGE:           {ATTRIBUTE:'customimage',       IDENTIFIER:'input[name="data.customcheck"]',    CAPTION:'Custom Image'       ,LINEBREAKER:''    ,DEFAULT:'false'},
      CHECKEDPATH:           {ATTRIBUTE:'checkedpath',       IDENTIFIER:'input[name="data.onPath"]',         CAPTION:'Checked Path'       ,LINEBREAKER:''    ,DEFAULT:''},
      UNCHECKEDPATH:         {ATTRIBUTE:'uncheckedpath',     IDENTIFIER:'input[name="data.offPath"]',        CAPTION:'Unchecked Path'     ,LINEBREAKER:''    ,DEFAULT:''},
            
      RADIOTYPE:             {ATTRIBUTE:'radiotype',         IDENTIFIER:'select[name="data.radiotype"]',     CAPTION:'Radio Type'         ,LINEBREAKER:''    ,DEFAULT:'Circle'},
      LIST:                  {ATTRIBUTE:'list',              IDENTIFIER:'input[name="data.listoptions"]',    CAPTION:'Options (a,b,c)'    ,LINEBREAKER:','    ,DEFAULT:''},
      
      GROUP:                 {ATTRIBUTE:'group',             IDENTIFIER:'input[name="data.group.name"]',     CAPTION:'Group'              ,LINEBREAKER:''    ,DEFAULT:''},
      HASHEADER:             {ATTRIBUTE:'hasheader',         IDENTIFIER:'input[name="data.hasheader"]',      CAPTION:'Has Header'         ,LINEBREAKER:''    ,DEFAULT:'true'},
      COLUMNNAME:            {ATTRIBUTE:'columnname',        IDENTIFIER:'input[name="data.namecolumn"]',     CAPTION:'ColumnName'         ,LINEBREAKER:''    ,DEFAULT:''},
      ISFREE:                {ATTRIBUTE:'isfree',            IDENTIFIER:'input[name="data.isfreetable"]',    CAPTION:'Is Free'            ,LINEBREAKER:''    ,DEFAULT:'false'},
      TRANSFERABLE:          {ATTRIBUTE:'transferable',      IDENTIFIER:'input[name="data.transferrable"]',  CAPTION:'Transferable'       ,LINEBREAKER:''    ,DEFAULT:'false'},
      HEIGHT:                {ATTRIBUTE:'height',            IDENTIFIER:'select[name="data.tableheight"]',   CAPTION:'Height'             ,LINEBREAKER:''    ,DEFAULT:'FREE'},
      ITEMNAMES:             {ATTRIBUTE:'itemnames',         IDENTIFIER:'select[name="data.onlynames"]',     CAPTION:'Item Names'         ,LINEBREAKER:''    ,DEFAULT:'YES'},
      SHOWUNITS:             {ATTRIBUTE:'showunits',         IDENTIFIER:'input[name="data.hasunits"]',       CAPTION:'Show Units'         ,LINEBREAKER:''    ,DEFAULT:'true'},
      SHOWUSES:              {ATTRIBUTE:'showuses',          IDENTIFIER:'input[name="data.hasuses"]',        CAPTION:'Show Uses'          ,LINEBREAKER:''    ,DEFAULT:'true'},
      SHOWACTIVATION:        {ATTRIBUTE:'showactivation',    IDENTIFIER:'input[name="data.hasactivation"]',  CAPTION:'Show Activation'    ,LINEBREAKER:''    ,DEFAULT:'false'},
      SHOWTOTALS:            {ATTRIBUTE:'showtotals',        IDENTIFIER:'input[name="data.hastotals"]',      CAPTION:'Show Totals'        ,LINEBREAKER:''    ,DEFAULT:'false'}
    },    
    
    MULTIPANEL:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.panelKey"]',       CAPTION:'Panel Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      WIDTH:                 {ATTRIBUTE:'width',             IDENTIFIER:'select[name="data.width"]',         CAPTION:'Width'              ,LINEBREAKER:''    ,DEFAULT:'1'},
      HEADERGROUP:           {ATTRIBUTE:'headergroup',       IDENTIFIER:'input[name="data.headergroup"]',    CAPTION:'Header Group'       ,LINEBREAKER:' '   ,DEFAULT:''},
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},                    
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''}
    },
    
    PANEL:{ 
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.panelKey"]',       CAPTION:'Panel Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      WIDTH:                 {ATTRIBUTE:'width',             IDENTIFIER:'select[name="data.width"]',         CAPTION:'Width'              ,LINEBREAKER:''    ,DEFAULT:'1'},
       
      COLUMNS:               {ATTRIBUTE:'columns',           IDENTIFIER:'select[name="data.columns"]',       CAPTION:'Columns'            ,LINEBREAKER:''    ,DEFAULT:'1'},
      CONTENTALIGNMENT:      {ATTRIBUTE:'contentalignment',  IDENTIFIER:'select[name="data.contentalign"]',  CAPTION:'Content Alignment'  ,LINEBREAKER:''    ,DEFAULT:'left'},
      LABELALIGNMENT:        {ATTRIBUTE:'labelalignment',    IDENTIFIER:'select[name="data.alignment"]',     CAPTION:'Label Alignment'    ,LINEBREAKER:''    ,DEFAULT:'left'},
      TITLEBACKGROUND:       {ATTRIBUTE:'titlebackground',   IDENTIFIER:'select[name="data.backg"]',         CAPTION:'Title Background'   ,LINEBREAKER:''    ,DEFAULT:'DEFAULT'},
      ISIMAGE:               {ATTRIBUTE:'isimage',           IDENTIFIER:'input[name="data.isimg"]',          CAPTION:'Is Image'           ,LINEBREAKER:''    ,DEFAULT:'false'},
      IMAGEPATH:             {ATTRIBUTE:'imgsrc',            IDENTIFIER:'input[name="data.imgsrc"]',         CAPTION:'Image Path'         ,LINEBREAKER:''    ,DEFAULT:''},       
       
      FONTGROUP:             {ATTRIBUTE:'fontgroup',         IDENTIFIER:'input[name="data.fontgroup"]',      CAPTION:'Font Group'         ,LINEBREAKER:' '   ,DEFAULT:''},      
      INPUTGROUP:            {ATTRIBUTE:'inputgroup',        IDENTIFIER:'input[name="data.inputgroup"]',     CAPTION:'Input Group'        ,LINEBREAKER:' '   ,DEFAULT:''},
      HEADERGROUP:           {ATTRIBUTE:'headergroup',       IDENTIFIER:'input[name="data.headergroup"]',    CAPTION:'Header Group'       ,LINEBREAKER:' '   ,DEFAULT:''},
      
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''}                      
    },
    
    TAB:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.tabKey"]',         CAPTION:'Tab Key'            ,LINEBREAKER:''    ,DEFAULT:''},
      TAG:                   {ATTRIBUTE:'tag',               IDENTIFIER:'input[name="data.title"]',          CAPTION:'Title'              ,LINEBREAKER:''    ,DEFAULT:''},
      CONTROL:               {ATTRIBUTE:'control',           IDENTIFIER:'select[name="data.controlby"]',     CAPTION:'Control'            ,LINEBREAKER:''    ,DEFAULT:'public'},
      VISIBLEIF:             {ATTRIBUTE:'visibleif',         IDENTIFIER:'input[name="data.condat"]',         CAPTION:'Visible If'         ,LINEBREAKER:''    ,DEFAULT:''},
      VISIBLEOPERATOR:       {ATTRIBUTE:'visibleoperator',   IDENTIFIER:'select[name="data.condop"]',        CAPTION:'Visible Operator'   ,LINEBREAKER:''    ,DEFAULT:'NONE'},
      VISIBLEVALUE:          {ATTRIBUTE:'visiblevalue',      IDENTIFIER:'input[name="data.condvalue"]',      CAPTION:'Visible Value'      ,LINEBREAKER:''    ,DEFAULT:''} 
    },
          
    GROUP:{
      KEY:                   {ATTRIBUTE:'key',               IDENTIFIER:'input[name="data.groupKey"]',       CAPTION:'Group Key'          ,LINEBREAKER:''    ,DEFAULT:''},
      ISUNIQUE:              {ATTRIBUTE:'isunique',          IDENTIFIER:'input[name="data.isUnique"]',       CAPTION:'Is Unique'          ,LINEBREAKER:''    ,DEFAULT:'false'}     
    },
    
    CITEM:{
      ROLLEXP:               {ATTRIBUTE:'rollexp',           IDENTIFIER:'input[name="data.roll"]',           CAPTION:'Roll Formula'       ,LINEBREAKER:'  '  ,DEFAULT:''}, 
      ROLLNAME:              {ATTRIBUTE:'rollname',          IDENTIFIER:'input[name="data.rollname"]',       CAPTION:'Roll Name'          ,LINEBREAKER:'  '  ,DEFAULT:''}, 
      ROLLID:                {ATTRIBUTE:'rollid',            IDENTIFIER:'input[name="data.rollid"]',         CAPTION:'Roll ID'            ,LINEBREAKER:''    ,DEFAULT:''}
    }
  };

