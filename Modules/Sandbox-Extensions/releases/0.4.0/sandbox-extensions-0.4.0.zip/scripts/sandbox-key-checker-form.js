
const _title="Sandbox Key Checker";
import { SandboxKeyValidate } from "./sandbox-key-validate.js";
import { _module_id } from   './sandbox-extensions.js';
import { ModuleSettingsForm } from "./module-settings-form.js";
export class SandboxKeyCheckerForm extends FormApplication {

  static initialize() {
    
    console.log('Initialized SandboxKeyCheckerForm' );
  }   
    
  static get defaultOptions() {
    const defaults = super.defaultOptions;  
    const overrides = {
      height: 'auto',
      width:'1024',
      id: 'sandbox-key-checker-form',
      template: `modules/sandbox-extensions/templates/sandbox-key-checker-form.hbs`,
      title: _title,
      userId: game.userId,
      closeOnSubmit: false, // do not close when submitted
      submitOnChange: false, // submit when any input changes 
      resizable:true
    };  
    const mergedOptions = foundry.utils.mergeObject(defaults, overrides);    
    return mergedOptions;
  }  
  
  activateListeners(html) {
    super.activateListeners(html);
    html.find('button[name="runkeycheck"]').click(this._onRunCheck.bind(this));
    html.find('#DisplaySandboxExtensionConfig').click(this._onDisplaySandboxExtensionConfig.bind(this)); 
      
  }
  
  getData(options) {      
    let data;
    return data;
  }    
        
  _onDisplaySandboxExtensionConfig(event) { 
    event.preventDefault();
    console.log('display conf'); 
    let f = new ModuleSettingsForm(); 
    f.render(true);
  }
  
  _onRunCheck(event) { 
    event.preventDefault();    
    // clear table   
    SandboxKeyCheckerForm_ResetCount(); 
    
          
    // first tabs
    let items; 
    let dtype;  
    const enforcedvalidation=SandboxKeyCheckerForm_get_game_setting(_module_id, 'OPTION_ENFORCED_VALIDATION');
    if(enforcedvalidation){ 
      document.getElementById('key_validation_mode').value= 'Enforced';
    }
    else{
      document.getElementById('key_validation_mode').value= 'Standard';
    }
    //       
    dtype="sheettab";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){             
          SandboxKeyCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.tabKey ,enforcedvalidation );
        } 
      });   
    } 
      
    dtype="multipanel";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){
          SandboxKeyCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.panelKey,enforcedvalidation  );
        } 
      });   
    }      
    
    dtype="panel";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){
          SandboxKeyCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.panelKey,enforcedvalidation  );
        } 
      });   
    }    
    
    dtype="group";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){
          SandboxKeyCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.groupKey,enforcedvalidation );
        } 
      });   
    }  
    
    dtype="property";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){
          SandboxKeyCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.attKey ,enforcedvalidation );
        } 
      });   
    }  
  }  
}

  function SandboxKeyCheckerForm_get_game_setting(moduleID,settingName){
    let setting=game.settings.get(moduleID, settingName);
    if (!setting) {
      return  '';
    }
    else{
      return setting;
    }
  }


  function SandboxKeyCheckerForm_CheckKey(validatingitemtype,validatingitemid,item,key,enforcedvalidation){    
    SandboxKeyCheckerForm_IncCheckCount();
    let objResult = SandboxKeyValidate(validatingitemtype,validatingitemid,key,enforcedvalidation); 
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){    
      objResult.warnings.forEach(function(msg){
        //ui.notifications.warn(item); 
        SandboxKeyCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key , msg,'Warning');
        SandboxKeyCheckerForm_IncWarningCount();     
      });  
       objResult.errors.forEach(function(msg){
        //ui.notifications.error(item); 
        SandboxKeyCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key , msg,'Error');
        SandboxKeyCheckerForm_IncErrCount();             
      });                    
    } 
    
    else{                     
      //ui.notifications.info('Key [' + sKey + '] valid for ' + typeClass + ' [' + itemName +']'  );
      SandboxKeyCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key , 'OK'); 
    } 

  }

  //msgclass,type,item,key,msg
  function SandboxKeyCheckerForm_LogCheckMessage(validatingitemid,type,item,key,msg,msgclass='Info'){ 
/*    if (msgclass=='Debug' &&  ${Setting_ShowDebugMsg()}==false){
      // dont log this, exit
      return 0;
    }*/
    //access the table and store it in a variable
    let table = document.querySelector('#run_key_check_tablelog');
    //create rows and store it in a variable
    let row = table.insertRow();             
    // if a item id is supplied
    if(validatingitemid!=''){
      // add clickable link
      row.setAttribute("onclick","SandboxKeyCheckerForm_ShowItem('"+validatingitemid+"')")
    } 
    let logclass;
    switch(msgclass){ 
      case 'Debug':         
        row.className ="sbe-log-table-row sbe-log-table-row-debug";         
        break;
      case 'Warning':
        row.className ="sbe-log-table-row sbe-log-table-row-warning";          
        break;
      case 'Error':
        row.className ="sbe-log-table-row sbe-log-table-row-error";        
        break;              
      default:
        row.className ="sbe-log-table-row sbe-log-table-row-info";        
        break;
    }     
    //now need to give some data to the row
    row.innerHTML = `
        <td class="sbe-log-table-cell sbe-log-table-cell-msgclass">` + msgclass + `</td>
        <td class="sbe-log-table-cell sbe-log-table-cell-type">`+ type +`</td>
        <td class="sbe-log-table-cell sbe-log-table-cell-item">`+ item +`</td>
        <td class="sbe-log-table-cell sbe-log-table-cell-key">`+ key +`</td>
        <td class="sbe-log-table-cell sbe-log-table-cell-msg">` + msg + `</td>`;
    table.scrollTop = table.scrollHeight;  
  }
     
  
  function SandboxKeyCheckerForm_ResetCount(){
    SandboxKeyCheckerForm_SetCheckCount(0); 
    SandboxKeyCheckerForm_SetErrCount(0);
    SandboxKeyCheckerForm_SetWarningCount(0);
    // clear table   
    let table = document.querySelector('#run_key_check_tablelog');; 
    // empty gear tables
    if (table.rows.length>0){
      for(let i=table.rows.length;i>=1;i--){
        table.deleteRow(-1);	
      }
    }
  }

  function SandboxKeyCheckerForm_SetErrCount(value){
    document.getElementById('key_err_count').value=value;
    if(value>0){
      document.getElementById('key_err_count').style.backgroundColor ='red';
    }
    else{
      document.getElementById('key_err_count').style.backgroundColor ='initial';
    }
  }  
  function SandboxKeyCheckerForm_SetWarningCount(value){
    document.getElementById('key_warning_count').value=value;
    if(value>0){
      document.getElementById('key_warning_count').style.backgroundColor ='yellow';
    }
    else{
      document.getElementById('key_warning_count').style.backgroundColor ='initial';
    }
  }
      
  function SandboxKeyCheckerForm_SetCheckCount(value){
    document.getElementById('key_count').value=value;
  }
  
  function SandboxKeyCheckerForm_IncErrCount(){
    document.getElementById('key_err_count').value=parseInt(document.getElementById('key_err_count').value, 10) + 1;
    document.getElementById('key_err_count').style.backgroundColor ='red';
  } 
  
  function SandboxKeyCheckerForm_IncWarningCount(){
    document.getElementById('key_warning_count').value=parseInt(document.getElementById('key_warning_count').value, 10) + 1;
    document.getElementById('key_warning_count').style.backgroundColor ='yellow';
  }
        
  function SandboxKeyCheckerForm_IncCheckCount(){
    document.getElementById('key_count').value=parseInt(document.getElementById('key_count').value, 10) + 1;
  } 


  