
const _title="Sandbox Item Structure Checker";
import { SandboxKeyValidate } from "./sandbox-key-validate.js";
import { _module_id } from   './sandbox-extensions.js';
import { ModuleSettingsForm } from "./module-settings-form.js";
export class SandboxItemCheckerForm extends FormApplication {

  static initialize() {
    
    console.log('Initialized SandboxItemCheckerForm' );
  }   
    
  static get defaultOptions() {
    const defaults = super.defaultOptions;  
    const overrides = {
      height: 'auto',
      width:'1280',
      id: 'sandbox-item-checker-form',
      template: `modules/sandbox-extensions/templates/sandbox-item-checker-form.hbs`,
      title: _title,
      userId: game.userId,
      closeOnSubmit: false, // do not close when submitted
      submitOnChange: false, // submit when any input changes 
      resizable:true
    };  
    const mergedOptions = foundry.utils.mergeObject(defaults, overrides);    
    return mergedOptions;
  }  
  
  activateListeners(html) {
    super.activateListeners(html);
    html.find('button[name="runitemcheck"]').click(this._onRunCheck.bind(this));
    html.find('#DisplaySandboxExtensionConfig').click(this._onDisplaySandboxExtensionConfig.bind(this)); 
      
  }
  
  getData(options) {      
    let data;
    return data;
  }    
        
  _onDisplaySandboxExtensionConfig(event) { 
    event.preventDefault();
    console.log('display conf'); 
    let f = new ModuleSettingsForm(); 
    f.render(true);
  }
  
  _onRunCheck(event) { 
    event.preventDefault();    
    // clear table   
    SandboxItemCheckerForm_ResetCount(); 
    
    
    
    let actortemplates=game.actors.filter(y => y.data.data.istemplate==true);
    
    if(actortemplates.length>0){
      actortemplates.forEach(function(actortemplate)  { 
        if(actortemplate!=null){
          //console.warn(actortemplate);
          if(actortemplate.data.data.tabs.length>0){
            for (let i = 0; i < actortemplate.data.data.tabs.length; i++) {
              //SandboxItemCheckerForm_CheckItem(validatingitemtype,validatingitemid,item,key,subitem,subitemkey,subitemid)
              SandboxItemCheckerForm_CheckItem('actortemplate',actortemplate.id,actortemplate.data.name, actortemplate.data.data.gtemplate,actortemplate.data.data.tabs[i].name,actortemplate.data.data.tabs[i].ikey,actortemplate.data.data.tabs[i].id  );
            }
          }
        }
      });
    }
    
    // first tabs
    let items; 
    let dtype;  
    const enforcedvalidation=SandboxItemCheckerForm_get_game_setting(_module_id, 'OPTION_ENFORCED_VALIDATION');
    if(enforcedvalidation){ 
      document.getElementById('item_key_validation_mode').value= 'Enforced';
    }
    else{
      document.getElementById('item_key_validation_mode').value= 'Standard';
    }
    //       
    dtype="sheettab";
    items = game.items.filter(y=>(y.type==dtype));          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){ 
          SandboxItemCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.tabKey,enforcedvalidation );
          if(item.data.data.panels.length>0){
          //console.log(item);
            for (let i = 0; i < item.data.data.panels.length; i++) {
              //SandboxItemCheckerForm_CheckItem(validatingitemtype,validatingitemid,item,key,subitem,subitemkey,subitemid,enforcedvalidation)
              SandboxItemCheckerForm_CheckItem(dtype,item.id,item.name, item.data.data.tabKey,item.data.data.panels[i].name,item.data.data.panels[i].ikey,item.data.data.panels[i].id ,enforcedvalidation );
            }
          }
        } 
      });   
    } 
      
    dtype = "multipanel";
    items = game.items.filter(y => (y.type == dtype));
    if (items.length > 0) {
      // found items, check each one                 
      items.forEach(function (item) {
        // check if this is the item 
        if (item != null) {
          SandboxItemCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.panelKey,enforcedvalidation );
          if (item.data.data.panels.length > 0) {
            //console.log(item);
            for (let i = 0; i < item.data.data.panels.length; i++) {
              SandboxItemCheckerForm_CheckItem(dtype, item.id, item.name, item.data.data.panelKey,item.data.data.panels[i].name,item.data.data.panels[i].ikey,item.data.data.panels[i].id,enforcedvalidation );
            }
          }
        }
      });
    }      
    
    dtype = "panel";
    items = game.items.filter(y => (y.type == dtype));
    if (items.length > 0) {
      // found items, check each one                 
      items.forEach(function (item) {
        // check if this is the item 
        if (item != null) {
          SandboxItemCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.panelKey,enforcedvalidation );
          if (item.data.data.properties.length > 0) {
            //console.log(item);
            for (let i = 0; i < item.data.data.properties.length; i++) {
              SandboxItemCheckerForm_CheckItem(dtype, item.id, item.name, item.data.data.panelKey, item.data.data.properties[i].name, item.data.data.properties[i].ikey, item.data.data.properties[i].id,enforcedvalidation);
            }
          }
        }
      });
    }    
    
    dtype = "group";
    items = game.items.filter(y => (y.type == dtype));
    if (items.length > 0) {
      // found items, check each one                 
      items.forEach(function (item) {
        // check if this is the item 
        if (item != null) {
          SandboxItemCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.groupKey,enforcedvalidation );
          if (item.data.data.properties.length > 0) {
            //console.log(item);
            for (let i = 0; i < item.data.data.properties.length; i++) {
              SandboxItemCheckerForm_CheckItem(dtype, item.id, item.name, item.data.data.groupKey, item.data.data.properties[i].name, item.data.data.properties[i].ikey, item.data.data.properties[i].id,enforcedvalidation);
            }
          }
        }
      });
    }  
    
    // properties will be validated by their parents

  }  
}

  function SandboxItemCheckerForm_get_game_setting(moduleID,settingName){
    let setting=game.settings.get(moduleID, settingName);
    if (!setting) {
      return  '';
    }
    else{
      return setting;
    }
  }


  function SandboxItemCheckerForm_CheckItem(validatingitemtype,validatingitemid,item,key,subitem,subitemkey,subitemid,enforcedvalidation){    
    SandboxItemCheckerForm_IncCheckCount();
    // do the checking
 
    
    // make sure that you can find the subitem by its key and name
    let subitemtype=';'
    let subitembykey;
    let subitembyname;
    let subitemkeytype='';
    switch (validatingitemtype.toUpperCase()) {
      case 'GROUP':
        subitemtype='property';
        subitemkeytype='attKey';
        subitembykey=game.items.filter(y=>y.type=="property" && y.data.data.attKey==subitemkey);
        subitembyname=game.items.filter(y=>y.type=="property" && y.name==subitem);
        
        break;
      case 'PANEL':
        subitemtype='property';
        subitemkeytype='attKey';
        subitembykey=game.items.filter(y=>y.type=="property" && y.data.data.attKey==subitemkey);
        subitembyname=game.items.filter(y=>y.type=="property" && y.name==subitem);
        break;
      case 'MULTIPANEL':
        subitemtype='panel';
        subitemkeytype='panelKey';
        subitembykey=game.items.filter(y=>y.type=="panel" && y.data.data.panelKey == subitemkey);
        subitembyname=game.items.filter(y=>y.type=="panel" && y.name==subitem);
        break;
      case 'SHEETTAB':
        subitemtype='panel';
        subitemkeytype='panelKey';
        subitembykey=game.items.filter(y=>(y.type=="panel" || y.type=="multipanel") && y.data.data.panelKey == subitemkey);
        subitembyname=game.items.filter(y=>(y.type=="panel" || y.type=="multipanel") && y.name==subitem);
        
        break;
      case 'ACTORTEMPLATE':
        subitemtype='sheettab';
        subitemkeytype='tabKey';
        subitembykey=game.items.filter(y=>(y.type=="sheettab") && y.data.data.tabKey == subitemkey);
        subitembyname=game.items.filter(y=>y.type=="sheettab" && y.name==subitem);
        break;
    }     
    
    // get the id of the bykey
    let validatingsubitemid='';
    if(subitembykey){
      if(subitembykey.length>0){
        validatingsubitemid=subitembykey[0].id;
      //console.log(subitembykey);
      }
    }
    
    // start by do a key validation of subitem
    // function     SandboxKeyValidate(validatingitemtype,validatingitemid,sKey,enforcedvalidation=true){ 
    let objResult = SandboxKeyValidate(subitemtype,validatingsubitemid,subitemkey,enforcedvalidation);
    
    // check that subitem key is not empty
    if(subitemkey.length==0){
      objResult.errors.push('Subitem key missing for ' + validatingitemtype); 
    }
    
    let subitembyid=game.items.get(subitemid);
    if (subitembyid){
      if(subitem!=subitembyid.name){
        objResult.warnings.push('Subitem ID points to ' +subitemtype +'[' + subitembyid.name +']');
      }
      if(subitembyid.data.data.hasOwnProperty(subitemkeytype)){
        if(subitembyid.data.data[subitemkeytype]!=subitemkey){
          objResult.errors.push('Subitem ID points to ' +subitemtype +'[' + subitembyid.name +'] with key['+ subitembyid.data.data[subitemkeytype]+']');
        }
      }
    }
    
    if(subitembykey.length==0){
      objResult.errors.push('Subitem not found by key(key is bad, have changed or item does not exist)' );
    }
    else if(subitembykey.length>1){
      for (let i = 0; i < subitembykey.length; i++) {
        if(subitem!=subitembykey[i].name){
          objResult.errors.push('Subitem key exist for more than one ' + subitemtype + ' ['+ subitembykey[i].name +']');
        }
      }
    }
    if(subitembyname.length==0){
      objResult.warnings.push('Subitem not found by name(name is bad, have changed or item does not exist)' );
    }
    else if(subitembyname.length>1){
      for (let i = 0; i < subitembyname.length; i++) {
        if(subitem!=subitembyname[i].name){
          objResult.warnings.push('Subitem name exist for more than one ' + subitemtype + ' ['+ subitembyname[i].name +']' );
        }
      }
    }

    
    
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){    
      objResult.warnings.forEach(function(msg){
        //ui.notifications.warn(item); 
        SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , msg,'Warning');
        SandboxItemCheckerForm_IncWarningCount();     
      });  
       objResult.errors.forEach(function(msg){
        //ui.notifications.error(item); 
        SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , msg,'Error');
        SandboxItemCheckerForm_IncErrCount();             
      });                    
    } 
    
    else{                     
      //ui.notifications.info('Item [' + sItem + '] valid for ' + typeClass + ' [' + itemName +']'  );
      SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , 'OK'); 
    } 

  }
  //SandboxItemCheckerForm_CheckKey(dtype,item.id,item.name, item.data.data.groupKey,enforcedvalidation );
  function SandboxItemCheckerForm_CheckKey(validatingitemtype,validatingitemid,item,key,enforcedvalidation){    
    SandboxItemCheckerForm_IncCheckCount();
    let objResult = SandboxKeyValidate(validatingitemtype,validatingitemid,key,enforcedvalidation); 
    let subitem='';
    let subitemkey='';
    let subitemid='';
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){    
      objResult.warnings.forEach(function(msg){
        //ui.notifications.warn(item); 
        SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , msg,'Warning');
        SandboxItemCheckerForm_IncWarningCount();     
      });  
       objResult.errors.forEach(function(msg){
        //ui.notifications.error(item); 
        SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , msg,'Error');
        SandboxItemCheckerForm_IncErrCount();             
      });                    
    } 
    
    else{                     
      //ui.notifications.info('Key [' + sKey + '] valid for ' + typeClass + ' [' + itemName +']'  );
      SandboxItemCheckerForm_LogCheckMessage(validatingitemid,validatingitemtype,item, key,subitem,subitemkey,subitemid , 'OK'); 
    } 

  }

  //msgclass,type,item,key,msg
  function SandboxItemCheckerForm_LogCheckMessage(validatingitemid,type,item,key,subitem,subitemkey,subitemid,msg,msgclass='Info'){ 
/*    if (msgclass=='Debug' &&  ${Setting_ShowDebugMsg()}==false){
      // dont log this, exit
      return 0;
    }*/
    //access the table and store it in a variable
    let table = document.querySelector('#run_item_check_tablelog');
    //create rows and store it in a variable
    let row = table.insertRow();             
    // if a item id is supplied
    if(validatingitemid!=''){
      // add clickable link
      row.setAttribute("onclick","SandboxItemCheckerForm_ShowItem('"+validatingitemid+"')")
    } 
    let logclass;
    switch(msgclass){ 
      case 'Debug':         
        row.className ="sbe-log-table-row sbe-log-table-row-debug";         
        break;
      case 'Warning':
        row.className ="sbe-log-table-row sbe-log-table-row-warning";          
        break;
      case 'Error':
        row.className ="sbe-log-table-row sbe-log-table-row-error";        
        break;              
      default:
        row.className ="sbe-log-table-row sbe-log-table-row-info";        
        break;
    }     
    //now need to give some data to the row
    row.innerHTML = `
            <td class="sbe-log-table-cell sbe-log-table-cell-msgclass">` + msgclass + `</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-type">`+ type +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-item">`+ item +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-key">`+ key +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-item">`+ subitem +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-item">`+ subitemkey +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-id">`+ subitemid +`</td>
            <td class="sbe-log-table-cell sbe-log-table-cell-msg">` + msg + `</td>`;
    table.scrollTop = table.scrollHeight;  
  }
     
  
  function SandboxItemCheckerForm_ResetCount(){
    SandboxItemCheckerForm_SetCheckCount(0); 
    SandboxItemCheckerForm_SetErrCount(0);
    SandboxItemCheckerForm_SetWarningCount(0);
    // clear table   
    let table = document.querySelector('#run_item_check_tablelog');; 
    // empty gear tables
    if (table.rows.length>0){
      for(let i=table.rows.length;i>=1;i--){
        table.deleteRow(-1);	
      }
    }
  }

  function SandboxItemCheckerForm_SetErrCount(value){
    document.getElementById('item_err_count').value=value;
    if(value>0){
      document.getElementById('item_err_count').style.backgroundColor ='red';
    }
    else{
      document.getElementById('item_err_count').style.backgroundColor ='initial';
    }
  }  
  function SandboxItemCheckerForm_SetWarningCount(value){
    document.getElementById('item_warning_count').value=value;
    if(value>0){
      document.getElementById('item_warning_count').style.backgroundColor ='yellow';
    }
    else{
      document.getElementById('item_warning_count').style.backgroundColor ='initial';
    }
  }
      
  function SandboxItemCheckerForm_SetCheckCount(value){
    document.getElementById('item_count').value=value;
  }
  
  function SandboxItemCheckerForm_IncErrCount(){
    document.getElementById('item_err_count').value=parseInt(document.getElementById('item_err_count').value, 10) + 1;
    document.getElementById('item_err_count').style.backgroundColor ='red';
  } 
  
  function SandboxItemCheckerForm_IncWarningCount(){
    document.getElementById('item_warning_count').value=parseInt(document.getElementById('item_warning_count').value, 10) + 1;
    document.getElementById('item_warning_count').style.backgroundColor ='yellow';
  }
        
  function SandboxItemCheckerForm_IncCheckCount(){
    document.getElementById('item_count').value=parseInt(document.getElementById('item_count').value, 10) + 1;
  } 


  