# Change Log

## 0.1.0 2020-09-22
First release

## 0.1.1 2020-09-27
* Improved key validation
* Key Checker
* Expression Editor
* Changed settings to 'world'-scope(meaning that settings is no longer in 'client'-scope, in other words, each Sandbox world will have its own settings of this module )
* Minor fixes

## 0.2.0 2020-09-29
* Updated Expression Editor with CodeMirror for syntax highlightning and tab support
* Added Expression Editor for simplenumeric property Max
* Minor fixes