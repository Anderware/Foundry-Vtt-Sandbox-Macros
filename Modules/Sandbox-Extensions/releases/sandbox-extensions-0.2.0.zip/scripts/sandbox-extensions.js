   // export const needed by ModuleSettingsForm
   export const _module_id='sandbox-extensions';  // modules true name(id)
   export const _module_ignore_settings=[];       // array of strings containing settings that should not be displayed, can be empty []
     
   import { ModuleSettingsForm } from "./module-settings-form.js";
   import { SandboxKeyCheckerForm } from "./sandbox-key-checker-form.js";
   import { SandboxKeyValidate } from "./sandbox-key-validate.js";
   import { SandboxExpressionEditorForm } from "./sandbox-expression-editor-form.js";
   
   
   class SandboxExtensions {
    static ID = _module_id ;  // moduleID         
    
    static CONSTANTS={
      CASE:{                
        NONE:"None",
        LOWERCASE:"Lower case",
        UPPERCASE:"Upper case",
        TITLECASE:"Title case"
      },
      CASENR:["None","Lower case","Upper case","Title case"],
      SEPARATOR:{
        KEY:"_",
        CSS:"-"
      }
    }
    
    static SETTINGS =  { 
      AUTOGEN :{                           
        SETTINGS_FORM: 'SETTINGS_FORM',
        KEY_CHECKER_FORM: 'KEY_CHECKER_FORM',
        PREFIX_PROPERTY: 'PREFIX_PROPERTY',
        PREFIX_PANEL: 'PREFIX_PANEL', 
        PREFIX_MULTIPANEL: 'PREFIX_MULTIPANEL',
        PREFIX_GROUP: 'PREFIX_GROUP',
        PREFIX_TAB: 'PREFIX_TAB',
        SUFFIX_FONTGROUP:'SUFFIX_FONTGROUP',
        SUFFIX_INPUTGROUP:'SUFFIX_INPUTGROUP',
        SUFFIX_HEADERGROUP:'SUFFIX_HEADERGROUP',
        SUFFIX_ROLLID:'SUFFIX_ROLLID',
        OPTION_KEY_CONVERT_TO_CASE:'OPTION_KEY_CONVERT_TO_CASE',
        OPTION_CSS_CONVERT_TO_CASE:'OPTION_CSS_CONVERT_TO_CASE',
        OPTION_ENFORCED_VALIDATION:'OPTION_ENFORCED_VALIDATION',
        OPTION_NUMBER:'OPTION_NUMBER',
        OPTION_BOOLEAN:'OPTION_BOOLEAN',
        OPTION_FILEPICKER:'OPTION_FILEPICKER'
      }
    }    
    
    static DEFAULT_SETTINGS={  
      AUTOGEN :{
        PREFIX_PROPERTY: 'PROPERTY',
        PREFIX_PANEL: 'PANEL', 
        PREFIX_MULTIPANEL: 'MULTIPANEL',
        PREFIX_GROUP: 'GROUP',
        PREFIX_TAB: 'TAB',
        SUFFIX_FONTGROUP:'FONTGROUP',
        SUFFIX_INPUTGROUP:'INPUTGROUP',
        SUFFIX_HEADERGROUP:'HEADERGROUP',
        SUFFIX_ROLLID:'ROLL',
        OPTION_KEY_CONVERT_TO_CASE:2,
        OPTION_CSS_CONVERT_TO_CASE:1,
        OPTION_ENFORCED_VALIDATION:'' // empty means false, non-empty is true
      }
    }  
    
    
    
    lastItemId='';
    
    static initialize() {
      // menu for KEY_CHECKER_FORM
      game.settings.registerMenu(this.ID, this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM, {
            name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Name`,
            label: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Name`,
            hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.KEY_CHECKER_FORM}.Hint`,
            icon: "fas fa-arrow-alt-circle-right",
            type: SandboxKeyCheckerForm,
            restricted: true
        }); 
      // menu for the Module Setting Form 
      game.settings.registerMenu(this.ID, this.SETTINGS.AUTOGEN.SETTINGS_FORM, {
            name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
            label: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Name`,
            hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SETTINGS_FORM}.Hint`,
            icon: "fas fa-cog",
            type: ModuleSettingsForm,
            restricted: true
        }); 
      // ---------------------------------------------------------------- 
      // Settings registrations                                           
      // ----------------------------------------------------------------    
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}`,
        type: Boolean,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PROPERTY, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PROPERTY}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PROPERTY}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_PANEL, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PANEL}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_PANEL}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_PANEL}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_GROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_GROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_GROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_GROUP}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.PREFIX_TAB, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_TAB}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.PREFIX_TAB}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.PREFIX_TAB}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP}.Hint`        
      }); 
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP}.Hint`        
      });   
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.SUFFIX_ROLLID, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.SUFFIX_ROLLID}`,
        type: String,
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.SUFFIX_ROLLID}.Hint`        
      });
      
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}`,
        type: String, 
        choices: {
          0: this.CONSTANTS.CASE.NONE,
          1: this.CONSTANTS.CASE.LOWERCASE,
          2: this.CONSTANTS.CASE.UPPERCASE,
          3: this.CONSTANTS.CASE.TITLECASE
        },        
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE}.Hint`        
      });
      game.settings.register(this.ID, this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE, {
        name: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Name`,
        default: `${this.DEFAULT_SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}`,
        type: String, 
        choices: {
          0: this.CONSTANTS.CASE.NONE,
          1: this.CONSTANTS.CASE.LOWERCASE,
          2: this.CONSTANTS.CASE.UPPERCASE,
          3: this.CONSTANTS.CASE.TITLECASE
        },        
        scope: 'world',
        config: false,
        hint: `sandbox-extensions.settings.autogen.${this.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE}.Hint`        
      });
           
    }
  }
  
  Hooks.once('init', () => {     
    SandboxExtensions.initialize();
  });
  
  
  
  
  Hooks.on('renderItemSheet', (sItemSheet, html) => {  
      
    let inputKey;
    let inputTag;    
    let inputTooltip;
    let inputFontGroup;
    let inputInputGroup;
    let inputHeaderGroup;
    let inputRollExp;
    let inputRollName;
    let inputRollID;
    let inputAuto;
    let inputAutoMax;
    let itemName;  
    let tooltip_generate;
    let tooltip_copy;
    let hasKey=false; 
    let hasTag=false;  
    let hasTooltip=false;
    let hasFontGroup=false;
    let hasInputGroup=false; 
    let hasHeaderGroup=false; 
    let hasRollExp =false;
    let hasRollName =false; 
    let hasRollID=false;
    let hasAuto=false; 
    let hasAutoMax=false;  
    let elementKey; 
    let elementTag;    
    let elementTooltip;
    let elementFontGroup;
    let elementInputGroup;
    let elementHeaderGroup;
    let elementRollExp;
    let elementRollName;  
    let elementRollID;
    let elementAuto;  
    let elementAutoMax;
    let key_prefix='';
    let key_prefix_setting='';
    
    const key_separator=SandboxExtensions.CONSTANTS.SEPARATOR.KEY;
    const css_separator=SandboxExtensions.CONSTANTS.SEPARATOR.CSS;
    
    
            
    let itemid=sItemSheet.object.data._id;
    
    if (itemid!=''){      
      SandboxExtensions.lastItemId=itemid;
    }                                     
    else{                 
      // cant get the itemid
      console.error("SandboxExtensions || Cant get itemid, reusing last from class object");
      itemid= SandboxExtensions.lastItemId;      
    }       
    // get the name of the item
    itemName=html.find(`input[name="name"]`)[0].value;        
    // find typeclass
    const typeClass=html.find(`.typelabel`)[0].innerText; 
    let validatingitemtype='';   
    // depending on typeclass
    switch(typeClass) {    
      case 'PROPERTY': 
        validatingitemtype='property';        
        hasKey=true;
        key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PROPERTY;              
        elementKey='input[name="data.attKey"]';
        hasTag=true;
        elementTag='input[name="data.tag"]';
        hasTooltip=true;
        elementTooltip='textarea[name="data.tooltip"]';  
        hasFontGroup=true; 
        elementFontGroup='input[name="data.fontgroup"]'; 
        hasInputGroup=true; 
        elementInputGroup='input[name="data.inputgroup"]';  
        hasRollExp=true;
        elementRollExp='input[name="data.rollexp"]';
        hasRollName=true;
        elementRollName='input[name="data.rollname"]'; 
        hasRollID=true;
        elementRollID='input[name="data.rollid"]';
        hasAuto=true;
        elementAuto='input[name="data.auto"]';   
        hasAutoMax=true;
        elementAutoMax='input[name="data.automax"]';        
        break;
      case "MULTIPANEL":
        validatingitemtype='multipanel';
        //data.panelKey
        hasKey=true; 
        key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_MULTIPANEL;
        elementKey='input[name="data.panelKey"]';
        hasTag=true;
        elementTag='input[name="data.title"]';
        break; 
      case "PANEL":
        //data.panelKey
        validatingitemtype='panel'; 
        key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_PANEL; 
        hasKey=true;
        elementKey='input[name="data.panelKey"]';
        hasTag=true;
        elementTag='input[name="data.title"]'; 
        hasFontGroup=true; 
        elementFontGroup='input[name="data.fontgroup"]'; 
        hasInputGroup=true; 
        elementInputGroup='input[name="data.inputgroup"]';  
        hasHeaderGroup=true; 
        elementHeaderGroup='input[name="data.headergroup"]'; 
        break; 
      case "TAB":
        hasKey=true; 
        validatingitemtype='sheettab';
        key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_TAB;
        elementKey='input[name="data.tabKey"]';
        hasTag=true;
        elementTag='input[name="data.title"]';
        break; 
      case "GROUP":
        hasKey=true;
        validatingitemtype='group'; 
        key_prefix_setting=SandboxExtensions.SETTINGS.AUTOGEN.PREFIX_GROUP; 
        elementKey='input[name="data.groupKey"]';
        break;   
      case "cITEM":
        //console.log('citem!!');  
        hasRollExp=true;
        elementRollExp='input[name="data.roll"]'; 
        hasRollName=true;
        elementRollName='input[name="data.rollname"]'; 
        hasRollID=true;
        elementRollID='input[name="data.rollid"]';  
      default:
        // nothing
    }    
                
    if(hasKey){        
            
      // find the element which the key
      inputKey = html.find(`${elementKey}`); 
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-key-title');                       
      let tooltip_validate=game.i18n.localize('sandbox-extensions.button-validate-key-title');
      tooltip_copy=game.i18n.localize('sandbox-extensions.button-copy-key-title');      
      // insert buttons at the end of this element
      inputKey.after(`<i class="sbe-btn generate-key fas fa-magic" title="${tooltip_generate}" ></i>
                      <i class="sbe-btn validate-key fas fa-spell-check" title="${tooltip_validate}"></i>
                      <i class="sbe-btn copy-key fas fa-copy" title="${tooltip_copy}"></i>`);        
      // register event listeners for buttons                  
      html.find('.generate-key').click(ev => {         
        // check if itemname already begins with prefix then dont add it 
        key_prefix = sandboxextensions_get_game_setting(SandboxExtensions.ID,key_prefix_setting); 
        let full_prefix=''; 
        let sKey='';
        if (key_prefix!=''){        
          full_prefix=key_prefix + key_separator;
          if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
            sKey=itemName;
          }
          else{
            sKey=full_prefix +  itemName;
          }
        }
        else{
          sKey=itemName;
        }       
        let keyCase=SandboxExtensions.CONSTANTS.CASENR[sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE)];                                           
        sKey=sandboxextensions_slugify(sKey,key_separator,keyCase);                    
        inputKey[0].value= sKey;             
      });              
     
      html.find('.validate-key').click(ev => {  
        const enforcedvalidation=sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_ENFORCED_VALIDATION);
        itemName=html.find(`input[name="name"]`)[0].value;
        let sKey=html.find(`${elementKey}`)[0].value;                                                
        sandboxextensions_validate_key(validatingitemtype,itemName,itemid,typeClass,sKey,enforcedvalidation); 
      });
      
      html.find('.copy-key').click(ev => {        
        let sKey=html.find(`${elementKey}`)[0].value;                                                
        navigator.clipboard.writeText(sKey);
      });  
        
    }  
        
    if(hasAuto){
      // try to find field auto
      inputAuto = html.find(`${elementAuto}`);         
      if (inputAuto!=null){
        let tooltip_editor=game.i18n.localize('sandbox-extensions.button-open-expression-editor-title');
        inputAuto.after(`<i class="sbe-btn open-expression-editor-auto fas fa-code" title="${tooltip_editor}"></i>`);
        html.find('.open-expression-editor-auto').click(ev => {        
          let sRollExp=html.find(`${elementAuto}`)[0].value;
          itemName=html.find(`input[name="name"]`)[0].value;
          let itemtargetelement=`${elementAuto}`;           
          let options = {
              expression: sRollExp,
              itemid: itemid,
              itemname:itemName,
              itemtype:typeClass.toLowerCase(),
              itemlabel:'Auto',
              itemtargetelement:itemtargetelement
            }                                                                   
          new SandboxExpressionEditorForm(options).render(true,{focus:true});           
        });                  
      }            
    }
    
    if(hasAutoMax){
      // try to find field auto
      inputAutoMax = html.find(`${elementAutoMax}`);         
      if (inputAutoMax!=null){
        let tooltip_editor=game.i18n.localize('sandbox-extensions.button-open-expression-editor-title');
        inputAutoMax.after(`<i class="sbe-btn open-expression-editor-auto-max fas fa-code" title="${tooltip_editor}"></i>`);
        html.find('.open-expression-editor-auto-max').click(ev => {        
          let sAutoMax=html.find(`${elementAutoMax}`)[0].value;
          itemName=html.find(`input[name="name"]`)[0].value;
          let itemtargetelement=`${elementAutoMax}`;           
          let options = {
              expression: sAutoMax,
              itemid: itemid,
              itemname:itemName,
              itemtype:typeClass.toLowerCase(),
              itemlabel:'Auto Max',
              itemtargetelement:itemtargetelement
            }                                                                   
          new SandboxExpressionEditorForm(options).render(true,{focus:true});           
        });                  
      }            
    }
    
    
    if(hasRollExp){
      // try to find roll exp
      inputRollExp = html.find(`${elementRollExp}`);         
      if (inputRollExp!=null){
        let tooltip_editor=game.i18n.localize('sandbox-extensions.button-open-expression-editor-title');
        inputRollExp.after(`<i class="sbe-btn open-expression-editor-roll-exp fas fa-code" title="${tooltip_editor}"></i>`);
        html.find('.open-expression-editor-roll-exp').click(ev => {        
          let sRollExp=html.find(`${elementRollExp}`)[0].value;
          itemName=html.find(`input[name="name"]`)[0].value;
          let itemtargetelement=`${elementRollExp}`;           
          let options = {
              expression: sRollExp,
              itemid: itemid,
              itemname:itemName,
              itemtype:typeClass.toLowerCase(),
              itemlabel:'Roll Formula',
              itemtargetelement:itemtargetelement
            }                                                                   
          new SandboxExpressionEditorForm(options).render(true,{focus:true});           
        });                  
      }            
    }
   
    if(hasRollName){
      // try to find roll exp
      inputRollName = html.find(`${elementRollName}`);         
      if (inputRollName!=null){
        let tooltip_editor=game.i18n.localize('sandbox-extensions.button-open-expression-editor-title');
        inputRollName.after(`<i class="sbe-btn open-expression-editor-roll-name fas fa-code" title="${tooltip_editor}"></i>`);
        html.find('.open-expression-editor-roll-name').click(ev => {        
          let sRollExp=html.find(`${elementRollName}`)[0].value;
          itemName=html.find(`input[name="name"]`)[0].value;
          let itemtargetelement=`${elementRollName}`;           
          let options = {
              expression: sRollExp,
              itemid: itemid,
              itemname:itemName,
              itemtype:typeClass.toLowerCase(),
              itemlabel:'Roll Name',
              itemtargetelement:itemtargetelement
            }                                                                   
          new SandboxExpressionEditorForm(options).render(true,{focus:true});           
        });                  
      }            
    } 
    
    if(hasRollID){
      // try to find roll exp
      inputRollID = html.find(`${elementRollID}`);         
      if (inputRollID!=null){
        let tooltip_rollid=game.i18n.localize('sandbox-extensions.button-generate-rollid-title');
        inputRollID.after(`<i class="sbe-btn generate-rollid fas fa-magic" title="${tooltip_rollid}"></i>`);
        let sBase;
        html.find('.generate-rollid').click(ev => { 
          if (typeClass=='PROPERTY'){       
            sBase=html.find(`${elementKey}`)[0].value;
          }
          else{
            sBase=html.find(`input[name="name"]`)[0].value;
          }  
          const SUFFIX_ROLLID=sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_ROLLID);    
          let sRollID=sBase + key_separator + SUFFIX_ROLLID;
          let keyCase=SandboxExtensions.CONSTANTS.CASENR[sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_KEY_CONVERT_TO_CASE)];                                                                 
          inputRollID[0].value= sandboxextensions_slugify(sRollID,key_separator,keyCase);             
        });                  
      }            
    }
   
    
    if(hasTag){
      // find the element which the key
      inputTag = html.find(`${elementTag}`);            
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-tag-title'); 
      // insert a button at the end of this element
      inputTag.after(`<i class="sbe-btn generate-tag fas fa-magic" title="${tooltip_generate}"></i>`);        
      // register event listeners for buttons  
      html.find('.generate-tag').click(ev =>  {  
        key_prefix = sandboxextensions_get_game_setting(SandboxExtensions.ID,key_prefix_setting);                                    
        let full_prefix=key_prefix + key_separator;
        let sItemName='';       
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }                       
        inputTag[0].value= sItemName;               
      });
    }   
     
    if(hasTooltip){
      // find the element which the key
      inputTooltip = html.find(`${elementTooltip}`);            
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-tooltip-title'); 
      // insert a button at the end of this element
      inputTooltip.after(`<i class="sbe-btn generate-tooltip fas fa-magic" title="${tooltip_generate}"></i>`);        
      // register event listeners for buttons  
      html.find('.generate-tooltip').click(ev => { 
        key_prefix = sandboxextensions_get_game_setting(SandboxExtensions.ID,key_prefix_setting); 
        let full_prefix=key_prefix + key_separator;
        let sItemName='';       
        if(itemName.toUpperCase().startsWith(full_prefix.toUpperCase())){
          // get rid of prefix
          sItemName=itemName.slice(full_prefix.length);
        }
        else{
          sItemName= itemName;
        }             
        inputTooltip[0].value= sItemName;              
      });
    } 
                
    if(hasFontGroup){  
     
      // find the element which the key
      inputFontGroup = html.find(`${elementFontGroup}`);            
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-fontgroup-title');
      tooltip_copy=game.i18n.localize('sandbox-extensions.button-copy-fontgroup-title'); 
      // insert buttons at the end of this element
      inputFontGroup.after(`<i class="sbe-btn generate-fontgroup fas fa-magic" title="${tooltip_generate}"></i>
                            <i class="sbe-btn copy-fontgroup fas fa-copy" title="${tooltip_copy}"></i>`);        
      // register event listeners for buttons  
      html.find('.generate-fontgroup').click(ev => {     
        let sKey=html.find(`${elementKey}`)[0].value;  
        const suffix_fontgroup=sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_FONTGROUP);    
        let sFontGroup=sKey + css_separator + suffix_fontgroup;
        let cssCase=SandboxExtensions.CONSTANTS.CASENR[sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE)];                                                                 
        inputFontGroup[0].value= sandboxextensions_slugify(sFontGroup,css_separator,cssCase);         
      }) ; 
      html.find('.copy-fontgroup').click(ev => {        
        let sFontGroup=html.find(`${elementFontGroup}`)[0].value;                                                
        navigator.clipboard.writeText(sFontGroup);
      });                  
    }      
    
    if(hasInputGroup){  
       
      // find the element which the key
      inputInputGroup = html.find(`${elementInputGroup}`);            
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-inputgroup-title');
      tooltip_copy=game.i18n.localize('sandbox-extensions.button-copy-inputgroup-title'); 
      // insert buttons at the end of this element
      inputInputGroup.after(`<i class="sbe-btn generate-inputgroup fas fa-magic" title="${tooltip_generate}"></i>
                            <i class="sbe-btn copy-inputgroup fas fa-copy" title="${tooltip_copy}" ></i>`);        
      // register event listeners for buttons
      html.find('.generate-inputgroup').click(ev => {  
        let sKey=html.find(`${elementKey}`)[0].value; 
        const suffix_inputgroup=sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_INPUTGROUP);      
        let sInputGroup=sKey + css_separator + suffix_inputgroup; 
        let cssCase=SandboxExtensions.CONSTANTS.CASENR[sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE)];                                                               
        inputInputGroup[0].value= sandboxextensions_slugify(sInputGroup,css_separator,cssCase);      
      }) ;      
      html.find('.copy-inputgroup').click(ev => {        
        let sInputGroup=html.find(`${elementInputGroup}`)[0].value;                                                
        navigator.clipboard.writeText(sInputGroup);
      });            
    }
    if(hasHeaderGroup){ 
       
      // find the element which the key
      inputHeaderGroup = html.find(`${elementHeaderGroup}`);            
      tooltip_generate = game.i18n.localize('sandbox-extensions.button-generate-headergroup-title'); 
      tooltip_copy=game.i18n.localize('sandbox-extensions.button-copy-headergroup-title');
      // insert buttons at the end of this element
      inputHeaderGroup.after(`<i class="sbe-btn generate-headergroup fas fa-magic" title="${tooltip_generate}"></i>
                              <i class="sbe-btn copy-headergroup fas fa-copy" title="${tooltip_copy}"></i>`);        
      // register event listeners for buttons
      html.find('.generate-headergroup').click(ev => {  
        let sKey=html.find(`${elementKey}`)[0].value;  
        const suffix_headergroup=sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.SUFFIX_HEADERGROUP);     
        let sHeaderGroup=sKey + css_separator + suffix_headergroup; 
        let cssCase=SandboxExtensions.CONSTANTS.CASENR[sandboxextensions_get_game_setting(SandboxExtensions.ID, SandboxExtensions.SETTINGS.AUTOGEN.OPTION_CSS_CONVERT_TO_CASE)];                                                               
        inputHeaderGroup[0].value= sandboxextensions_slugify(sHeaderGroup,css_separator,cssCase);         
      }); 
      html.find('.copy-headergroup').click(ev => {        
        let sHeaderGroup=html.find(`${elementHeaderGroup}`)[0].value;                                                
        navigator.clipboard.writeText(sHeaderGroup);
      });
    }
   
    
  });
  
  function sandboxextensions_get_game_setting(moduleID,settingName){
    let setting=game.settings.get(moduleID, settingName);
    if (!setting) {
      return  '';
    }
    else{
      return setting;
    }
  }
  
  // function for checing if this key is valid
  function sandboxextensions_validate_key(validatingitemtype,itemName, validatingitemid,typeClass,sKey,enforcedvalidation) {  
    let sHeader= 'Key validation for key [' + sKey + '] for ' + typeClass + ' [' + itemName +']';       
    let objResult = SandboxKeyValidate(validatingitemtype,validatingitemid,sKey,enforcedvalidation);
    // check for warnings and errors    
    if (objResult.warnings.length>0 || objResult.errors.length>0){
    
      objResult.warnings.forEach(function(msg){
        ui.notifications.warn(sHeader + ' returned validation warning:<br>' + msg);      
      });  
       objResult.errors.forEach(function(msg){
        ui.notifications.error(sHeader + ' returned validation error:<br>' + msg);      
      });                   
    } 
    
    else{                     
      ui.notifications.info(sHeader + ' returned valid.' );
    }                                                          
  }

  function sandboxextensions_slugify(text,separator,useCase=SandboxExtensions.CONSTANTS.CASE.NONE){  
    
    let sReturn=text
          .toString()
          .normalize('NFD')                   // split an accented letter in the base letter and the acent
          .replace(/[\u0300-\u036f]/g, '')   // remove all previously split accents          
          .trim();
     
    switch(useCase){
      case SandboxExtensions.CONSTANTS.CASE.NONE:
        sReturn=sReturn 
          .replace(/[^A-Za-z0-9_-]/g, separator);   // remove all chars not letters, numbers and spaces (to be replaced)
        break;
      case SandboxExtensions.CONSTANTS.CASE.LOWERCASE:
        sReturn=sReturn 
          .toLowerCase()               
          .replace(/[^a-z0-9_-]/g, separator) ;  // remove all chars not letters, numbers and spaces (to be replaced)
          break;
      case SandboxExtensions.CONSTANTS.CASE.UPPERCASE:
         sReturn=sReturn      
          .toUpperCase()               
          .replace(/[^A-Z0-9_-]/g, separator);   // remove all chars not letters, numbers and spaces (to be replaced)               
        break;
      case SandboxExtensions.CONSTANTS.CASE.TITLECASE:           
          sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.KEY,' ');
          sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.CSS,' ');
          sReturn= sandboxextensions_toTitleCase(sReturn);
          sReturn=sReturn 
              .replace(/[^A-Za-z0-9_-]/g, separator);                   
        break;    
    }        
    if(separator==SandboxExtensions.CONSTANTS.SEPARATOR.KEY){
      sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.CSS, separator) ;
    }  
    if(separator==SandboxExtensions.CONSTANTS.SEPARATOR.CSS){
      sReturn=sReturn.replaceAll(SandboxExtensions.CONSTANTS.SEPARATOR.KEY, separator) ;
    }        
    sReturn=sReturn.replace(/\s+/g, separator) ; 
    return sReturn;
  }             
  
  function sandboxextensions_toTitleCase(str) {
  return str.replace(
    /\w\S*/g,
    function(txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    }
  );
}




 