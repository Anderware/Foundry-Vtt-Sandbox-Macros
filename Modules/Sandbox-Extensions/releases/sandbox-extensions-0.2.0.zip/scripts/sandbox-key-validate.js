export function SandboxKeyValidate(validatingitemtype,validatingitemid,sKey,enforcedvalidation=true){                 
  let objResult = {
    warnings:  [],
    errors: []
  };    
  let items;          
                 
  // check that it has anything
  if(sKey.length==0){           
    objResult.errors.push('Key is empty'); 
  }
  else{  
    // general syntax check 
    if(enforcedvalidation){
      const validchars = /^[A-Za-z0-9_]+$/;   // will only allow unaccented letters a-z, A-Z, numbers 0-9 and underscore
      if(!sKey.match(validchars)){
        // fail         
        objResult.errors.push('Key contains invalid characters');            
      }
    }  
    else{
      // relaxed validation, will allow anything but spaces and special characters defined below
      let format = /[ `����!@#$%^&*()+=\[\]{};':"\\|,.<>\/?~]/;
      if (format.test(sKey)){                                                  
        objResult.errors.push('Key contains invalid characters');        
      }   
      // NOTE seems that comma,semicolon also kills them
    }
    
    // now check against the rest of the items in the database
    items = game.items.filter(y=>(y.type=="property" && y.data.data.attKey==sKey)||(y.type=="panel" && y.data.data.panelKey==sKey)||(y.type=="multipanel" && y.data.data.panelKey==sKey) || (y.type=="sheettab" && y.data.data.tabKey==sKey)||(y.type=="group" && y.data.data.groupKey==sKey)  );          
    if (items.length>0){
      // found items, check each one                 
      items.forEach(function(item)  {   
        // check if this is the item 
        if (item!=null){
          if (item.id!==validatingitemid){ 
            if(enforcedvalidation){
              objResult.errors.push('Key exists for ' + item.type.toLowerCase() + ' [' + item.name+']');
            }
            else{
              // relaxed validation
              if(validatingitemtype.toUpperCase()=='PANEL'||validatingitemtype.toUpperCase()=='MULTIPANEL' ){          
                // special for panels/multipanels 
                if(item.type.toUpperCase()=='PANEL' || item.type.toUpperCase()=='MULTIPANEL'){               
                  objResult.errors.push('Key exists for ' + item.type.toLowerCase() + ' [' + item.name+']');
                }
                else{
                  // just a warning
                  objResult.warnings.push('Key exists for ' + item.type.toLowerCase() + ' [' + item.name+']'); 
                }
              }            
              else{
                // keys for these types can exist for other item types
                if(item.type.toUpperCase()==validatingitemtype.toUpperCase()){                             
                  objResult.errors.push('Key exists for ' + item.type.toLowerCase() + ' [' + item.name+']');
                }
                else{
                  objResult.warnings.push('Key exists for ' + item.type.toLowerCase() + ' [' + item.name+']');
                }
                
              }
            }            
          }
        } 
      });   
    } 
  }  
  
 return objResult;

}

