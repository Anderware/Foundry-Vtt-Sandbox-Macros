# FUx Dice Roller Change Log


## Version 0.1.0 (2022-01-17)
First release
