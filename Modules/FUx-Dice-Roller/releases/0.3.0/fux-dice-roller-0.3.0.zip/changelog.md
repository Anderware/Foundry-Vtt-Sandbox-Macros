# FUx Dice Roller Change Log

## Version 0.3.0 (2022-01-20)
- Added option for custom Action/Danger icon
- Updated FU v2 Combat Helper
- Minor fixes

## Version 0.2.0 (2022-01-19)
- Added system variant Earthdawn Age of Legend
- Minor fixes

## Version 0.1.0 (2022-01-17)
- First release
